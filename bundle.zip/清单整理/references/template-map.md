# 模板行号与列位

## 英文报价模板（常用）

文件：`英文报价模板.xlsx`，sheet `方案`。

```
 1-4   logo + 公司抬头（C1 标题 / C2 公司名 / C3 生产基地 / C4 电话传真）
 5     A5 Party A   F5 Party B   K5 编号
 6     A6 甲方负责人  F6 乙方负责人  K6 日期
 7     A7 TEL       F7 TEL
 8     表头行：NO. | Product Name | PIC | SIZE(W*D*H)mm | QTY | UNIT | UNIT-EXW-RMB | Amount-EXW-RMB | Material | (L空) | REMARK
 9-44  明细区（36 行，必须扩容）
 45-51 表尾 7 条中英对照条款
```

列位（13 列，A:M）：

| 列 | 内容 | 宽度 |
|---|---|---|
| A | NO. | 8.9 |
| B | Product Name | 19.7 |
| C | PIC | 13 |
| D/E/F | SIZE W / D / H（D8:F8 合并表头） | 7.8 / 13 / 13 |
| G | QTY | 17.4 |
| H | UNIT | 10.6 |
| I | UNIT-EXW-RMB | 18.75 |
| J | Amount-EXW-RMB | 13 |
| K | Material | 33.2 |
| L | （模板无表头，实测当备注用） | 52.5 |
| M | REMARK | 16 |

`L` 列宽 52.5 却没表头，实际是主要备注列。本项目在 `L8` 补了 `REMARKS`，`M` 放 `Ref: IF-xxxx`。**改表头前先确认客户是否有既定格式。**

## 中文报价模板（对照用）

sheet `报价清单`：表头第 **9** 行，明细 **10–15**（6 行，**没有分组行**），16 行 = 出厂价合计，17–21 = 运输/安装/搬运/税金/含税合计，22 = 说明：，23–28 = 6 条条文，打印区 A1:N28。

> 这个模板曾被误判为"第 10 行是分组行、第 17 行是合计"，导致表头被清空、页脚整体错位一行。**行号一律以 XML 为准。**

v1.5 起这个模板有可执行的通用输出脚本，结构参数写在 config 的 `cn_quote.layout`，字段映射与自检见 `references/cn-quote.md`。

## 明细区扩容

模板只有 36 行，实际条目几乎总是更多。

```python
extra = len(rows_plan) - (FOOTER_START - CONTENT_START)   # 36
ws.insert_rows(FOOTER_START, extra)                       # 一次性插够
footer_start = FOOTER_START + extra
```

**扩容前必须做的事：**

1. 先把表尾 45–51 的值、`_style`、`number_format`、行高、合并区全部存档。
2. **unmerge 掉明细区的所有合并**（`D9:F9`、`C13:C14` 这类），否则写入时报 `MergedCell object attribute 'value' is read-only`。
3. `footer_merges` **只收 `min_row >= FOOTER_START` 的合并**。把明细区合并也存进去，插行后会重新合并到错误行（本项目合到了第 243 行）。
4. 插行后按 `offset = extra` 把表尾值/样式/合并/行高搬回去。

## 样式复制

跨工作簿不能直接搬 `_style` 数组，要逐属性 copy：

```python
dst.font = copy(src.font);      dst.border = copy(src.border)
dst.fill = copy(src.fill);      dst.alignment = copy(src.alignment)
dst.number_format = src.number_format
```

## 图片

```python
pic = Image(path)
ratio = min(96 / pic.width, 62 / pic.height, 1)   # 适配 C 列 ~96px 宽、行高 80pt
pic.width, pic.height = pic.width * ratio, pic.height * ratio
ws.add_image(pic, f'C{r}')
```

`add_image(pic, 'C10')` 生成 oneCellAnchor + ext，显示尺寸由 `pic.width/height` 决定。
**不要用 reload 后的 `im.width` 判断显示尺寸**——openpyxl 会按单元格重算成 184×223 之类的假值。

## 打印设置

```python
ws.print_area = f'A1:M{last_row}'
ws.print_title_rows = '1:8'
ws.page_setup.orientation = 'landscape'
ws.sheet_properties.pageSetUpPr.fitToPage = True
ws.page_setup.fitToWidth = 1
ws.page_setup.fitToHeight = 0
```

14 列竖排 57% 必然断列，一律横向 fit-to-width。

## 后处理（裁空壳 + 补命名空间）

openpyxl 保存后会留下大量 A:M 之外的空壳单元格（曾有 70 万+），逐行删：

```python
ET.register_namespace('', NS_MAIN)
ET.register_namespace('r', NS_REL)   # 不注册，r:id 会退化成 ns1:id
```

删完同步改 `dimension ref="A1:M{max_row}"`。本项目清理了 140 万+ 空单元格。
