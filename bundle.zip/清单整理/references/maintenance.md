# 技能维护细则（每轮收尾必做）

本技能是**活的**：每做完一个项目就回写一次。不做这一步，下一个项目会重复踩同一个坑。

## 一、什么时候做

一轮清单/报价整理交付之后，**立刻**做，不要等用户提。用户在对话里说过：

> 每一轮清单整理结束之后，自动整理更新 skill。

## 二、四件事

### 1. 记新坑 → `references/pitfalls.md`

只在**这轮新遇到**才加，已有条目不要重写。格式固定三行：

```markdown
15. **一句话现象。**
    根因：为什么会这样（能定位到 openpyxl / xlsx 结构 / 客户数据 哪一层）。
    修法：怎么绕（给代码片段或命令）。
```

规则：

- 编号连续往下排，**不要重排既有编号**——`references/*.md` 里有交叉引用。
- 只写"踩了才知道"的，不写教科书内容（openpyxl 怎么装这种不写）。
- 现象要写成用户视角（"表头被清空""图片压到下一行"），方便以后按现象搜到。

### 2. 补术语 → `scripts/glossary.py`

- 单条专有品名 → `NAMES` 字典。
- 组合式品名（`Lobby Sofa A`、`Round Dining Table for 2`）→ 加词根到 `NAME_PHRASES` / `NAME_WORDS`，**不要逐条建词典**，否则词典无限膨胀。
- 材质词 → `_D` 或 `_EXTRA`/`_PRE`。注意：会被通用规则吃掉的专有短语（`Leatherette` vs `Leather`）必须放 `_PRE` 预处理。
- 单字母/两字母词（`or`、`in`、`at`）必须带 `\b` 或前后否定断言，否则 `outdoor → outdo或`。
- 补完跑一次覆盖率，只剩品牌（Sunbrella / Concertex）、色号、料号（SP-/MT-/GL-）才算收口：

```bash
python -c "
import json,sys; sys.path.insert(0,'scripts')
from glossary import translate_material
d=json.load(open('_work/parsed.json',encoding='utf8'))
n=sum(1 for i in d if translate_material(i['material'])[1])
print('材质残余英文条目:',n,'/',len(d))"
```

### 3. 改脚本 → `scripts/`

- 这轮临时为了过审打的补丁，合并回主脚本，不要留在项目目录里当"这个项目专用版"。
- 下一个项目还会用到的差异 → 做成 `config.json` 的开关（`auto_height` / `pic_w` / `drawing_mode` 都是这么来的），不要 `if 项目名 ==`。
- 改完必须**用上一个项目的数据回归**：重跑 build + selfcheck，确认没把老项目弄坏。

### 4. 写版本记录 → `references/changelog.md`

在文件顶部「当前版本」下面加一条，格式见文件内模板。同时同步 `SKILL.md` 三处：

- 「步骤 5 — 自检」的项数
- 「脚本」表格的文件清单
- 「配置开关」表格的键

## 三、验收标准

**下一个项目只改 `config.json` 就能跑通，不需要再改脚本。**

做不到就要问自己：这轮遇到的问题，是项目特例还是通用坑？是通用坑就必须固化。

## 四、不要做的事

- 不要把项目路径、客户名、具体报价写进技能（技能是跨项目复用的，写死就是污染）。
- 不要把一次性的调试脚本塞进 `scripts/`。只有**下个项目还会跑**的才进。
- 不要为了"看起来完整"编造坑。没踩过的不写。
- 不要改已经跑通的既有逻辑去"顺手优化"，除非这轮确实被它绊倒。

## 五、四条支路，别串台（v1.9 起）

| 支路 | 输入 | 配置样例 | 生成脚本 | 自检 |
|---|---|---|---|---|
| 报价模板 | 客户 BOQ / 方案 PDF | `assets/config.sample.json` | `scripts/build_quote.py` | `selfcheck.py`（27 项） |
| 清单拆分 | 混合材料报验表 | `assets/config.material.sample.json` | `scripts/build_material_list.py` | `selfcheck_material.py`（28 项） |
| 中文模板输出 | 拆分清单 + 客户中文模板 | 同一份 `config.material.sample.json` 的 `cn_quote` 节 | `scripts/build_cn_quote.py` | `selfcheck_cn_quote.py`（27 项） |

- 改脚本只动**对应支路**的脚本；改完用该支路上一个项目的数据回归一次（重跑 build + selfcheck）。
- `glossary.py` 只服务英→中翻译。**纯中文清单不需要补词条**，别为了凑「四件事」硬加词，在 changelog 里写明「无新增术语」即可。
- 自检脚本报错时，先分清「数据缺陷」还是「断言过严」：假 FAIL 修脚本，绝不为了过审改源数据（v1.4 一次踩了 5 类）。
- 样例 config 要跟着脚本一起更新：新增了配置键却没进样例，下一个项目还是得读代码。中文模板支路的新键必须同步进 `config.material.sample.json` 的 `cn_quote` 节。
- 清单拆分与中文模板输出**共用同一份 config**（拆完直接套模板），新增支路时不要另起一份配置文件，否则「只改一份 config 跑通全链路」就失效了。
