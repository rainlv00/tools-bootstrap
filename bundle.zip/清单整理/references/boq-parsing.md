# 区块式 BOQ 解析规则

客户的 BOQ 通常是一张"单元格排版"的表，不是数据库表。一条产品占 4–8 行，靠**空行**和**缩进**区分。按固定列取数会全错。

## 1. 先摸清列位

不要假设表头在第 1 行。打印前 40 行 × 15 列全部原值，找这一行：

```
['Item', 'DESCRIPTION', '', '', '', '', 'PHOTOS', 'QUANTITY', 'UNIT', 'UNIT COST', ...]
```

典型布局（菲律宾/东南亚总包 BOQ）：

| 列 | 内容 |
|---|---|
| A | 序号（1、2、3…），General Requirements 用 |
| B | 条目字母（a. b. c.）**或**分区名（LEVEL 1 - MAIN LOBBY） |
| C | IF 型号 / 产品名 / 规格 / 材质（全部挤在 C） |
| F | SUB-TOTAL 文字常在这里 |
| G | PHOTOS（浮动图，无单元格值） |
| H | QUANTITY（常常整列为空） |
| I | UNIT |
| J–M | UNIT COST 拆分（Labor / Material / Equip't / Amount） |
| N | TOTAL AMOUNT |

## 2. 条目起始有四种写法

只认其中一种会漏掉约 1/4 条目。

| 类型 | 特征 | 例 |
|---|---|---|
| ① 字母 + 型号 | B 列 `a.`，C 列 `IF - 1107` | 散装家具 |
| ② 纯型号 | B 空，C 列 `IF-1107` | 少数散装 |
| ③ 纯名称 | B 空，C 列 `Throw Pillow A`（无任何编号） | 抱枕、腰枕等配件，**有独立单位，是独立报价行** |
| ④ 字母 + 名称 | B 列 `a.`，C 列 `COUNTER`（名称直接在字母行，无型号） | 固装家具 |

判定顺序（伪代码）：

```python
if IS_LETTER(B) and C:      new_item(code=C if IS_IF_CODE(C) else '', name=else C)
elif IS_IF_CODE(C) and not B: new_item(code=C)
elif B and not C:            header  # LEVEL 开头=分区，其余=区域
elif C and not B:
    if prev_blank or cur is None: new_item(name=C)     # ③
    else: continuation(C)
```

## 3. 条目之间不一定有空行

Level 4/5 常有 `a. b. c. d. e. f. g. h. i. j. k` 连排 11 条，中间没有空行。

**结论：字母行永远开新条目，不要用「是否空行」判断。**

## 4. 编号行之后的第一行才是名称

```
C49: IF - 1107      <- 编号
C50: Occassional Table A   <- 名称（单位在 I50）
C51: 600mm dia x 720mm H   <- 规格
C52: in Light quartz ...    <- 材质
```

把 C50 当材质续行，会导致全部条目的 name 为空。

固装则相反：名称就在编号行（`a.` + `COUNTER`），后续行直接是规格和饰面。

## 5. 分区与区域

- **分区**：B 列 `LEVEL 1 - MAIN LOBBY / LOUNGE`
- **区域**：B 列 `LOBBY` / `PRE-FUNCTION` / `ALL DAY DINING`
- **类别**：B 列 `TABLES` / `CHAIRS` / `SOFA`（通常已拆成独立 sheet）

命名不要统一——客户原文本身就不一致（`LEVEL 6 - 19 (GUESTROOM)` 与 `LEVEL 7 - 19 (GUESTROOM)` 并存），改了反而无法回查。

## 6. SUB-TOTAL 要跳过

`F164 = 'SUB-TOTAL FOR LEVEL 1 - TABLES'`，B/C 都是空。不特判会被当成一条产品。

## 7. 图片归属

客户表里的产品图是**浮动图**，不是单元格值。

```python
im.anchor._from.row + 1    # 锚点行（1 基）
```

两个必须处理的坑：

1. **锚点行常比条目首行早 1 行**（图片压在区块顶边）。
   用 `bisect_right(rows, anchor_row + 1) - 1` 修正。

2. **不同 sheet 行号重叠**（TABLES 的第 64 行和 BUILT-INS 的第 64 行是两条不同产品）。
   映射键必须是 `(sheet, row)`，只按 row 会串表。

取图：

```python
best = max((blk for blk in page.get_images(full=True)
            if page.get_image_rects(blk[0])[0].x0 > 430),
           key=lambda b: page.get_image_rects(b[0])[0].width)
```

## 8. 尺寸解析

客户写法规整度很低：

```
600mm dia x 720mm H
1160mm x 750mm W x 550mm H
1800 X 2000mm W
Front Counet (1695mm x  H)
Refer to drawings
```

按 `x`／`×` 切段，**按段顺序映射到 W/D/H 三列**（不是按字母），并让 `dia` 和 `H` 强制归位：

| 原文 | W | D | H |
|---|---|---|---|
| 600mm dia x 720mm H | | Ø600 | 720 |
| 1160mm x 750mm W x 550mm H | 1160 | 750 | 550 |
| 1800 X 2000mm W | 1800 | 2000 | |

圆形件写进 D 列并套 `"Ø"#,##0` 格式，值仍是数字，可参与计算。

## 9. 完工判据

| 指标 | 期望 |
|---|---|
| 条目数 | = 各 sheet 字母行数 + 无编号子项数，且与人工抽查一致 |
| name 缺失 | 0 |
| 有材质 | ≥ 95%（少数只有名称的条目例外） |
| 无编号条目 | 全部是抱枕/腰枕这类配件，不是解析错误 |


## 10. Strict OOXML / 外部链接

症状一：`TypeError: ExternalReference.__init__() missing 1 required positional argument: 'id'`
症状二：`load_workbook` 能过，但 `len(wb.sheetnames) == 0`

原因：文件是 Strict OOXML，命名空间是 `http://purl.oclc.org/ooxml/...`，openpyxl 只认 transitional。

处理：

```bash
python scripts/strict2t.py in.xlsx out.xlsx
```

脚本做三件事：替换命名空间、删 `conformance="strict"`、剥掉 `xl/externalLinks/*` 与对应 relationship。转换后在临时副本上作业，**原始文件保持只读**。

## 11. 整段式描述（另一种 BOQ 排版）

有的客户把整条规格塞进一个单元格：

```
Description: Providing and fixing a custom-made Lobby Lounge Chair.
Seat Structure:- Base: ...
ColourFinish: FB-50-03 & MT-11
```

换行可能被吃掉，也可能保留。两种都按下面的方式处理：

1. **原文整段保留**到「规格说明」列，逐字搬运，不删不改。这是唯一不会丢信息的做法。
2. 另起列抽 **Size**：`Size\s*[-–:：]\s*(...)` 优先，失败再退化到 `\d+\s*mm` 组合。
3. 另起列抽 **饰面代号**：`\b(ST|MT|WD|SF|FB|UP|GL|LP|PT)[-\s]?\d{2,4}[A-Z]?\b`，去重后按出现顺序连起来。这些代号是客户的 finish schedule 索引，报价时比一句英文描述有用得多。
4. 条目名称取自**上一行的标签行**，但标签行常写成 `C Table: Size - 450mm...`，要切掉 `:` 之后的内容。

## 12. 图片列失效的判定

看三处：

1. 单元格值是 `#VALUE!` 或 `=DISPIMG(...)` 且 media 目录有图。
2. `ws._images` 为空。
3. `xl/drawings/drawingN.xml` 里 `<pic>` 数量为 0，或者 sheet 的 rels 只指向 printerSettings。

三条全中 = 图片已脱离，**不要按 media 顺序猜对应关系**（本项目 106 张图对 132 条产品，数量根本不等）。


## 13. 没有产品图时，怎么切图纸

先判断图面有没有**文字层**：

```python
doc[0].search_for('LF-50-100')     # 有返回 = 矢量文字，可精确裁
len(doc[0].get_text())             # 只有图框字样（约 1200 字）= 栅格图，不可定位
```

| 情况 | 做法 |
|---|---|
| 有文字层 | 按编号定位，裁编号周边 200×150pt 窗口，一物一图 |
| 无文字层（本项目） | 退化到**区域级**：一个区域一张平面图 |

区域级裁切要点（`scripts/crop_drawings.py`）：

1. 右边界留 18% 给标题栏，裁掉；上下各留 2~3% 去掉图框线。
2. 用 `numpy` 按 `<245` 阈值收紧白边，避免大片空白占满单元格。
3. 同时输出 `_thumb.jpg`（260px）：**PIC 列只能放缩略图**，整图 1400px 放进去会让文件暴涨（194 行 × 400KB ≈ 77MB，实测过）。
4. 大图放 `DRAWINGS` 页，一行一个区域，宽 660px 可读。

**踩过的坑**：同一张图重复插入不会被自动去重，`all` 模式下 194 份全尺寸图直接把文件顶到 77MB。缩略图 13KB × 194 × 2 表 ≈ 5MB 可接受。
