# 常见坑（完整列表）

> 每轮收尾（SKILL.md 步骤 7）在末尾追加，编号连续，**不要重排既有编号**——SKILL.md 与其它文档里有「见坑 13」「见坑 21/22」这类交叉引用。写法统一为：现象 → 根因 → 修法。

1. **模板行号偏一行** → 表头清空 + 页脚错位。必须 XML 复核。
2. **辅助函数 `put()` 把 value 默认写成 None** → 复制样式时顺手清空内容。用 sentinel 区分「没传」和「要写空」。
3. **`footer_merges` 把明细区合并也收进去** → 插行后重新合并到错误行，报 `MergedCell object attribute 'value' is read-only`。只收 `min_row >= FOOTER_START`。
4. **`ws.add_image(pic,'C{r}')` 尺寸由 `pic.width/height` 决定**，不要用 reload 后的 `im.width`（openpyxl 会按单元格算出假值）。
5. **改 XML 后 `r:id` 退化成 `ns1:id`** → 需 `ET.register_namespace('r', rels_ns)`。
6. **`copy_worksheet` 不复制图片**，必须清空后按主表锚点重挂；logo 要按模板锚点的实际显示尺寸放（模板里 150×89），直接给原始像素会把 4377×772 的 logo 拉变形。
7. **术语表单字母词条（or/in/and）必须带 `\b`**，否则 `outdoor → outdo或`、`for → f或`。
8. **通用术语规则会先吃掉专有短语**，必须做 `_PRE` 预处理（`Leatherette` 先于 `Leather`）。
9. **`SUB-TOTAL` 常写在 F 列而不是 B/C 列**，不跳过会被当成一条产品。
10. **Strict OOXML 打不开**（`ExternalReference.__init__() missing 'id'` 或 sheet 数为 0）。
    文件用 `http://purl.oclc.org/ooxml/...` 命名空间，openpyxl 完全不认。跑 `scripts/strict2t.py` 换成 transitional 命名空间再读，同时剥掉 externalLinks。

11. **整段式描述不能按行拆**。
    有的 BOQ 把「Description / Size / Structure / Finishes / Note」全塞进一个单元格且换行被吃掉；有的分行写。两种都要吃得下：优先正则抽 Size 和饰面代号（ST-07 / MT03 / FB-50-03），原文整段保留到「规格说明」列，不要为了"好看"把长文截断。

12. **参考图片列可能是坏公式**。
    见过整列 `#VALUE!`（原来是 WPS DISPIMG 或 IMAGE 链接，导出后失效），zip 里 media 是孤儿文件、没有任何锚点。**没有锚点就不要按顺序猜图**，直接报告"图片列失效"。

13. **备注有两套来源，优先级要定死**：`remark_override`（调用方显式给）> `remark_of()`（自动扫缺口）。只改一处会导致英文表备注为空、中文表有字的错位。

14. **组合式品名不要硬塞词典**。`Lobby Sofa A` / `Round Dining Table for 2` / `Squsre Table Lounge` 这类是词根拼出来的，用「长短语优先 + 词根替换 + 保留尾部编号」的组合翻译，比逐个建条目可持续。注意 `TableA` 这种驼峰粘连，要先拆。

15. **`add_image(pic, 'C12')` 传字符串时改不动锚点。**
    此时 `pic.anchor` 还是 `'C12'`（str），要等到 `wb.save()` 才生成 OneCellAnchor。
    想让图片垂直居中 / 加内边距，必须自己构造：
    ```python
    marker = AnchorMarker(col=2, colOff=pixels_to_EMU(6), row=r-1, rowOff=pixels_to_EMU(off_px))
    pic.anchor = OneCellAnchor(_from=marker,
                               ext=XDRPositiveSize2D(pixels_to_EMU(w), pixels_to_EMU(h)))
    ws.add_image(pic)
    ```

16. **自检脚本自己也会错**：`print_area` 带 sheet 名前缀和 `$`、合并区子单元格 `font` 返回默认值、分区行中英本就不同——断言里都要排除，否则假 FAIL。

17. **短关键词误伤复合家具名**：「电视」把「电视柜」判成电器，「灯」把「床头柜」判成灯具。
    根因：品类词用子串 `in` 匹配，中文复合词没有词边界。
    修法：家具白名单必须**先于**非家具子类；再在 config 加 `keyword_exclusions`（如 `{"电视": ["电视柜"]}`），命中排除词时该关键词不生效。**自检脚本必须复用同一套优先级**，否则会造出假 FAIL。

18. **人工 override 写了却不生效**：S/N「装饰抱枕」明明改判为软装，结果仍落到「客房布草及运营用品」。
    根因：自动规则（布草排除）排在 `override` 前面并提前 `return`，「枕」把条目吃掉，改判形同虚设。
    修法：`override` 必须是 `classify()` 的**第一个**判断，任何自动规则都不能抢在它前面。

19. **家具厂供货 ≠ 家具**：床头吊灯、床下地毯、全身镜、化妆镜由家具供应商供货，被当成家具报进来。
    根因：拿「品牌 / 供应商」当品类判据。
    修法：品牌只作兜底；命中「家具供应商」但品类不是家具的，单列「其他（家具厂供货但非家具）」并标待确认，不静默并入家具。

20. **集成功能词把家具判成灯具**：床头软包靠垫名称含「LED 阅读灯 / LED 灯带」，被归到灯具电气。
    根因：对整段名称做关键词匹配，把「集成功能」当成了「品类」。
    修法：家具白名单优先 + 对该条加 override 写明理由 + 说明页列待确认。

21. **drawing 路径解析不到图片**：`xl/drawings/drawing1.xml` 读不到，或 media 路径拼错。
    根因：sheet rels 的 Target 可能是 `../drawings/drawing1.xml`、也可能是 `/xl/drawings/drawing1.xml`；drawing rels 的 Target 又相对 `xl/drawings/` 写成 `../media/image1.png`。直接字符串拼接必错。
    修法：统一 `posixpath.normpath(posixpath.join(dirname, target))`；绝对路径先 `lstrip('/')`。

22. **`twoCellAnchor` 正则漏匹配，一张图都取不到**：xml 里标签有的带 `xdr:` 前缀、有的不带。
    根因：Excel / WPS 不同导出工具生成的前缀不一致。
    修法：正则里所有标签写成 `(?:xdr:)?twoCellAnchor`、`(?:xdr:)?from`、`(?:xdr:)?row` 等。

23. **源表照片压在文字列上、一行两张，第二张被写成备注**。
    根因：`twoCellAnchor` 跨行显示，原版面不可直接打印；旧做法只取第一张、把第二张路径塞进备注。
    修法：按锚点起始行把图片归位到「照片」列；`place_pics()` 支持 1~N 张竖排，行高按**图片总高度**反推（`≥ 总px × 72/96 + 6pt`）并垂直居中。

24. **自检脚本 5 类假 FAIL**（新增拆分表自检时一次踩全）。
    根因：断言比解析规则更严，或用错 openpyxl 的返回值。
    修法：
    - 品类残留检查必须复用解析的分类优先级（家具白名单 + 备注豁免）。
    - 源表允许空名称行，前提是备注写明推定依据；只检查「有没有说明」，不要一律禁空。
    - 数量列允许数字串、带单位/多行面积说明（`40㎡（不包含损耗）`、`墙面2.16㎡\n地面6㎡`）；只拦 `'-'` / `'TBC'` 这类非数字开头且无单位的脏值。
    - `print_title_rows` 返回 `'$1:$3'` 而非 `'1:3'`，比较前 `replace('$', '')`。
    - 判定前先分清「数据缺陷」还是「断言过严」：假 FAIL 修脚本，**绝不为了过审改源数据**。

25. **长产品名称溢出覆盖参考图片列**（中文报价模板输出，用户 2026-11-20 点名要求修）。
    现象：B 列品名最长 29 字（如「L型沙发区圆桌椅子 T-0A / 书桌椅CU21 T-0B」），列宽只容约 12 个中文字；模板明细行 `wrapText=None`，文字横向溢出到 C 列压住产品图。
    根因：模板明细样式的 alignment 不带 `wrapText`，`style_from()` 原样复刻就把这个缺陷一起带进来了。
    修法：输出时给名称列明细格强制 `wrap_text=True`（`copy.copy(alignment)` 后只改 wrapText，center/center 沿用模板）；并验算折行后所需高度（显示宽度÷列宽取整行数 × 14.5pt + 余量）≤ 行高，行高不够要撑行。自检固定两处：①名称列明细 `wrap_text` 全 True；②折行后行高足够。源表本身的名称列若已设 wrap 则不动。

26. **配置化自检把 overrides 单元格判成「表头与模板不一致」（假 FAIL）**。
    现象：表头比对报 3 处差异，正好是 D1 / M6 / A8 这些按项目改过的抬头、项目名、时间。
    根因：自检用 `openpyxl.utils.coordinate_from_string` 解析 overrides 坐标，该函数在部分版本不在顶层导出，异常被 `except` 吞掉，排除集合为空。
    修法：自己用 `re.match(r'^([A-Z]+)(\d+)$', coord.upper())` + `column_index_from_string` 解析；**别吞异常**，解析不出来要显式报错。这类属脚本问题，修脚本，不动源数据。

27. **FFE 尺寸列写法不统一，一行一个格式**：同列里混着 `400W x 320D x 380H`、`Dia 500 x H680`、`L2800 x W1000 x H750`、`47" x 24" x 30"`、`1.2 x 0.8 x 0.75 m`。
    根因：设计方每家模板不同，且同一家不同 sheet 也不一致。
    修法：`norm_size()` 统一处理 —— 先 `×`/`*`→`x`、`"`→`inch`、换行转 ` / ` 再切段；**在段内**找最近标签（不是全文搜，否则 `Top Dia 500` 会吃到相邻字段的 `Height`）；槽位 W/D/H 不覆盖，`L` 占 W 时 W 退 D；`cm > 300` 判为 mm 误写，保留数值标红。

28. **中文表机械翻译出垃圾**：`pedestal 桌`、`镜面饰面镜面ed`、`Tex瓷砖布艺`、`Synthetic 黑色大理石台面`。
    根因：FFE 品名里混品牌与系列名（`Wilkhahn Graph`、`Samba Bar Chair / Lusso Spruce Velvet`），术语表按词替换会把半个词换成中文；材质列更严重，面料牌号根本不该译。
    修法：**品名逐条写 `overrides.*.name_zh`**（数量少时人工最快最准）；材质/单位/页脚保留原文，加两个开关 `zh_keep_material` / `zh_keep_remark`。自检只查第 2 列且允许 ≤3 个英文词（品牌/型号），别去查材质列。

29. **PDF 表格按 y 聚类会整行错位**：TAG 文字在单元格里垂直居中，按 bbox 上下边聚合就归到上一行或下一行。
    根因：FFE 表格的 TAG 列是合并单元格，文字 y 在整条中间，不在首行。
    修法：「先按列 x 分桶拿单元格文本 → 归到**最近的 TAG 行**（比较单元格中心 y 与相邻 TAG 行 y 的中点）」。图片同理，用 bbox 与 TAG 行的 y 区间重叠度归行。

30. **同一项目多份 FFE 表表头位置不一致，复用同一套 `cols` 会错列**：合并总表 / 家具分表 / 核算版看起来一样，实际品名列、尺寸列错位；有的表把品名写在 AREA 列。
    根因：设计方分表是分别导出的，列顺序没对齐。
    修法：每份源文件单独给 `cols`；品名位置用 `name_from` 指定（`desc` / `area` / `code`）。别想着写一个通用列识别器。

31. **构建脚本最后一行统计「图片 0 张」，但实际图片都贴上了**：`len(imgs)` 只统计旧图片通道（从源表抽图），FFE 支路的图片走 `items[].img`，计数为 0。
    根因：统计口径没跟着新增的数据通道更新，容易误判成贴图失败。
    修法：统计改成 `sum(1 for i in items if i.get('img')) or len(imgs)`；核实真相用 `zipfile` 数 `xl/media/` 张数（含 logo，EN+ZH 两表各一份）。

32. **PDF 续页的第一条被整行吃掉，产品数莫名少几条**（某项目 吧台区域 5 条只出 4 条）。
    现象：`pages: [6]` 只取到 4 条，FU5 在续页第 7 页顶部；把 `[6,7]` 加上后 FU5 出来了但字段全空。
    根因：PDF 解析为了丢页头写死 `body = [b for b in body if b[1] > 200]`。首页页头 + 表头约占 200pt，但**续页没有页头**，TAG 直接从 y≈108 开始，整行被阈值切掉。
    修法：改成按关键词算表头下沿 —— `hdr_kw` 匹配 `项目名称 / E-mail / FURNITURE SCHEDULE / PROJECT: / DATE: / TO: / ADDRESS: / TAG / LOCATION / … / REMARKS / Reference`，只取 `y1 < 260`（防止页面底部重复的列标题把阈值拉到页尾），`hdr_bot = max(y1)+2`，无表头则 0。**同理适用于所有「表格跨页」的 PDF**，看到条数比源文件少先去数 TAG 总数。

33. **PDF 里相邻段落的文字串进上一条 FU 的材质列**（FU5 宴会桌的材质末尾出现冰箱的 `Product Power Type`）。
    根因：归行用「最近 FU 标签 + 95pt 距离阈值」，而 `tags` 只收了 FU。FU5 在 y=108、下一段 WHITE GOODS 的 WG1 在 y=244，WG1 的描述从 y=187 起算，距 FU5 只有 79pt，落进阈值内。
    修法：**用本页全部条目 TAG（FU/WG/FT/EQ/FX/DH/FN）做中点划界**，取到 owner 后只保留 owner 是 `FU` 的块；别用「最近 FU + 阈值」。验收方式：改前改后逐条对比 `desc/color/size/access/supplier`，只应变动目标条目，其余零差异。

34. **按段名排除会把该做的品类一起排掉**（`WHITE GOODS` 里既有冰箱也有马桶，`EQUIPMENT` 里既有炸炉也有不锈钢工作台）。
    根因：FFE 的分段是设计方按「设备大类」分的，不是按「谁供货」分的，段名跟供货范围不对应。
    修法：范围判定落到**条目**，用 `skip_tags` 精确列要排除的 TAG；判定口径用「通不通电」而不是段名。排除项要在交付说明里逐类列出来。

35. **洁具/五金的 SIZE 列是型号或整段参数，拆成三维会造出假尺寸**（`LCN 1460T` → 1460×864×965，`32 Gallon` → 1×27×3，`12" spout` → 12700mm）。
    根因：`norm_size()` 只认数字和单位，把型号里的数字、容量、管径都当成了宽深高。
    修法：`ffe.size_raw_prefix` 默认 `["FN","FT","DH","FX"]` —— 这几类原文直出规格列、不拆三维。规格文本超过 40 字或是整段参数（水压范围、流量、包装尺寸）的，移进备注 `[size: …]`，别塞进规格列撑爆行高。

36. **红字覆盖率失控，136 条里标红 63 条**：源文写着 `Refer To Detail`、`Check Plans for measurements`、`size TBC` 的都被当成缺陷标红。
    根因：把「源表没给尺寸」和「源表数据矛盾」混成同一类。
    修法：`norm_size()` 返回的 flags 用 `~` 前缀区分 —— 带 `~` 的是软提示（源文本来就没给），只记 `size_note`、不写备注不标红；不带 `~` 的才是硬错误（cm/mm 误写、尺寸列填 `Yes`），标红留痕。健康值：红字占比 5% 左右。

37. **同节 TAG 撞号导致参考号重复**（两张表都编 FN13，一条是木线条、一条是墙纸）。
    根因：不同设计文件各自从 1 开始编号，合并到同一节就撞了。
    修法：`fix_dup_sn()` —— 同 `(label, TAG)` 且描述、部位都相同的**整行重复直接丢弃**（源表重复录入）；描述不同的加字母后缀 `FN13B`，overrides 用加后缀后的键。改完一定要看 `parsed.json` 里有没有多出来的 `xxx B` 条目还没配中文名。

38. **节标题缺 `zh` 键导致 `KeyError: 'zh'`**：重写 config 的 `sections` 时只写了 `src` / `en`。
    根因：中文子表要逐个节标题取 `payload['zh']`，缺键就在 build 阶段崩。
    修法：`sections` 每项必须同时给 `src` / `en` / `zh`；改配置后用 `json.load` + 遍历校验三键齐全，再跑 build。

39. **带项目前缀的 TAG 判断类别失效**（`PT-DH1` 用 `sn.startswith('DH')` 是 `False`）。
    现象：同一批门五金，L16 那批走原文直出正常，首层公卫 `PT-DH1` 又被拆成 `1460×864×965`。
    根因：设计方给 TAG 加了项目前缀（`PT-`、`某项目-`），`startswith` 只能匹配无前缀的写法。
    修法：用正则取**末尾那段字母** —— `re.search(r'([A-Z]+)\d+[A-Z]*$', sn)`，`PT-DH1` → `DH`、`FN13B` → `FN`。
    另一处同理：`build_quote.py` 在 `size_text` 为空时会回退去 `size_cells()` 拆原文，必须靠 `size_raw` 标记拦住，否则解析层改对了、成品还是假尺寸。**改完必看成品单元格，不能只看 parsed.json。**

40. **报价范围含门五金/洁具时，模板页脚免责条款会打自己脸**：模板第 1 条明写「以上报价不含…门控五金（门锁、拉手、闭门器、合页、猫眼、防盗扣、链、…门吸…）」。
    根因：页脚是通用免责文案，按「只做家具」写的，范围一改就对不上。
    修法：**不要擅自改模板文案**（模板是共享文件，影响所有项目）——在交付正文里明确提示这条冲突，让用户决定是否改条款。核对清单：范围含门五金 → 查第 1 条；含石材/皮布 → 查第 2 条的材料限价。

41. **图纸项目最大的坑：以为有清单，其实只有效果图**（某海外项目：13 个文件全是 PDF/DWG/JPG，65 页里只有 1 页平面图）。
    现象：用户说「整理这个清单」，打开目录发现没有 Excel、没有规格书。
    修法：先按 `步骤 0` 全量勘察再动手，别先写代码。判定顺序：有 xlsx 清单 → 走 BOQ/FFE 支路；只有平面图+效果图 → 走 `步骤 2e`。开工前必须跟用户确认「就从图纸整理 / 还有清单要发 / 只出房型配置模板」。

42. **一页 CAD 平面图上家具名能提取、尺寸提取不到**。
    现象：`get_text('words')` 只拿到 `wardrobe`、`bed`、`side table`，1025、900、2200 这些数字一个都没有。
    根因：CAD 导出 PDF 时尺寸标注被打散成线条路径，不再是文字对象。
    修法：家具名用文字层（按 x 分列、y 排序还原阅读顺序），**尺寸只能放大人工读图**。渲染 150dpi 再裁切放大 1.5–2 倍，读得清。

43. **平面图页面带 90° 旋转，文字坐标看起来是乱的**。
    现象：`page.rect` 是 842×595，但文字 y 到 780，每个词单独一个坐标、字距很大。
    根因：页面 `/Rotate 90`，Word 的 bbox 是未旋转坐标系，且竖排文字被逐字拆开。
    修法：`round(x/8)` 分列 + 列内按 y 递增排序，就能还原「从左到右」的家具顺序；相邻 y（差 <22）的词合并成短语（`Luggage rack+ mirror` 是 3 个词）。

44. **效果图充当产品图会误导客户**。
    现象：把整间房的室内渲染图放进 PIC 列，客户会以为那是某件家具的实拍。
    修法：每节只放**首条**一张房型效果图作视觉锚点，并在该条 REMARK 写 `PIC shows room rendering, not single-product photo`；其余条目留空，交付说明写清「资料为效果图，无单件产品图」。

45. **`parsed.json` 里写 `remark` 不生效，必须写 `remark_override`**（坑 13 的复现）。
    现象：备注列全空，但 parsed.json 里 `remark` 明明有值。
    根因：`build_quote.py` 取 `it.get('remark_override') or remark_of(it)`，`remark_of` 只产 TBC 提示，从不读 `it['remark']`。
    修法：生成 parsed.json 时同时写 `remark` 和 `remark_override`。另：没有参考号会补 `no IF ref`、缺尺寸会补 `size TBC`，想干净就得把 `ref` 和 `size_mm` 也填上。

46. **中文表的材质和备注整列是英文**（只看 `zh_keep_material: true` 就交差）。
    现象：品名中文、尺寸数字，但材质列 `Oak veneer, integrated full-height mirror` 原样搬过去，客户看不懂。
    根因：`zh_keep_material / zh_keep_remark` 的本意是「保留牌号/供应商不要机械翻译」，不是「整列不翻」。
    修法：`parsed.json` 里给 `material_zh` / `remark_zh`（`items.json` 用 `materials_zh` / `rm_zh` 按方案给），`build_quote` 中文表优先取这两个字段；只保留技术牌号（Polytec、LCN 1460T、Caroma Liano II）原文。

47. **三维尺寸只填了宽深，高度整列空着**。
    现象：平面图只标 W×D（衣柜 2270×600、床 2100×2200），高度没标，成品 H 列全空。
    根因：平面图是水平剖面，本来就没有高度信息。
    修法：按家具常规高度补（桌 750、床头柜 550、床架 450、床头板 1100、衣柜/墙板 = 吊顶 − 400、马桶 750、浴缸 550、淋浴 2000、地毯 12），并用 `Ceiling_Height_Schedule` 交叉校验；交付说明必须写「高度为常规值，非图纸标注」。**别留空**，留空客户没法报价。

48. **一套方案的裁图坐标直接套到另一套方案**（OP1 的 p1 是衣柜，OP2 的 p1 是走廊）。
    现象：OP2 裁出来是走廊/白墙，不是产品。
    根因：两套方案虽然同一位设计方，但页序不同（有的把电视柜放 p2、衣柜放 p3）。
    修法：每套方案先渲染全部页面拼缩略图，逐页确认内容再定位坐标；同一房型内可复用同一页裁多件（衣柜页顺带裁迷你吧）。
