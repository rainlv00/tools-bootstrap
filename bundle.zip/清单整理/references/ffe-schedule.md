# FFE Schedule 支路（设计方清单 → 我方英文报价模板）

适用：客户/设计方给的 **FFE Schedule**（Furniture, Fixtures & Equipment 表），按 `TAG | LOCATION | AREA | IMAGE | PRODCUT CODE DESCRIPTION | COLOR FINISH | UNIT SIZE | ACCESSORIES | QTY | SUPPLIER | REMARKS` 排布，按 `FURNITURE / EQUIPMENT / WHITE GOODS / FIXTURES / DOOR HARDWARE` 全大写分段。
样例配置：`assets/config.ffe.sample.json`。

```bash
python scripts/parse_ffe_schedule.py --config _work/config.ffe.json   # 抽条目 + 抽图 + 尺寸规范化
# 复核 parsed.json：无名称 / 无尺寸 / 无图 / 红字待确认 四类逐条过一遍，需要改的写进 overrides
python scripts/build_quote.py        --config _work/config.ffe.json   # 复用报价模板支路，不另写一套
python scripts/selfcheck.py          --file out.xlsx --expect-items N
```

三个动作共用**同一份 config**：`ffe` 节管解析，顶层管模板与文案。

## 1 先判定范围（必须问用户，别自己砍）

**默认「除电器全收」**（2026-11-20 用户明确口径）：做活动家具 + 固装家具 + 洁具 + 门五金 + 厨房不锈钢台架，只排除通电设备。

| 段 | 典型内容 | 默认 |
|---|---|---|
| `FURNITURE` / `FURNITURE/ FITTINGS` | 桌椅、沙发、床、行李架、定制镜 | 做 |
| `JOINERIES` | 衣柜、吧台、橱柜、电视墙、床头板、石材/人造石台面、玻璃、墙纸、黄铜嵌条 | 做（固装） |
| `FIXTURES` | 马桶、花洒、龙头、浴室镜、扶手、淋浴门、拉手 | 做 |
| `HARDWARE` / `DOORS HARDWARE` | 门锁、闭门器、门吸、合页、门镜、防盗链 | 做 |
| `EQUIPMENT` | 炸炉、烤箱、冷柜、洗碗机（不做）／水槽、工作台、置物架（做） | **逐条判** |
| `WHITE GOODS` | 冰箱、电视、灶台、微波炉、咖啡机、干手器（不做）／马桶、龙头、皂液器、垃圾桶、熨衣板（做） | **逐条判** |
| `LIGHTING` / `ELECTRICAL` | 灯具、开关插座 | 不做（不是家具，单独说明） |

判定口径是**通不通电**，不是段名。`WHITE GOODS` 里既有冰箱也有马桶，只能按条目逐条判，用 `skip_tags` 精确列。

- 「由家具厂供货」≠「是家具」。存疑的（定制全身镜、行李架、活动隔断）**列入主表但标红待确认**，或问用户拍板。
- **只存在于 PDF 的条目也要收**：同一项目常是「xlsx 主体 + PDF 补充页」。先比对 TAG 集合，确认 xlsx 是否为并集；PDF 独有的条目单列一节。
- 数量：源表有值就填，没有就留空（不要按图纸估）。有的项目数量只在「核算图纸量」附属表里，用 `qty_source` 回灌。
- **交付报告要写清范围**：哪几类纳入、哪几类排除、为什么，客户核源表才对得上。

## 2 源文件类型

| `type` | 必填键 | 说明 |
|---|---|---|
| `xlsx` | `file` `sheet` `start_row` `cols` | `cols` 是 **字段名 → 列号** 映射（1 起），换客户表只改这里 |
| `pdf` | `file` `pages` | 按列 x 分桶还原表格，需 `pymupdf` |

公共键：

| 键 | 作用 |
|---|---|
| `label` | 内部区域名，与顶层 `sections[].src` 对应，决定分节顺序 |
| `slug` | 图片文件名前缀，如 `L15CONF` → `L15CONF_FU2.jpg` |
| `name_from` | 品名取自哪列：`desc`（常规）/ `area`（该表把品名写在 AREA 列）/ `code` |
| `groups` | 分段白名单，**子串匹配**（`"FURNITURE"` 也能命中 `FURNITURE/ FITTINGS`）；`[]` 表示整表都收 |
| `skip_tags` | 按 TAG 精确排除，**排除电器只能用这个**；同一 sheet 可以拆成多个 source，各自给不同 `groups` + `skip_tags` + `label` |
| `skip_name_re` | 按品名正则排除，TAG 编号不稳时用 |
| `group` | PDF 用，单值 |

两个全局键（`ffe` 级）：

| 键 | 作用 |
|---|---|
| `dedupe` | 跨工作表按「前缀 + 品名指纹」合并同一产品；**同表内不合并**（FU1/FU14 都叫 Dining Table 可能是两张不同桌子） |
| `size_raw_prefix` | 这些前缀的 SIZE 是型号/材料规格，原文直出规格列、不拆三维。默认 `["FN","FT","DH","FX"]` |

**同一个项目里各表列位经常不一致**：合并总表、家具分表、核算版三份表头看似相同，实际品名/尺寸列会错位。逐份打印第 1–2 行表头核对，别复用同一套 `cols`。

## 3 解析规则（脚本已实现，改逻辑前先读这段）

1. **分组行识别**：`^[A-Z][A-Z0-9 &/.\-]{2,}$` 且不含数字 → 视为分段标题；命中 `groups` 白名单才取下面的行。全大写品名（如 `BAR STOOL`）会被误判，靠「必须单独占行、且下一行是数据行」二次确认。
2. **TAG 为空的行并入上一条**：FFE 常把一个 SKU 的名称/材质拆成两三行写。判据是同 TAG 或 TAG 空 + 该行无尺寸、无数量。
3. **条目结束**：遇到下一个 TAG、下一个分组行、或连续两行空行。
4. **PDF 归行**：TAG 文字**垂直居中**于整条，按 y 聚类会把 TAG 分到上一行或下一行。做法是「先按列 x 分桶 → 取每个单元格文本 → 归到**最近的 TAG 行**」（比较 bbox 中心 y 与各 TAG 行 y 的中点）。
5. **PDF 图片**：`page.get_image_info(xrefs=True)` 拿 bbox，按 bbox 与 TAG 行 y 区间重叠度归行，不按顺序数。
6. **xlsx 图片**：`zipfile` + `sheet_xml_path()` + `drawing_media_map()` 读锚点行；`oneCellAnchor` / `twoCellAnchor` 都要支持，标签前缀 `(?:xdr:)?`。详见坑 21/22。
7. **尺寸规范化** `norm_size()`：见下节。
8. **红字**：`flag` / `material_add` / `remark_add` 非空即在 REMARKS 列红字加粗，**不改源数值**。

## 4 尺寸写法与规范（坑最多的一段）

源表同一列里混着这些写法，必须逐条规范化成 `W / D / H` 三个数字（mm）：

```
400W x 320D x 380H        W400 x D320 x H380        400 x 320 x 380
Dia 500 x H 680           Ø900 x 750H               L2800 x W1000 x H750
1050 x 150 x 720 (mm)     1.2 x 0.8 x 0.75 m        47" x 24" x 30"
W 400 / D 320 / H 380     Height 750, Width 2800
```

规则：

1. 统一 `×` `*` → `x`；`"` → `inch`；换行先转成 ` / ` 再切段。
2. **先按分隔符分段，再在段内找「最近标签」**。跨字段搜标签会把 `Top Dia 500` 的 before 窗口吃到相邻字段的 `Height`。
3. 槽位 W / D / H **不覆盖**：只有长度不标 L 时，第 1 个数给 W；出现 `L` 时 `L` 占 W、`W` 退 D；`Dia` 给直径位（输出仍写进 W，D 留空）。
4. 单位：`mm` 默认；`cm` / `m` / `inch` / `in` / `"` 换算。`cm > 300` 视为 mm 误写（如 `500 x 500` 写成 cm），保留数值并标红。
5. 源文本**确实没有数字**的（`size TBC`、`Details as per specs`）→ 三维留空，REMARKS 写 `size TBC`。**不要用同类产品中位数估填。**

**但 `FN` / `FT` / `DH` / `FX` 四类不要拆三维** —— 它们的 SIZE 是型号或整段参数，硬拆会造出假尺寸：`LCN 1460T` → `1460×864×965`、`32 Gallon` → `1×27×3`、`12" spout` → `12700mm`。这几类走 `size_raw_prefix`：

- 长度 ≤ 40 字符且含数字 → 原文放规格列（`3mm thk`、`1220 x 3050mm`、`670 X 440 X 200`）
- 超过 40 字符或没有数字 → 移进备注 `[size: …]`，规格列留空，避免撑爆行高
- 源文是 `refer to details` / `See drawings for measurements` → 规格列写 `TBC (see drawings)`
- 源文是 `Yes` / `TBC` 这类非尺寸值 → 清空 + 标红，备注写 `[source size field reads: Yes]`

红字分两级：`~` 前缀的是**软提示**（源文本来就没给尺寸），只记 `size_note`、不写备注不标红；不带 `~` 的才是**硬错误**（cm/mm 误写、尺寸列填 `Yes`），标红留痕。健康值：红字占比 5% 左右，超过 20% 说明把「没给尺寸」也当成了缺陷。

## 5 `qty_source`：从附属表回灌数量

```json
"qty_source": { "type": "xlsx", "file": "...", "sheet": "核算图纸量",
                "tag_col": 1, "qty_col": 9, "start_row": 4, "overwrite": false }
```

按 TAG 匹配回灌，`overwrite: false` 时不覆盖已有值。同一 TAG 在多个区域出现时，只在第一个命中区域落值。

## 6 `overrides`：人工改判（键 = `区域|TAG`）

```json
"overrides": {
  "L15 CONFERENCE|FU1": {
    "name": "Pedestal Table",       // 覆盖品名（源品名列放的是面料名/规格说明时必填）
    "name_zh": "圆几（黑大理石台面）",  // 中文表品名，必须逐条给，不走机械翻译
    "material_add": "…",            // 追加到材质列
    "remark_add": "…",              // 追加到 REMARKS（红字）
    "qty": 14,                      // 覆盖数量
    "flag": "尺寸与 TAG 矛盾"        // 只标红，不改数值
  }
}
```

**中文表品名一律逐条手写 `name_zh`**。FFE 品名里混着品牌、系列、面料名（`Wilkhahn Graph`、`Sasso`、`Samba Bar Chair / Lusso Spruce Velvet`），术语表机械替换必然出 `pedestal 桌`、`镜面饰面镜面ed` 这类垃圾。材质、单位、页脚**保留原文**（`zh_keep_material` / `zh_keep_remark` 置 `true`），面料牌号翻译失真比留英文更糟。

## 7 已知源数据缺陷的标准处理

| 现象 | 处理 |
|---|---|
| 尺寸与 TAG/名称矛盾（`4000x1400 会议桌` 却写 1050x150x720） | 数值照抄，`flag` 标红写矛盾点 |
| 单位写错（mm 写成 cm） | 按 mm 解读，`flag` 说明 |
| 品名列放的是面料名 / `Details as per specs` | `name` 覆盖，原文进 `material_add` |
| 同一条目名称跨两行粘连 | 解析时并入上一条，`name` 覆盖为可读名称 |
| TAG 一号多用（FU110 同时是 5 个 SKU） | 按 `区域|TAG|行号` 区分，**不能只按 TAG 去重**，否则吃掉 SKU |

## 8 自检要点

`scripts/selfcheck.py` 27 项通用，FFE 支路额外盯三处：

- `--expect-items N` 必须等于解析条数；分节数等于 `sections` 长度。
- `08 尺寸列格式`：非数字必须为 0 处。规格文本（含字母且含数字，或 `TBC (see drawings)` 这类）算正常，会单独计数；空尺寸条数记下并在交付正文说明原因。
- `15 中文表品名已译`：只查第 2 列，允许 ≤3 个英文词（品牌/型号），材质列不查。
- 红字占比：看 `11 字重统一` 的「红字豁免 N 格」，明显偏高说明软提示被当成了硬错误。
