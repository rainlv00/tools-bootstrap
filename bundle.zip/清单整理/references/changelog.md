# 版本记录

> 每轮收尾（SKILL.md 步骤 7）在顶部加一条。最新在最上面。

## 模板

```
## vX.Y — YYYY-MM-DD ｜ 项目代号
- 新增：
- 修复：
- 影响：自检 N 项 / 脚本 N 个 / 下个项目是否需要改脚本
```

---

## v2.2 — 2026-11-23 ｜ 技能再改名「清单整理」

- **改名**：`清单资料整理` → **`清单整理`**（目录名、`name` 字段、正文示例、zip 包名同步；`hotel-furniture-pricing` 两处交叉引用已更新）。
- 旧名保留为 description 里的触发词别名，说「清单资料整理」仍能命中。
- 影响：自检 27 项 / 脚本 15 个 / 30 个文件，逻辑无改动。

---

## v2.1 — 2026-11-23 ｜ 技能改名「清单资料整理」+ 一句话可用

- **改名**：`hotel-furniture-quotation` → **`清单资料整理`**（目录名、`name` 字段、交叉引用全部同步；`hotel-furniture-pricing` 里的 3 处引用已更新）。
- **一句话可用**：SKILL.md 新增「一句话怎么用」，给出四种典型说法与对应支路；步骤 1 补「默认口径表」——用户说「按默认」或干脆不说，就按默认做，只有两种情形必须追问（资料无任何范围线索、房量歧义会让总价差一个数量级）。
- **description 重写**：中文优先，覆盖 25 个触发词 + 四类输入 + 三种产出，便于只凭一句话命中。
- 影响：自检 27 项 / 脚本 15 个 / 30 个文件；改名后用 某海外项目 项目全链路回归，86 条 / 75 图 / 27-27 通过。

---

## v2.0 — 2026-11-22 ｜ 技能整理（瘦身 / 术语 / 脚本固化）

- **SKILL.md 瘦身**：499 → 332 行。48 条「常见坑」整体迁到 `references/pitfalls.md`，SKILL.md 只留索引 + 高频三条。每次会话加载的 token 少了一半。
- **glossary.py 整理**：
  - 删掉重复的 `translate_material` 定义（曾定义两次，后者覆盖前者，容易改错地方）。
  - 补 FFE / 图纸支路高频词：材质 40 条整词短语（oak veneer / fluted / bed base / linen weave / cut-pile / freestanding / wall-faced pan / soft-close seat …），品名 30 条（luggage rack with mirror / tv cabinet with wall panelling / bar counter with bar chair …）。
  - 效果：`Oak veneer, integrated full-height mirror` 从「橡木木饰面，integrated full-height 镜面」变成「橡木饰面，一体式通高穿衣镜」；`Wall-faced pan, soft-close seat` 从「Wall-faced pan，soft-close seat」变成「壁挂式座便器，缓降盖板」。
  - 注意：`seat` 这类短词必须排在 `soft-close seat` 之后，否则拆坏专有短语（坑 7/8 的复现）。
- **新增 `scripts/crop_from_pdf.py`**：从效果图 PDF 按比例坐标裁单件，并按 `(section, name)` 自动挂回 `parsed.json` 的 `img`。job 文件里 `page` **从 1 开始**（避免 0-based 的误读）。
- 文档同步：`maintenance.md` 的记坑位置改到 `pitfalls.md`；支路数 3 → 4。
- 影响：自检 27 项 / 脚本 15 个 / 四条支路共用一份 config。整理后 glossary 用本项目 12 条材质 + 22 条品名做了回归，BOQ 老用例 7/8 一致（第 8 条是测试期望值本身写错）。

---

## v1.9 — 2026-11-22 ｜ 某海外项目 修订（中文材质/高度/房量/产品图）

- 新增：
  - `build_from_items.py` 支持 `materials_zh`（按方案）、`rm_zh`、`pic_note` / `pic_note_zh`、`sections[].room_count`（数量自动 = 单间件数 × 房量）。
  - `build_quote.py` 中文表材质优先取 `material_zh`（`zh_keep_material` 降级为兜底）。
  - 图纸支路补全：高度按家具常规值补、房量从总平面图逐间数、产品图从效果图裁单件后用 `fill_images.py` 挂回。
  - 坑 46–48：中文表材质备注整列英文、三维只填宽深、跨方案套用裁图坐标。
- 影响：自检 27 项 / 脚本 14 个；本项目 86 条 6 节、75 张产品图，跑通 27/27。

---

## v1.8 — 2026-11-22 ｜ 某海外项目（海外，图纸项目）

- 新增支路 **步骤 2e — 图纸项目（无电子清单）**：资料只有平面图 + 效果图时，清单人工整理成 `items.json`，用新脚本转 `parsed.json` 后走通用出表与自检。
  - `scripts/build_from_items.py` —— `items.json` → `parsed.json`。房型可被多个节复用（设计方案 / 楼层），材质按 `scheme` 从 `materials` 取。
  - `assets/items.sample.json` —— 结构样例。
  - 尺寸只抄图面标注，缺的写 `null`（自动补 `size TBC`）；效果图只在每节首条作锚点并注明「非单件产品图」。
- 新增：
  - 坑 41–45：图纸项目别先写代码、CAD 平面图尺寸不在文字层、页面 90° 旋转的坐标还原、效果图别当产品图、`remark_override` 才是备注入口。
- 影响：自检 27 项 / 脚本 14 个 / 四条支路共用一份 config。本项目 86 条 6 节跑通 27/27。

---

## v1.7 — 2026-11-20 ｜ 某海外项目（范围口径修订：除电器全收）

- **口径变更（用户明确）**：FFE 支路从「只做家具」改为「**除电器全收**」——活动家具 + 固装 `JOINERIES`（衣柜/吧台/橱柜/电视墙/床头板/石材台面/玻璃/墙纸/黄铜嵌条）+ 洁具 `FIXTURES` + 门五金 + 厨房不锈钢台架。只排除通电设备（冰箱/电视/烤箱/灶台/洗碗机/油烟机/微波炉/咖啡机/洗烘机/干手器）。判定标准是**通不通电**，不是段名。
- 新增：
  - `ffe.sources[].skip_tags` / `skip_name_re` —— 按 TAG 或品名精确排除。`WHITE GOODS` 段里马桶要做、冰箱不做，只能逐条排。
  - `ffe.dedupe` —— 跨工作表按「前缀 + 品名指纹」合并同一产品；同表内不合并（同表两行 `Dining Table` 可能是不同房型的桌子）。
  - `ffe.size_raw_prefix`（默认 `["FN","FT","DH","FX"]`）—— 这几类 SIZE 是型号/材料规格，原文直出规格列，不拆三维。超过 40 字或无数值的转备注 `[size: …]`。
  - `fix_dup_sn()` —— 同节 TAG 撞号：整行完全重复直接丢弃，描述不同的加字母后缀 `FN13B`。
  - 红字拆两级：`~` 前缀是软提示（源文没给尺寸），只记 `size_note` 不标红；不带 `~` 才是硬错误。
  - 同一 sheet 拆多个 source（不同 `groups` / `skip_tags`，同 `label` 合并为一节）。
  - 坑 34–40：段名不可用于判范围、洁具型号被当尺寸、红字覆盖率失控、同节 TAG 撞号、`sections` 缺 `zh` 键崩溃、带前缀 TAG 判断失效、页脚免责条款与范围冲突。
- 修复：
  - `selfcheck.py` 第 08 项由「尺寸列必须为数字」改为「尺寸列格式」——允许规格文本（含字母 + 数字，或 `TBC (see drawings)`），否定式拦纯数字文本与占位符。
  - `build_quote.py` 支持 `size_text`（规格原文直出）与 `sections[].zh` 校验路径。
- 影响：自检 27 项 / 脚本 13 个 / 同类项目只改 config 即可。样本从 39 条扩到 **151 条（8 节）**，全文跑通 27/27。
- 修正（收尾自查发现）：`某项目 Public Toilet Furn Fixt`（首层公卫，TAG 带 `PT-` 前缀）整表漏掉，补为 SECTION 3；`size_raw_prefix` 改按末尾字母段匹配，`build_quote` 加 `size_raw` 防回退。

---

## v1.6 — 2026-11-20 ｜ 某海外项目（设计方 FFE Schedule 支路）

- 新增：
  - **支路 2d**：`scripts/parse_ffe_schedule.py` —— FFE Schedule（xlsx + PDF 双源）→ `parsed.json`，含抽图、尺寸规范化、数量回灌、人工改判。
  - `references/ffe-schedule.md`：源文件类型、字段映射、尺寸写法清单与规范化规则、`qty_source`、`overrides` 键位、6 类源数据缺陷的标准处理。
  - `assets/config.ffe.sample.json`：可直接照抄的 FFE 支路样例。
  - SKILL.md：步骤 2d、何时使用加 FFE、脚本表 12→13、FFE 配置开关表、常见坑 27–31。
- 修复：
  - **PDF 续页第一条被页头阈值吃掉**（吧台区域 FU5 丢失）：`y > 200` 写死改为按表头关键词算 `hdr_bot`，续页无页头时不裁剪。
  - `norm_size()` 标签窗口跨字段（`Top Dia 500` 的 before 吃到相邻 `Height`）→ 改「先分段、段内取最近标签」。
  - 多行尺寸串未被切开：split 正则的 `\s*` 把换行吞了 → 分段前先 `re.sub(r'[\n\r\t]+', ' / ', s)`。
  - `'inch'.replace('in','inch')` 得 `'inchch'` → 改为 `if uu in ('in','"')` 显式映射。
  - `build_quote.py` 末行统计「图片 0 张」误导（只数旧通道）→ 改为数 `items[].img`。
  - 中文表材质走机械翻译出中英混排（`Synthetic 黑色大理石台面`）→ 新增 `zh_keep_material`，材质保留原文。
- 验证：
  - 某项目 项目：4 个源（3 xlsx sheet + 1 PDF 页）38 条家具，产物 42 行 / 表尾 51–57 / 1.88 MB / 72 media（EN+ZH 各 36）/ 自检 **27/27**。
  - 尺寸单元测试 13 例（`400W x 320D x 380H`、`Dia 500 x H 680`、`47" x 24" x 30"`、`1.2 x 0.8 x 0.75 m`、多行串等）全通过。
- 影响：自检项数不变（英文 27 / 拆分 28 / 中文模板 27）；脚本 12→13 个；新增两条支路共享的开关 `zh_keep_material`。
- 边界：只做家具段；`EQUIPMENT / WHITE GOODS / FIXTURES / DOOR HARDWARE` 整段排除，判定口径写进交付正文。

## v1.5 — 2026-11-20 ｜ 中文报价模板输出支路固化（用户选方案 A）

- 新增：
  - **支路 2c**：`scripts/build_cn_quote.py` / `selfcheck_cn_quote.py` / `preview_cn_quote.py`，把原先散在 `_work/` 的临时脚本通用化。
  - **同一份 config 的 `cn_quote` 节**：路径、模板行号/合并区、列位映射、列宽、换行列、材质词/备注字段/正则、图片参数、抬头覆盖、自检期望值全部配置化；`assets/config.material.sample.json` 同步加样例节。
  - `references/cn-quote.md`：配置键、字段映射、版式复刻、自检 27 项、验收记录。
  - SKILL.md：步骤 2c、铁律 6 第三个自检、输出约定改三条支路、脚本表 9→12、配置开关表、常见坑 26（overrides 假 FAIL）。
- 修复：自检表头比对原本用 `openpyxl.utils.coordinate_from_string` 解析 overrides，异常被吞导致 3 处假 FAIL；改为正则解析并显式报错。
- 验证：
  - 通用脚本重建产物与上轮交付文件**逐格 0 差异**（值/样式/行高/列宽/29 合并区/126 图片锚点/打印设置）。
  - **全新目录 + 只改 config** 从源表跑六步全链路：拆分表 28/28、中文模板 27/27，脚本一行未改。
- 影响：自检项数 27（英文）/ 28（拆分）/ 27（中文模板）；脚本 12 个；三条支路共用 config，验收标准「下个项目只改 config」达成。
- 边界：只固化已跑通的中文模板输出，**未触碰用户尚未确认的整体报价整理方法论 / PDF 方案训练**。

## v1.4.1 — 2026-11-20 ｜ 某酒店项目（中文模板输出·名称列换行）

- 修复：中文报价模板明细行 `wrapText=None`，B 列长品名溢出覆盖 C 列参考图片。输出时名称列强制 `wrap_text=True`（只改 wrapText，对齐沿用模板），并验算折行后行高足够。常见坑追加第 25 条。
- 影响：报价模板自检仍 27 项（英文支路不变；中文模板输出临时自检 25→27 项）/ 脚本 9 个不变 / 无新配置开关。

## v1.4 — 2026-11-20 ｜ 某酒店项目（混合材料报验表拆分）

- 新增：
  - **铁律 7**：混合清单只做家具，非家具单列子表 + 说明页；条数守恒；「由家具厂供货 ≠ 是家具」；拿不准的标待确认不替客户拍板。
  - **支路 2b**：`scripts/parse_material_list.py` / `build_material_list.py` / `selfcheck_material.py`，三脚本共用**同一份 config**。
  - `assets/config.material.sample.json`、`references/material-split.md`（判定口径 + 6 级分类优先级 + 图片归位 + 拆分表自检 28 项）。
  - 配置开关：`classify.override`（最高优先）、`keyword_exclusions`、`bedding_keys`、`furniture_vendor_keys`、`photo.max_photos`、`notes` 占位符、`selfcheck.expected_*`。
- 修复：
  - 人工 `override` 被布草自动规则抢先而失效（S/N 31「装饰抱枕」错分布草）→ 改判提到 `classify()` 第一位，现归「窗帘软装及装饰」并写明依据。
  - 短关键词误伤复合家具名（「电视」命中「电视柜」）→ 家具白名单优先 + `keyword_exclusions`。
  - drawing 路径相对/绝对混用、`twoCellAnchor` 标签 `xdr:` 前缀有无 → `posixpath.normpath` + `(?:xdr:)?` 正则。
  - 一行两张照片只放第一张、第二张被写进备注 → `place_pics()` 竖排，行高按总图高反推并垂直居中。
  - 自检脚本 5 类假 FAIL（品类残留、空名称、数量带单位、`print_title_rows` 的 `$`、多行面积说明）→ 断言对齐解析规则与源数据实际形态；**未改动任何源数据**。
- 影响：自检 报价模板 27 项 / 拆分表 28 项；脚本 9 个；下个项目只改 `config.json` 即可跑通。
  - 本轮为纯中文清单，无新增英译术语，`glossary.py` 保持不变。

## v1.3 — 2026-11-20 ｜ 某酒店项目（行高修复）

- 新增：
  - `place_pic()`：行高由图片显示高度反推（`行高 ≥ 图片px × 72/96 + 6pt`），长文本行里图片垂直居中。
  - 自检 16b / 16c：图片显示高度不得超出所在行高；锚点在合并区内（logo A2:B3）时按合并区行高之和判定。
  - 配置开关 `pic_w` / `pic_h` / `col_widths` 与行高联动。
- 修复：图纸缩略图插入后跨行堆叠（4 行叠成一团）——行高原先只按文字长度算。
- 影响：自检 27 项；脚本 6 个；下个项目无需改脚本。

## v1.2 — 2026-11-20 ｜ 某酒店项目（无产品图 → 切图纸）

- 新增：
  - `scripts/crop_drawings.py`：图纸 PDF 去图框 + 去白边，同时输出 260px 缩略图。
  - 配置开关 `drawing_map` / `drawing_mode`(all|first) / `drawings_sheet`。
  - `DRAWINGS` 大图页（每区一行，660px 可读）。
  - 铁律 2b：没有产品图就切图纸顶上，不许留空；有文字层按编号裁一物一图，栅格图退到区域级。
- 修复：194 份全尺寸图让文件从 0.3MB 涨到 77MB（openpyxl 不去重重复插入）→ 改用缩略图。
- 影响：自检 25 项；脚本 6 个。

## v1.1 — 2026-11-20 ｜ 某酒店项目（严格 OOXML + 整段描述）

- 新增：
  - `scripts/strict2t.py`：Strict OOXML（`purl.oclc.org` 命名空间）→ transitional，并剥 externalLinks。
  - 整段式描述解析：原文整段保留到「规格说明」列，另开列正则抽 Size 与饰面代号（ST-/MT-/FB-）。
  - 红字备注（`flag` → `FFFF0000` 加粗）、`remark_override` 优先级、`auto_height` 自适应行高。
  - 输出约定：默认 EN 主表 + ZH 子表；存疑项写 REMARKS 并标红。
  - `glossary.py` 增加 `NAME_PHRASES` / `NAME_WORDS` 组合翻译（解决 `Lobby Sofa A`、`TableA` 驼峰）。
- 修复：中文表 logo 用模板 `image1.png` 按 A2:B3 实际显示尺寸 150×89 放置，否则比例失真。
- 影响：自检 25 项；脚本 6 个。

## v1.0 — 2026-11-20 ｜ 某项目（某酒店）

- 首版。parse / build / selfcheck / glossary 四件套 + 4 份 reference。
- 覆盖：block 式 BOQ 四种条目起始、图片锚点偏移 1 行、`(sheet,row)` 双键防串表、模板行号 XML 级复核、字体统一、尺寸转数字、中文子表、25 项自检。
