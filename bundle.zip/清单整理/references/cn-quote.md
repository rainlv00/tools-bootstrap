# 中文报价模板输出（支路 2c，v1.5 起）

> 什么时候用：国内项目给的是材料报验表 / 混合清单，先按 `material-split.md` 拆出家具，
> 然后客户要求「按我们的中文报价模板出正式报价清单」。这条支路接在拆分之后，产物仍是三张表
> （报价清单 + 非家具子表 + 说明页）。不要把它套到英文 BOQ 上，也不要把中文模板版式套到英文主表。

## 一、全链路命令（一份 config 跑通）

`build_cn_quote.py` / `selfcheck_cn_quote.py` / `preview_cn_quote.py` 与拆分支路三个脚本
**共用同一个 config**，新增 `cn_quote` 节即可；不填这一节就跳过本支路。

```bash
CFG=_work/config.material.json
python scripts/parse_material_list.py     --config $CFG    # 源表 → items.json + 图片
# 人工复核 items.json 分类与「需人工确认」，必要时只改 config 的 override
python scripts/build_material_list.py     --config $CFG    # → 拆分清单（家具/非家具/说明）
python scripts/selfcheck_material.py      --config $CFG    # 28 项
python scripts/build_cn_quote.py          --config $CFG    # → 中文模板报价清单
python scripts/selfcheck_cn_quote.py      --config $CFG    # 27 项
python scripts/preview_cn_quote.py        --config $CFG    # 无 Excel/LibreOffice 时目视核对
```

验收标准：**换项目只改 config 里的路径、`overrides`、`layout`、词表与期望值，不改脚本。**
v1.5 已用一份全新目录的 config 从源表跑通上述六步（拆分 28/28、中文模板 27/27）。

## 二、配置键（`cn_quote` 节）

样例见 `assets/config.material.sample.json`，实际跑通的见 `D:/WDY/报价/1120-3/config.material.json`。

| 键 | 说明 |
|---|---|
| `tpl` / `tpl_sheet` | 客户中文报价模板 xlsx 与工作表名 |
| `out` | 本支路输出文件 |
| `base` | 上游拆分清单，用来复制非家具子表/说明页。**不写该键**时默认取顶层 `out`；显式 `null` 则只出报价清单单表 |
| `items` | 默认 `<work_dir>/items.json`，即 `parse_material_list.py` 产物 |
| `img_dir` | 默认 `<work_dir>/cn_img`（放模板 logo 抽取件） |
| `sheet_name` / `copy_sheets` | 主表名；要带的子表清单，留空则复制 `base` 除首表外全部 sheet |
| `overrides` | 按项目覆盖的单元格，如 `{"D1":"公司抬头","A8":"项目名称：XX","M6":"时  间：..."}`。**必须是合并区左上角单元格** |
| `layout.header_rows` / `detail_start` / `style_row` / `footer_start` / `footer_rows` / `last_col` | 模板结构行号 |
| `layout.header_merges` / `footer_merge_first` / `footer_merge_col` / `print_title_rows` | 合并区与重复表头 |
| `columns` | 列位映射：`seq/name/pic/w/d/h/qty/unit[]/price[]/material/remark` |
| `col_widths` | 模板原列宽太窄时只调宽、不改结构，如 `{"B":24,"C":24,"N":26,"K":12}` |
| `wrap_cols` | 需要自动换行的列号，**默认 `[2]`（产品名称列，坑 25）** |
| `text` | 材质词、备注字段顺序、品名裁剪正则、尺寸正则、文案前缀 |
| `photo` | `max_photos` / 行高上下限 / 文字行高系数 / 图片间距 / logo 尺寸与 media 名 |
| `print` | 方向、fitToWidth/fitToHeight |
| `preview` | 预览输出、字体、缩放宽度 |
| `selfcheck` | 27 项自检期望值；`expected_*` 填 `null` 表示跳过，正式交付前建议填实值 |

> **`layout` 的行号一律以 `xl/worksheets/sheet1.xml` 的 `r=` + `sharedStrings.xml` 复核**，
> 不能只信一次 openpyxl 打印（某项目项目因此整体偏移一行、表头被清空）。
> 中文模板当前已验证的结构：表头第 9 行、明细 10–15、合计 16、运输/安装/搬运/税金/含税合计 17–21、
> 说明 22、条文 23–28，打印区 A1:N28，**没有分组行**。

## 三、字段映射（用户已认可的口径）

| 模板列 | 填法 |
|---|---|
| B 产品名称 | 品名（短）：按 `text.short_name_strip_patterns` 裁掉尺寸串与括注；**完整原始名称写进备注，逐条可回溯** |
| C 参考图片 | `items.json` 的 `photos`，每行最多 `photo.max_photos` 张，竖排、按总图高撑行高、垂直居中 |
| D/E/F 宽/深/高 | 只填 `text.dim_pattern` 命中的明确三段 mm 尺寸；**不做单位换算、不编造**，其余留空 |
| G 数量 | 源表原样（可能是数字串或带单位，不换算） |
| H/I/J 单位、单套数量 | 全空（源表无单位列，不编造） |
| K/L 出厂价、合计 | 全空（价格暂不报） |
| M 材质 | 源表 `remark` 中含 `text.mat_keys` 的句子，按 `；` 连接 |
| N 备注 | `【家具子类】` + 原名 + `remark_fields`（品牌/图纸编号/使用项目） + `remark_extras`（说明/待确认） + 数量为空提示 |

**不润色源文字**：材质、备注原样搬运；备注只做字段拼接，不改写措辞。
家具子类取自顶层 config 的 `furniture_kinds` / `default_furniture_kind`。

## 四、版式复刻方法

沿用 某项目已验证的逐格复刻，**不插行删行、不动模板结构**：

1. 表头块 `1..header_rows` 逐格 `put()` 复刻值 + 样式（font/fill/border/alignment/protection/number_format）。
2. 明细块按实际家具条数扩展，每格样式一律取模板 `style_row`（第 10 行），不复用上一行。
3. 页脚块 `footer_start..footer_start+footer_rows-1` 逐格复刻，再按 `footer_merge_first` 建合并区。
4. 打印设置从模板带过来，打印区按 `A1:<末列><末行>` 动态算，重复表头 `1:<header_rows>`。
5. `overrides` 在合并区建好之后再写；写的是合并区左上角格。
6. `base` 里的非家具子表 / 说明页用「逐格复刻 + 图片锚点重建」搬到新工作簿，`OneCellAnchor` 保留原 colOff/rowOff/ext。

行高规则：`max(文字需要高度, 图片总高度 × 72/96 + 余量)`；图片永远不压行。
名称列强制 `wrap_text=True`（只改 wrapText，center/center 沿用模板）——见 `SKILL.md` 常见坑 25。

## 五、自检 27 项（`selfcheck_cn_quote.py`）

| 组 | # | 检查 |
|---|---|---|
| A 结构 | 01–05 | 工作表齐全、明细条数、序号连续、表头 1..N 与模板一致（排除 `overrides`）、表头行列文字一致 |
| B 数据口径 | 06–10 | 价格列全空、单位列全空、尺寸为数字或空、尺寸数字个数（不编造）、逐条原名可回溯 |
| C 图片 | 11–13 | 图片总数、锚点全在图片列、图片未超行高 |
| D 页脚/版式 | 14–19 | 页脚文字与模板一致、表头合并区、页脚合并区、打印区、打印设置、明细字体统一 |
| E 子表/文件 | 20–25 | 条数守恒、非家具图片保留、说明页关键词、zip 完整、体积、命名空间 |
| F 名称列换行 | 26–27 | 名称列 `wrap_text` 全 True、折行后行高足够（按显示宽度估算行数，中文按 2 个列宽单位） |

有 FAIL 就不交付，把原始输出贴给用户。**先分清数据缺陷还是断言过严**；假 FAIL 修脚本，
绝不为了过审改源数据（v1.4 一次踩了 5 类，v1.5 踩了 overrides 坐标解析一类，见常见坑 24/26）。

## 六、预览（可选）

`preview_cn_quote.py` 用 PIL 按实际行高列宽自绘，**文字按像素宽度折行**，用来目视确认
长品名不会越过竖线压到图片列。合并单元格的长文字在预览中被按单列宽截断属绘制局限，xlsx 内正常。

## 七、验收记录（v1.5，2026-11-20 某酒店项目）

- 通用脚本重建的产物与上轮交付文件**逐格 0 差异**：值、样式、行高、列宽、29 个合并区、
  126 张图片锚点、打印设置全部一致。
- 全新目录 + 只改 config 的端到端六步全链路：拆分表 28/28、中文模板 27/27。
- 关联坑位：`SKILL.md` 常见坑 1（行号 XML 级校验）、23（一行两张照片）、25（名称列换行）、26（overrides 假 FAIL）。
