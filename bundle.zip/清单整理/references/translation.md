# 中英术语表与翻译

## 用法

```python
from glossary import translate_name, translate_material
zh, leftover = translate_name('Occassional Table A')     # ('边几 A（原文拼写 Occassional）', [])
zh, leftover = translate_material('in Light quartz Stone Top, Light Metal legs')
# ('浅色石英石台面，浅色金属脚', [])
```

`leftover` 返回译文里剩下的英文词，用于统计覆盖率。**覆盖率必须迭代到只剩品牌名和料号。**

## 结构

`glossary.py` 三层，按顺序生效：

```
_PRE     预处理：会先被通用规则拆坏的专有短语、客户原始错拼
NAMES    154 条产品名，人工核对，精确匹配
_D       材质词典：长短语 -> 单词，正则 + re.I
_NAME_RE 把 NAMES 转成正则，用于在材质串里顺带翻译夹带的品名
```

## 三条硬规则

1. **单字母词条必须带 `\b`。**
   `or` 不带边界会把 `outdoor` 变成 `outdo或`，`for` 变成 `f或`，`in` 变成 `扢`。

2. **专有短语必须进 `_PRE`，不能只放 `_D`。**
   `_D` 从上往下执行，通用规则先跑；`Leatherette` 会被 `Leather` 先吃掉，剩下 `ette`。

3. **中文之间去空格，标点统一。**
   `re.sub(r'(?<=[\u4e00-\u9fa5])\s+(?=[\u4e00-\u9fa5])', '', s)`，逗号转全角，句号转分号。

## 迭代方法

```bash
python - <<'EOF'
import json, sys; sys.path.insert(0, '.')
from glossary import translate_material
d = json.load(open('_work/parsed.json', encoding='utf8'))
from collections import Counter
c = Counter(); n = 0
for i in d:
    zh, left = translate_material(i['material'])
    if left:
        n += 1
        for w in left: c[w.lower()] += 1
print('未译条目', n, '| 残余词', len(c)); print(c.most_common(40))
EOF
```

**按词频补词，一轮能降 60%。** 本项目 5 轮：262 → 184 → 79 → 29 → 14 → 2（剩品牌名）。

## 允许保留的英文

| 类型 | 例 |
|---|---|
| 面料/品牌 | Sunbrella、Concertex、Canyon Mushroom |
| 材料牌号 | PVC、HPL、MDF、EPS、CNC |
| 项目料号 | SP-1004、MT-601、GL-102、WD-601、LP-4601、ECO 52009 |

这些进 `keep` 白名单，不算未译。

## 客户原始拼写的处理

客户 BOQ 错拼极多，一律**独立建条**，并在译名后标「（原文拼写 XXX）」：

| 原文 | 应为 | 译文 |
|---|---|---|
| Occassional Table | Occasional | 边几（原文拼写 Occassional） |
| Coffeee Table | Coffee | 茶几（原文拼写 Coffeee） |
| Side Tabke | Table | 边几 A（原文拼写 Tabke） |
| Dinign Chair | Dining | 餐椅（原文拼写 Dinign） |
| Louge Chair | Lounge | 休闲椅（原文拼写 Louge） |
| Kidnew Pillow | Kidney | 腰枕（原文拼写 Kidnew） |
| HEADROOM | HEADBOARD | 床头板（主卧） |
| BUFFER COUNTER | BUFFET | 自助餐台 A |

材质串里的错拼（直接归到正确含义，不标注）：

```
concelaed -> 隐藏式      poweder/powdercoat -> 粉末喷涂
heady/heacy/heavy -> 重型  gliddes/glifes -> 脚垫
fiish/finish -> 饰面     woof/wood -> 木
darj -> 深色             fabirc/fabriic -> 布艺
Soild -> 实木            telphone -> 电话
Aslo/Also -> 亦          Meral -> 金属
```

## 持续更新

每做一个新项目，把新出现的品名和材质词补进 `glossary.py`，然后重跑覆盖率脚本确认只剩余白名单词。**这是本技能里唯一需要长期积累的文件。**
