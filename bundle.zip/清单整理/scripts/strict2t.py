# -*- coding: utf-8 -*-
"""Strict OOXML -> Transitional OOXML（openpyxl 才能读）"""
import re, sys, zipfile

SUB = [
 (b'http://purl.oclc.org/ooxml/spreadsheetml/main',
  b'http://schemas.openxmlformats.org/spreadsheetml/2006/main'),
 (b'http://purl.oclc.org/ooxml/officeDocument/relationships',
  b'http://schemas.openxmlformats.org/officeDocument/2006/relationships'),
 (b'http://purl.oclc.org/ooxml/drawingml/main',
  b'http://schemas.openxmlformats.org/drawingml/2006/main'),
]

def convert(src, dst):
    with zipfile.ZipFile(src) as zin, zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED) as zout:
        for it in zin.infolist():
            if it.filename.startswith('xl/externalLinks/'):
                continue
            data = zin.read(it.filename)
            if it.filename.endswith(('.xml', '.rels')):
                for a, b in SUB:
                    data = data.replace(a, b)
                if it.filename == 'xl/workbook.xml':
                    data = re.sub(rb'<externalReferences>.*?</externalReferences>', b'', data, flags=re.S)
                    data = data.replace(b'conformance="strict"', b'')
                if it.filename == 'xl/_rels/workbook.xml.rels':
                    data = re.sub(rb'<Relationship[^>]*externalLink[^>]*/>', b'', data)
            zout.writestr(it, data)

if __name__ == '__main__':
    convert(sys.argv[1], sys.argv[2])
    print('converted ->', sys.argv[2])
