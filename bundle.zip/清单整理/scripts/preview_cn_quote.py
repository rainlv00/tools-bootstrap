#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""中文报价模板输出的版式预览（本机无 Excel/LibreOffice 时用 PIL 按实际行高列宽自绘）。

用法：
    python preview_cn_quote.py --config config.material.json [--file out.xlsx] [--png preview.png]

文字按像素宽度折行，严格限制在本列宽内 —— 用来直观验证名称列换行后不越到图片列。
合并单元格里的长文字在预览中按单列宽截断属绘制局限，xlsx 内正常。
"""
import argparse
import io
import json
import os

import openpyxl
from openpyxl.utils import get_column_letter
from PIL import Image, ImageDraw, ImageFont


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', required=True)
    ap.add_argument('--file', default=None)
    ap.add_argument('--png', default=None)
    a = ap.parse_args()
    raw = json.load(open(a.config, encoding='utf8'))
    cq = raw.get('cn_quote', {})
    pv = cq.get('preview', {})
    out = a.file or cq['out']
    work = raw['work_dir']
    png = a.png or pv.get('out') or os.path.join(work, 'preview_cn.png')
    font_path = pv.get('font') or r'C:\Windows\Fonts\simsun.ttc'
    if not os.path.exists(font_path):
        font_path = r'C:\Windows\Fonts\msyh.ttc'

    wb = openpyxl.load_workbook(out)
    ws = wb[cq.get('sheet_name', '报价清单')]
    NROW = ws.max_row
    NCOL = min(ws.max_column, int(cq.get('layout', {}).get('last_col', 14)))
    target_w = float(pv.get('width_px', 1700))

    cw = [7 * (ws.column_dimensions[get_column_letter(c)].width or 8.43) + 5
          for c in range(1, NCOL + 1)]
    rh = [(ws.row_dimensions[r].height or 14.25) * 96 / 72
          for r in range(1, NROW + 1)]
    S = target_w / sum(cw)
    cw = [int(x * S) for x in cw]
    rh = [int(x * S) for x in rh]
    W, H = sum(cw), sum(rh)

    img = Image.new('RGB', (W, H), 'white')
    d = ImageDraw.Draw(img)
    try:
        f = ImageFont.truetype(font_path, max(int(12 * S * 1.4), 9))
        fb = ImageFont.truetype(font_path, max(int(12 * S * 1.5), 10))
    except Exception:
        f = fb = ImageFont.load_default()

    xs = [0]
    for w in cw:
        xs.append(xs[-1] + w)
    ys = [0]
    for h in rh:
        ys.append(ys[-1] + h)

    for x in xs:
        d.line((x, 0, x, H), fill=(200, 200, 200))
    for y in ys:
        d.line((0, y, W, y), fill=(200, 200, 200))

    header_row = int(cq.get('layout', {}).get('header_rows', 9))
    for r in range(1, NROW + 1):
        for c in range(1, NCOL + 1):
            v = ws.cell(r, c).value
            if v is None or v == '':
                continue
            t = str(v).replace('\n', ' / ')
            max_px = max(cw[c - 1] - 6, 8)
            lines, cur = [], ''
            for ch in t:
                if cur and f.getlength(cur + ch) > max_px:
                    lines.append(cur)
                    cur = ch
                else:
                    cur += ch
            if cur:
                lines.append(cur)
            lines = lines[:max(int(rh[r - 1] / (f.size * 1.4)), 1)]
            for k, line in enumerate(lines):
                d.text((xs[c - 1] + 2, ys[r - 1] + 2 + k * f.size * 1.35),
                       line, fill=(20, 20, 20), font=fb if r == header_row else f)

    for im in ws._images:
        try:
            p = Image.open(io.BytesIO(im._data())).convert('RGB')
        except Exception:
            continue
        anc = im.anchor
        x = xs[anc._from.col] + anc._from.colOff / 9525.0 * S
        y = ys[anc._from.row] + anc._from.rowOff / 9525.0 * S
        w = anc.ext.cx / 9525.0 * S
        h = anc.ext.cy / 9525.0 * S
        if w < 2 or h < 2:
            continue
        p = p.resize((max(int(w), 1), max(int(h), 1)))
        img.paste(p, (int(x), int(y)))

    img.save(png)
    print('预览已生成', png, img.size, '| %d 行 x %d 列' % (NROW, NCOL))


if __name__ == '__main__':
    main()
