#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""中文报价模板输出（支路 2c）：把 items.json 里的家具条目套进客户提供的中文报价模版。

用法：
    python build_cn_quote.py --config config.material.json

输入：
    cn_quote.tpl    中文报价模版 xlsx
    cn_quote.items  parse_material_list.py 产出的 items.json（默认 <work_dir>/items.json）
    cn_quote.base   build_material_list.py 产出的拆分清单（默认取顶层 out），
                    用于复制非家具子表 / 说明页；设为 null 则不复制
输出：
    cn_quote.out

设计要点（某项目 + 某酒店项目两轮验证过的做法，全部由 config 驱动）：
- 不插行删行，按「表头块 → 明细块（取模板 style_row 样式）→ 页脚块」逐格复刻，
  只有明细行数按实际条数扩展。见常见坑 1 / references/template-map.md。
- 产品名称列强制 wrap_text=True（坑 25：模板明细 wrapText 为空，长名称会溢出压住 C 列图片）。
- 价格 / 单位列留空（源表无单价、无单位，不编造）；尺寸只认明确三段 mm，不做换算。
- 行高取 max(文字需要高度, 图片显示高度反推)，图片永远不压行。
- 路径 / 行号 / 列位 / 列宽 / 文案 / 词表 / 图片参数全部由 config 驱动。
"""
import argparse
import copy
import io
import json
import os
import re
import zipfile

import openpyxl
from openpyxl.drawing.image import Image as XLImage
from openpyxl.drawing.spreadsheet_drawing import AnchorMarker, OneCellAnchor
from openpyxl.drawing.xdr import XDRPositiveSize2D
from openpyxl.utils import get_column_letter
from openpyxl.utils.units import pixels_to_EMU
from PIL import Image

# 默认值：config.cn_quote 缺键时兜底。改项目只需改 config，不改这里。
DEFAULTS = {
    'tpl_sheet': '报价清单',
    'sheet_name': '报价清单',
    'copy_sheets': [],
    'overrides': {},
    'layout': {
        'header_rows': 9, 'detail_start': 10, 'style_row': 10,
        'footer_start': 16, 'footer_rows': 13, 'last_col': 14,
        'header_merges': [], 'footer_merge_first': 6, 'footer_merge_col': 8,
        'print_title_rows': None,
    },
    'columns': {
        'seq': 1, 'name': 2, 'pic': 3, 'w': 4, 'd': 5, 'h': 6, 'qty': 7,
        'unit': [8, 9, 10], 'price': [11, 12], 'material': 13, 'remark': 14,
    },
    'col_widths': {},
    'wrap_cols': [2],
    'text': {
        'mat_keys': ['材质', '基材', '饰面', '石英', '岩板', '大理石'],
        'remark_fields': [['brand', '品牌'], ['fsb', '图纸编号'], ['si', '使用项目']],
        'remark_extras': [['remark', '说明'], ['note', '待确认']],
        'kind_label': '【%s】', 'name_prefix': '原名：',
        'empty_qty_note': '源表数量为空',
        'short_name_strip_patterns': [r'[-，,]\s*尺寸为.*$',
                                      r'\d+\s*[*×xX]\s*\d+.*$',
                                      r'（[^）]*）\s*$'],
        'short_name_strip_chars': ' ：:、-',
        'dim_pattern': r'(\d{3,4})\s*[*×xX]\s*(\d{2,4})\s*[*×xX]\s*(\d{2,4})\s*(?:mm|毫米)?',
    },
    'photo': {
        'max_photos': 2, 'min_row_height': 95, 'max_row_height': 300,
        'text_h_divisors': [12, 18, 13], 'line_h': 14, 'text_pad': 14,
        'pad_px': 10, 'avail_pad_px': 10, 'gap_px': 4, 'need_pad_pt': 8,
        'logo_media': 'xl/media/image1.png', 'logo_anchor': 'A1',
        'logo_w': 187, 'logo_h': 126,
    },
    'print': {'orientation': 'landscape', 'fit_to_width': 1, 'fit_to_height': 0},
}


def deep_merge(base, over):
    """递归合并 dict，over 优先；None 视为显式关闭。"""
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def load_cfg(path):
    raw = json.load(open(path, encoding='utf8'))
    cq = deep_merge(DEFAULTS, raw.get('cn_quote', {}))
    work = raw['work_dir']
    cq.setdefault('items', os.path.join(work, 'items.json'))
    cq.setdefault('img_dir', os.path.join(work, 'cn_img'))
    if 'base' not in cq:                     # 未显式配置时，默认接材料拆分脚本的产物
        cq['base'] = raw.get('out')
    cq['_raw'] = raw
    return cq


def short_name(n, t):
    s = str(n or '').replace('\n', ' / ')
    for p in t['short_name_strip_patterns']:
        s = re.sub(p, '', s)
    return s.strip(t['short_name_strip_chars']) or str(n or '')


def parse_whd(n, t):
    """只认明确的三段 mm 尺寸，其余留空（不做单位换算、不编造）。"""
    m = re.search(t['dim_pattern'], str(n or ''))
    if m:
        return int(m.group(1)), int(m.group(2)), int(m.group(3))
    return None, None, None


def mat_text(remark, t):
    if not remark:
        return ''
    parts = re.split(r'[\n；;]', str(remark))
    return '；'.join(p.strip() for p in parts if any(k in p for k in t['mat_keys']))


def remark_text(it, t, kinds, default_kind):
    bits = [t['kind_label'] % kinds.get(str(it['sn']), default_kind),
            t['name_prefix'] + str(it['name'])]
    for key, label in t['remark_fields']:
        if it.get(key):
            bits.append('%s：%s' % (label, str(it[key]).strip()))
    for key, label in t['remark_extras']:
        if it.get(key):
            bits.append('%s：%s' % (label, str(it[key]).strip()))
    if not it.get('qty'):
        bits.append(t['empty_qty_note'])
    return '\n'.join(bits)


def text_h(b, m, n, ph):
    div = ph['text_h_divisors']
    lines = max(len(str(b)) / div[0], len(str(m)) / div[1], len(str(n)) / div[2], 1)
    return min(ph['line_h'] * lines + ph['text_pad'], ph['max_row_height'])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', required=True)
    a = ap.parse_args()
    cq = load_cfg(a.config)
    raw = cq['_raw']
    ly, cols, t, ph = cq['layout'], cq['columns'], cq['text'], cq['photo']
    os.makedirs(cq['img_dir'], exist_ok=True)

    items = json.load(open(cq['items'], encoding='utf8'))
    fur = [i for i in items if i['furniture']]
    kinds = raw.get('furniture_kinds', {})
    default_kind = raw.get('default_furniture_kind', '活动家具')

    # ---------------- 1. 复刻模板 ----------------
    src = openpyxl.load_workbook(cq['tpl'])
    sws = src[cq['tpl_sheet']]
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = cq['sheet_name']

    _SENT = object()

    def style_from(dst, s):
        dst.font = copy.copy(s.font)
        dst.border = copy.copy(s.border)
        dst.fill = copy.copy(s.fill)
        dst.alignment = copy.copy(s.alignment)
        dst.protection = copy.copy(s.protection)
        dst.number_format = s.number_format

    def put(r, c, value=_SENT, sr=None, sc=None):
        s = sws.cell(row=sr or r, column=sc or c)
        d = ws.cell(row=r, column=c)
        style_from(d, s)
        d.value = s.value if value is _SENT else value
        return d

    for k, dim in sws.column_dimensions.items():
        if dim.width:
            ws.column_dimensions[k].width = dim.width
    for letter, width in cq['col_widths'].items():
        ws.column_dimensions[letter].width = width

    hr = int(ly['header_rows'])
    last_col = int(ly['last_col'])
    for r in range(1, hr + 1):
        for c in range(1, last_col + 1):
            put(r, c)
        if sws.row_dimensions[r].height:
            ws.row_dimensions[r].height = sws.row_dimensions[r].height

    for m in ly['header_merges']:
        ws.merge_cells(m)
    for coord, val in (cq['overrides'] or {}).items():
        ws[coord] = val

    # logo（模板内嵌图片；跳过目录条目，优先指定 media）
    logo_count = 0
    with zipfile.ZipFile(cq['tpl']) as z:
        media = [n for n in z.namelist()
                 if n.startswith('xl/media/') and not n.endswith('/')]
        logo_name = ph['logo_media'] if ph['logo_media'] in media else (media[0] if media else None)
        if logo_name:
            logo_p = os.path.join(cq['img_dir'], 'logo.png')
            open(logo_p, 'wb').write(z.read(logo_name))
            logo = XLImage(logo_p)
            logo.width, logo.height = ph['logo_w'], ph['logo_h']
            ws.add_image(logo, ph['logo_anchor'])
            logo_count = 1

    # ---------------- 2. 明细 ----------------
    pic_letter = get_column_letter(int(cols['pic']))
    pic_w = ws.column_dimensions[pic_letter].width or 8.43
    BOX_W = int(pic_w * 7 + 5 - ph['pad_px'])

    def layout_photos(paths, row_h_pt):
        n = len(paths)
        if not n:
            return []
        avail = row_h_pt * 96 / 72 - ph['avail_pad_px']
        each_max = max((avail - ph['gap_px'] * (n - 1)) / n, 20)
        out = []
        for p in paths:
            im = Image.open(p).convert('RGB')
            k = min(BOX_W / im.width, each_max / im.height, 1.0)
            out.append((p, int(im.width * k), int(im.height * k)))
        return out

    r = int(ly['detail_start'])
    img_log = []
    for seq, it in enumerate(fur, 1):
        sr_style = int(ly['style_row'])
        for c in range(1, last_col + 1):
            put(r, c, None, sr_style, c)

        name = str(it['name'])
        sn = short_name(name, t)
        W, D, H = parse_whd(name, t)
        mat = mat_text(it.get('remark'), t)
        rem = remark_text(it, t, kinds, default_kind)

        ws.cell(r, cols['seq']).value = seq
        ws.cell(r, cols['name']).value = sn
        # 坑 25：名称列强制自动换行，长名称在列内折行，不溢出覆盖图片列。
        # 只改 wrapText，horizontal/vertical 沿用模板明细样式。
        # wrap_cols 可配置多个列（默认 [name列]），换模板时改 config 即可。
        for wc in cq['wrap_cols']:
            acell = ws.cell(r, int(wc))
            bal = copy.copy(acell.alignment)
            bal.wrap_text = True
            acell.alignment = bal

        for key, val in (('w', W), ('d', D), ('h', H)):
            ws.cell(r, cols[key]).value = val
        ws.cell(r, cols['qty']).value = it.get('qty') or None
        # unit / price 保持空：源表无单位、价格暂不报
        ws.cell(r, cols['material']).value = mat or None
        ws.cell(r, cols['remark']).value = rem

        row_h = max(ph['min_row_height'], text_h(sn, mat, rem, ph))
        photos = (it.get('photos') or [])[:int(ph['max_photos'])]
        lay = layout_photos(photos, row_h)
        if lay:
            need = (sum(h for _, _, h in lay)
                    + ph['gap_px'] * (len(lay) - 1)) * 72 / 96 + ph['need_pad_pt']
            if need > row_h:
                row_h = need
                lay = layout_photos(photos, row_h)
        ws.row_dimensions[r].height = row_h

        if lay:
            total_h = sum(h for _, _, h in lay) + ph['gap_px'] * (len(lay) - 1)
            offset = max(int((row_h * 96 / 72 - total_h) / 2), 0)
            for p, w, h in lay:
                pic = XLImage(p)
                pic.width, pic.height = w, h
                pic.anchor = OneCellAnchor(
                    _from=AnchorMarker(col=int(cols['pic']) - 1,
                                       colOff=pixels_to_EMU(max((BOX_W - w) // 2, 0)),
                                       row=r - 1, rowOff=pixels_to_EMU(offset)),
                    ext=XDRPositiveSize2D(pixels_to_EMU(w), pixels_to_EMU(h)))
                ws.add_image(pic)
                offset += h + ph['gap_px']
            img_log.append((seq, len(lay), round(row_h, 1)))
        r += 1

    # ---------------- 3. 页脚（模板 footer_start 起 footer_rows 行） ----------------
    first_footer = r
    fr = int(ly['footer_rows'])
    for i in range(fr):
        sr = int(ly['footer_start']) + i
        for c in range(1, last_col + 1):
            put(first_footer + i, c, sr=sr, sc=c)
        if sws.row_dimensions[sr].height:
            ws.row_dimensions[first_footer + i].height = sws.row_dimensions[sr].height
    fm = int(ly['footer_merge_first'])
    for i in range(fm):
        ws.merge_cells(start_row=first_footer + i, start_column=1,
                       end_row=first_footer + i, end_column=int(ly['footer_merge_col']))
    for i in range(fm, fr):
        ws.merge_cells(start_row=first_footer + i, start_column=1,
                       end_row=first_footer + i, end_column=last_col)
    last_row = first_footer + fr - 1

    pr = cq['print']
    ws.page_setup.orientation = pr['orientation']
    ws.page_setup.paperSize = sws.page_setup.paperSize
    ws.page_setup.scale = None
    ws.sheet_properties.pageSetUpPr = copy.copy(sws.sheet_properties.pageSetUpPr)
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_setup.fitToWidth = pr['fit_to_width']
    ws.page_setup.fitToHeight = pr['fit_to_height']
    ws.page_margins = copy.copy(sws.page_margins)
    ws.print_area = 'A1:%s%d' % (get_column_letter(last_col), last_row)
    ws.print_title_rows = ly.get('print_title_rows') or '1:%d' % hr

    # ---------------- 4. 复制非家具子表与说明页 ----------------
    if cq.get('base') and os.path.exists(cq['base']):
        base_wb = openpyxl.load_workbook(cq['base'])

        def copy_sheet(s, dst_wb, title):
            d = dst_wb.create_sheet(title)
            for k, dim in s.column_dimensions.items():
                if dim.width:
                    d.column_dimensions[k].width = dim.width
            for rr in range(1, s.max_row + 1):
                if s.row_dimensions[rr].height:
                    d.row_dimensions[rr].height = s.row_dimensions[rr].height
                for cc in range(1, s.max_column + 1):
                    sc, dc = s.cell(rr, cc), d.cell(rr, cc)
                    dc.value = sc.value
                    if sc.has_style:
                        dc.font = copy.copy(sc.font)
                        dc.fill = copy.copy(sc.fill)
                        dc.border = copy.copy(sc.border)
                        dc.alignment = copy.copy(sc.alignment)
                        dc.number_format = sc.number_format
            for mg in s.merged_cells.ranges:
                d.merge_cells(str(mg))
            for im in s._images:
                try:
                    pic = XLImage(io.BytesIO(im._data()))
                    an = im.anchor
                    pic.anchor = OneCellAnchor(
                        _from=AnchorMarker(col=an._from.col, colOff=an._from.colOff,
                                           row=an._from.row, rowOff=an._from.rowOff),
                        ext=XDRPositiveSize2D(an.ext.cx, an.ext.cy))
                    d.add_image(pic)
                except Exception as e:
                    print('  ! 图片重挂失败', e)
            d.page_setup.orientation = s.page_setup.orientation
            d.sheet_properties.pageSetUpPr = copy.copy(s.sheet_properties.pageSetUpPr)
            d.page_setup.fitToWidth = s.page_setup.fitToWidth
            d.page_setup.fitToHeight = s.page_setup.fitToHeight
            d.print_title_rows = s.print_title_rows
            return d

        names = cq['copy_sheets'] or base_wb.sheetnames[1:]
        for sh in names:
            if sh in base_wb.sheetnames:
                copy_sheet(base_wb[sh], wb, sh)
            else:
                print('  ! base 缺少 sheet，跳过：', sh)

    wb.save(cq['out'])
    print('已生成', cq['out'])
    print('明细 %d 条 | 明细行 %d-%d | 页脚 %d-%d | 打印区 A1:%s%d'
          % (len(fur), ly['detail_start'], first_footer - 1,
             first_footer, last_row, get_column_letter(last_col), last_row))
    print('%s 图片 %d 张（logo %d + 产品 %d）'
          % (cq['sheet_name'], len(ws._images), logo_count,
             len(ws._images) - logo_count))
    print('有图明细行 %d / %d' % (len(img_log), len(fur)))
    print('sheets:', wb.sheetnames)
    print('体积 %.2f MB' % (os.path.getsize(cq['out']) / 1024 / 1024))


if __name__ == '__main__':
    main()
