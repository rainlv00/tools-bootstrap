#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""区块式 BOQ -> parsed.json

用法：
    python parse_boq.py --config config.json
    python parse_boq.py --loose LOOSE.xlsx --builtins BUILT-INS.xlsx --out parsed.json

输出每条：src / area / zone / no / code / name / size / material / remark / unit / row
"""
import argparse
import json
import os
import re

import openpyxl

LETTER = re.compile(r'^[a-zA-Z][\.,]?$')
IFCODE = re.compile(r'^IF\s*[-–]\s*\d+', re.I)
LEVEL = re.compile(r'^LEVEL\s*\d', re.I)
SIZEPAT = re.compile(r'(\d+\s*(mm|m\b|dia|thk))', re.I)
REMARK_KEYS = ('fire rating', 'wood treatment', 'power data', 'power point',
               '*confirm', 'note', 'warranty', 'delivery', 'installation')

DEFAULT_START = 13


def clean(v):
    return str(v).strip() if v is not None else ''


def parse_sheet(ws, start_row=DEFAULT_START):
    """区块式解析：字母行 / 纯型号行 / 纯名称行 均开新条目；B 列标签为分区。"""
    items, area, zone = [], '', ''
    prev_blank, cur = True, None
    for r in range(start_row, ws.max_row + 1):
        a = clean(ws.cell(row=r, column=1).value)
        b = clean(ws.cell(row=r, column=2).value)
        c = clean(ws.cell(row=r, column=3).value)
        unit = clean(ws.cell(row=r, column=9).value)
        f = clean(ws.cell(row=r, column=6).value)

        if 'SUB-TOTAL' in f.upper():                 # 小计行，跳过
            prev_blank, cur = True, None
            continue
        if not any([a, b, c, unit, f]):              # 空行，结束当前条目
            prev_blank, cur = True, None
            continue

        if LETTER.match(b) and c:                    # a. + 型号/名称
            prev_blank = False
            cur = dict(no=b.rstrip('.,'), code='', name='', lines=[], unit='',
                       row=r, area=area, zone=zone)
            if IFCODE.match(c):
                cur['code'] = c
            else:
                cur['name'] = c
            items.append(cur)
            continue

        if IFCODE.match(c) and not b:                # 纯型号行
            prev_blank = False
            cur = dict(no='', code=c, name='', lines=[], unit='',
                       row=r, area=area, zone=zone)
            items.append(cur)
            continue

        if b and not c:                              # 分区 / 区域标签
            prev_blank = False
            if LEVEL.match(b):
                area, zone = b, ''
            else:
                zone = b
            cur = None
            continue

        if c and not b:
            if prev_blank or cur is None:            # 无编号条目（配件类）
                prev_blank = False
                cur = dict(no='', code='', name=c, lines=[], unit=unit,
                           row=r, area=area, zone=zone)
                items.append(cur)
                continue
            if not cur['name']:                      # 编号行之后第一行 = 名称
                cur['name'] = c
            else:
                cur['lines'].append(c)
            if unit and not cur['unit']:
                cur['unit'] = unit
            continue

        prev_blank = False
        if cur is not None and unit and not cur['unit']:
            cur['unit'] = unit
    return items


def split_fields(it):
    """name 之后的行拆成 规格 / 材质 / 备注。"""
    lines = [l for l in it['lines'] if l]
    size, mat, rem = [], [], []
    for i, ln in enumerate(lines):
        low = ln.lower()
        if i == 0 and (SIZEPAT.search(ln) or ln[:1].isdigit()) and len(ln) < 90:
            size.append(ln)
        elif any(low.startswith(k) for k in REMARK_KEYS):
            rem.append(ln)
        elif re.match(r'^[\(\[]?\d', ln) and 'mm' in low and len(ln) < 60:
            size.append(ln)
        else:
            mat.append(ln)
    it['size'] = ' / '.join(size)
    it['material'] = ' / '.join(mat)
    it['remark'] = ' / '.join(rem)
    return it


def run(sources, out_path, start_row=DEFAULT_START):
    all_items, general_req = [], []
    for src in sources:
        wb = openpyxl.load_workbook(src['file'], data_only=True)
        for sh in src['sheets']:
            ws = wb[sh['name']]
            its = [split_fields(i) for i in parse_sheet(ws, start_row)]
            for i in its:
                i['src'] = sh['label']
            all_items += its
            print('%-12s %-18s %3d 项' % (sh['label'], sh['name'], len(its)))
        if src.get('general_req') and not general_req:
            ws = wb[src['sheets'][0]['name']]
            for r in range(start_row, 45):
                a = clean(ws.cell(row=r, column=1).value)
                b = clean(ws.cell(row=r, column=2).value)
                if a.isdigit() and b:
                    general_req.append((a, b))
        wb.close()

    os.makedirs(os.path.dirname(os.path.abspath(out_path)) or '.', exist_ok=True)
    json.dump({'items': all_items, 'general_req': general_req},
              open(out_path, 'w', encoding='utf8'), ensure_ascii=False, indent=1)

    empty = lambda k: sum(1 for i in all_items if not i[k])
    print('\n合计 %d 项 | 无名称 %d | 无尺寸 %d | 无材质 %d | 无单位 %d | 措施费行 %d'
          % (len(all_items), empty('name'), empty('size'), empty('material'),
             empty('unit'), len(general_req)))
    return all_items


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--config')
    ap.add_argument('--loose')
    ap.add_argument('--builtins')
    ap.add_argument('--out', default='_work/parsed.json')
    ap.add_argument('--start-row', type=int, default=DEFAULT_START)
    a = ap.parse_args()

    if a.config:
        cfg = json.load(open(a.config, encoding='utf8'))
        run(cfg['sources'], cfg.get('parsed', a.out), cfg.get('start_row', DEFAULT_START))
        return

    sources = []
    if a.loose:
        sources.append({'file': a.loose, 'general_req': True,
                        'sheets': [{'name': 'TABLE', 'label': 'TABLES'},
                                   {'name': 'CHAIRS', 'label': 'CHAIRS'},
                                   {'name': 'SOFA', 'label': 'SOFA'}]})
    if a.builtins:
        sources.append({'file': a.builtins,
                        'sheets': [{'name': ' BUILT INS', 'label': 'BUILT-INS'}]})
    run(sources, a.out, a.start_row)


if __name__ == '__main__':
    main()
