"""从效果图 / 图纸 PDF 裁单件图，并直接挂到 parsed.json 的 img 字段。

资料只有效果图、没有产品图时的标准做法（SKILL.md 步骤 2e）：
逐页看图定位，用**比例坐标**裁出单件，再按 (节, 品名) 写回条目。

用法：
    python crop_from_pdf.py --job _work/crop_job.json

job 文件结构：
{
  "src_dir": "D:/.../效果图目录",        // PDF 所在目录
  "out_dir": "D:/.../_work/img",          // 输出 jpg 目录
  "parsed":  "D:/.../_work/parsed.json",  // 可选，给了就顺便挂图
  "dpi": 150,                              // 可选，默认 150
  "max_px": 520,                           // 可选，输出最长边
  "jobs": [
    {"pdf": "OP1 EXECUTIVE ROOM RE.pdf", "page": 1,          // 1 = 第 1 页（不是 0）
     "section": "OP1-EX", "name": "Wardrobe (3-door)",
     "slug": "wardrobe",                   // 可选，不给就从 name 派生
     "box": [0.32, 0.08, 0.73, 0.94]}      // x0,y0,x1,y1 相对整页 0~1
  ]
}

注意（坑 48）：不同方案的 PDF 页序不同，坐标不能直接套用；先渲染缩略图逐页确认。
"""
import argparse
import json
import os

import pymupdf
from PIL import Image


def render(doc, page, dpi, cache):
    if page not in cache:
        pix = doc[page].get_pixmap(dpi=dpi)
        cache[page] = Image.frombytes('RGB', [pix.width, pix.height], pix.samples)
    return cache[page]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--job', required=True, help='crop job json')
    a = ap.parse_args()
    j = json.load(open(a.job, encoding='utf-8'))

    src_dir = j['src_dir']
    out_dir = j['out_dir']
    dpi = j.get('dpi', 150)
    max_px = j.get('max_px', 520)
    os.makedirs(out_dir, exist_ok=True)

    docs, made = {}, {}
    for item in j['jobs']:
        pdf, page = item['pdf'], item['page']
        if pdf not in docs:
            docs[pdf] = pymupdf.open(os.path.join(src_dir, pdf))
            made[pdf] = {}
        im = render(docs[pdf], page - 1, dpi, made[pdf])   # job 里 page 从 1 开始
        w, h = im.size
        x0, y0, x1, y1 = item['box']
        c = im.crop((int(w * x0), int(h * y0), int(w * x1), int(h * y1)))
        c.thumbnail((max_px, max_px), Image.LANCZOS)
        code = '%s-%s' % (item['section'], item.get('slug') or item['name']
                          .lower().replace(' ', '-').replace('(', '').replace(')', ''))
        p = os.path.join(out_dir, code + '.jpg')
        c.save(p, 'JPEG', quality=88, optimize=True)
        item['_out'] = p
        print('%-34s %4dx%-4d %3d KB' % (code, c.width, c.height, os.path.getsize(p) // 1024))
    for d in docs.values():
        d.close()

    # 挂图：按 (section, name) 写回 parsed.json
    parsed = j.get('parsed')
    if not parsed:
        return
    data = json.load(open(parsed, encoding='utf-8'))
    idx = {}
    for item in j['jobs']:
        idx[(item['section'], item['name'])] = item['_out'].replace('\\', '/')
    hit = 0
    for it in data['items']:
        p = idx.get((it['src'], it['name']))
        if p:
            it['img'] = p
            hit += 1
    json.dump(data, open(parsed, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('挂图 %d 条 / 共 %d 条' % (hit, len(data['items'])))


if __name__ == '__main__':
    main()
