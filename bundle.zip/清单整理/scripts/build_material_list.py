#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""通用材料报验 / 混合清单生成：家具主表 + 非家具子表 + 说明页。

用法：
    python build_material_list.py --config config.material.json

数据只来自 parse_material_list.py 产出的 items.json；本脚本不重新判定品类。
版式、列宽、表名、分组顺序、说明文字全部由 config 驱动。
"""
import argparse
import json
import os
import re

from openpyxl import Workbook
from openpyxl.drawing.image import Image
from openpyxl.drawing.spreadsheet_drawing import AnchorMarker, OneCellAnchor
from openpyxl.drawing.xdr import XDRPositiveSize2D
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import column_index_from_string, get_column_letter
from openpyxl.utils.units import pixels_to_EMU

THIN = Side(style='thin', color='FFBFBFBF')
BOX = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
HEAD_FILL = PatternFill('solid', fgColor='FF44546A')
SEC_FILL = PatternFill('solid', fgColor='FFE8E4D9')
SUM_FILL = PatternFill('solid', fgColor='FFF2F2F2')

SPEC_PATTERNS = [
    r'尺寸为\s*([^，,。；;]{4,40})',
    r'(\d[\d\.\+\s\*×]*\d)\s*(?:mm|毫米)',
    r'(\d+\s*厘米\s*[×xX]\s*\d+\s*厘米)',
    r'(\d+\s*[*×xX]\s*\d+(?:\s*[*×xX]\s*\d+)?)',
]


def spec_of(name):
    """从名称抽规格；抽不到留空，绝不编造。"""
    n = str(name or '').replace('\n', ' ')
    for p in SPEC_PATTERNS:
        m = re.search(p, n)
        if m:
            s = re.sub(r'\s{2,}', ' ', m.group(1).strip())
            s = re.sub(r'\s*[*xX]\s*', ' × ', s)
            if any(t in s for t in ('mm', '毫米', '厘米', '×')):
                return s
    return ''


def place_pics(ws, row, photos, box_w, box_h, col='J'):
    """一行内 1~N 张竖排；行高按图片总高反推，图片垂直居中，永不压行。

    行高(pt) >= 图片总显示高度(px) * 72/96 + 6。
    用显式 OneCellAnchor，字符串锚点改不动 rowOff。
    """
    if not photos:
        return
    pics, tot_h = [], 0
    for path in photos:
        pic = Image(path)
        ratio = min(box_w / pic.width, box_h / pic.height, 1)
        w, h = pic.width * ratio, pic.height * ratio
        pics.append((pic, w, h))
        tot_h += h
    gap = 4
    tot_h += gap * (len(pics) - 1)
    need = tot_h * 72 / 96 + 6
    cur = ws.row_dimensions[row].height or 20
    row_h = max(cur, need)
    ws.row_dimensions[row].height = row_h
    offset = max(int((row_h - need) / 2 * 96 / 72), 0)
    for pic, w, h in pics:
        marker = AnchorMarker(col=column_index_from_string(col) - 1,
                              colOff=pixels_to_EMU(4), row=row - 1,
                              rowOff=pixels_to_EMU(offset))
        pic.anchor = OneCellAnchor(
            _from=marker, ext=XDRPositiveSize2D(pixels_to_EMU(w), pixels_to_EMU(h)))
        ws.add_image(pic)
        offset += h + gap


class Builder:
    def __init__(self, cfg):
        self.cfg = cfg
        self.cols = [(x[0], x[1]) for x in cfg['output_columns']]
        self.nc = len(self.cols)
        fonts = cfg.get('fonts', {})
        fam = fonts.get('zh', '宋体')
        size = fonts.get('size', 9)
        self.BODY = Font(name=fam, size=size)
        self.BOLD = Font(name=fam, size=size, bold=True)
        self.HEAD = Font(name=fam, size=size + 1, bold=True, color='FFFFFFFF')
        self.TITLE = Font(name=fam, size=size + 5, bold=True)
        self.SUB = Font(name=fam, size=size, color='FF808080')
        self.RED = Font(name=fam, size=size, bold=True, color='FFFF0000')
        self.photo = cfg.get('photo', {})
        self.pic_col = self.photo.get('col', 'J')
        self.box_w = self.photo.get('box_w', 118)
        self.box_h = self.photo.get('box_h', 72)
        self.remark_fields = cfg.get('remark_fields', ['note', 'desc', 'remark'])
        self.wrap_cols = cfg.get('wrap_cols', [3, 4, 5, 7, 8, 9])

    def setup(self, ws, title, note):
        for i, (name, w) in enumerate(self.cols, 1):
            ws.column_dimensions[get_column_letter(i)].width = w
        ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=self.nc)
        c = ws.cell(1, 1, title)
        c.font = self.TITLE
        c.alignment = Alignment(horizontal='center', vertical='center')
        ws.row_dimensions[1].height = 30
        ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=self.nc)
        c = ws.cell(2, 1, note)
        c.font = self.SUB
        c.alignment = Alignment(horizontal='left', vertical='center')
        ws.row_dimensions[2].height = 18
        for i, (name, _) in enumerate(self.cols, 1):
            c = ws.cell(3, i, name)
            c.font = self.HEAD
            c.fill = HEAD_FILL
            c.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            c.border = BOX
        ws.row_dimensions[3].height = 30
        ws.freeze_panes = cfg_freeze(self.cfg)
        return 4

    def remark_of(self, it):
        bits = [str(it.get(k) or '') for k in self.remark_fields]
        bits = [x for x in bits if x]
        if not it.get('qty'):
            bits.append(self.cfg.get('empty_qty_note', '源表数量为空'))
        return '；'.join(bits)

    def put_row(self, ws, r, vals, photos):
        for i, v in enumerate(vals, 1):
            c = ws.cell(r, i, v)
            c.font = self.BODY
            c.border = BOX
            c.alignment = Alignment(
                vertical='center', wrap_text=i in self.wrap_cols,
                horizontal='center' if i in (1, 6) else 'left')
        if photos:
            place_pics(ws, r, photos, self.box_w, self.box_h, self.pic_col)
        txt = max(len(str(vals[2])) / 44, len(str(vals[3])) / 22,
                  len(str(vals[4])) / 24, len(str(vals[6])) / 24,
                  len(str(vals[8])) / 38, 1)
        h = min(max(18, 6 + txt * 12), int(self.cfg.get('max_row_height', 210)))
        if (ws.row_dimensions[r].height or 0) < h:
            ws.row_dimensions[r].height = h

    def total_row(self, ws, r, label, qty_sum):
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=5)
        c = ws.cell(r, 1, label)
        c.font, c.fill, c.border = self.BOLD, SUM_FILL, BOX
        c.alignment = Alignment(horizontal='right', vertical='center')
        c = ws.cell(r, 6, int(qty_sum) if qty_sum == int(qty_sum) else qty_sum)
        c.font, c.fill, c.border = self.BOLD, SUM_FILL, BOX
        c.alignment = Alignment(horizontal='center', vertical='center')
        for i in range(7, self.nc + 1):
            ws.cell(r, i).fill = SUM_FILL
            ws.cell(r, i).border = BOX
        ws.row_dimensions[r].height = 22


def cfg_freeze(cfg):
    return cfg.get('freeze_panes', 'C4')


def qnum(v):
    try:
        return float(v) if re.fullmatch(r'\d+(\.\d+)?', str(v).strip()) else 0.0
    except (TypeError, ValueError):
        return 0.0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', required=True)
    a = ap.parse_args()
    cfg = json.load(open(a.config, encoding='utf8'))
    items = json.load(open(os.path.join(cfg['work_dir'], 'items.json'), encoding='utf8'))
    fur = [i for i in items if i['furniture']]
    non = [i for i in items if not i['furniture']]
    b = Builder(cfg)
    names = cfg['sheet_names']

    wb = Workbook()
    # ---------- 家具主表 ----------
    ws = wb.active
    ws.title = names['furniture']
    kinds = cfg.get('furniture_kinds', {})
    r = b.setup(ws, cfg['title'], cfg['subtitle'].format(total=len(items)))
    total = 0.0
    for k, it in enumerate(fur, 1):
        total += qnum(it.get('qty'))
        vals = [k, kinds.get(str(it['sn']), cfg.get('default_furniture_kind', '活动家具')),
                it['name'], spec_of(it['name']), it.get('brand', ''), it.get('qty', ''),
                it.get('fsb', ''), it.get('si', ''), b.remark_of(it), '']
        b.put_row(ws, r, vals, it['photos'])
        r += 1
    b.total_row(ws, r, cfg.get('total_label', '合计（{n} 项）').format(n=len(fur)), total)

    # ---------- 非家具子表 ----------
    ws2 = wb.create_sheet(names['non'])
    sub_order = cfg.get('sub_order') or (
        [s[0] for s in cfg['classify'].get('non_furniture_subs', [])]
        + [cfg['classify'].get('other_vendor_label', '其他（家具厂供货但非家具）'),
           cfg['classify'].get('other_unknown_label', '其他（未归类）')])
    r = b.setup(ws2, cfg.get('non_title', names['non']),
                cfg.get('non_subtitle', '本单位只做家具，以下 {n} 条不属于家具范围，单列备查')
                .format(n=len(non)))
    seq = 0
    for sub in sub_order:
        grp = [i for i in non if i['sub'] == sub]
        if not grp:
            continue
        ws2.merge_cells(start_row=r, start_column=1, end_row=r, end_column=b.nc)
        c = ws2.cell(r, 1, '%s　（%d 项）' % (sub, len(grp)))
        c.font, c.fill = b.BOLD, SEC_FILL
        c.alignment = Alignment(horizontal='left', vertical='center')
        for i in range(1, b.nc + 1):
            ws2.cell(r, i).fill = SEC_FILL
            ws2.cell(r, i).border = BOX
        ws2.row_dimensions[r].height = 20
        r += 1
        for it in grp:
            seq += 1
            vals = [seq, sub, it['name'], spec_of(it['name']), it.get('brand', ''),
                    it.get('qty', ''), it.get('fsb', ''), it.get('si', ''),
                    b.remark_of(it), '']
            b.put_row(ws2, r, vals, it['photos'])
            r += 1
        b.total_row(ws2, r, cfg.get('subtotal_label', '%s 小计（{n} 项）')
                    .format(n=len(grp)) % sub, sum(qnum(i.get('qty')) for i in grp))
        r += 1

    # ---------- 说明页 ----------
    if cfg.get('notes'):
        ws3 = wb.create_sheet(names.get('notes', '说明'))
        ws3.column_dimensions['A'].width = cfg.get('notes_key_width', 22)
        ws3.column_dimensions['B'].width = cfg.get('notes_val_width', 96)
        for rr, (k, v) in enumerate(cfg['notes'], 1):
            v = str(v).format(fur=len(fur), non=len(non), total=len(items),
                              with_photo=sum(1 for i in items if i['photos']),
                              no_photo=sum(1 for i in items if not i['photos']))
            ca = ws3.cell(rr, 1, k)
            ca.font = b.BOLD if k != '标题' else b.TITLE
            ca.alignment = Alignment(vertical='top')
            cb = ws3.cell(rr, 2, v)
            cb.font = b.BODY if k != '标题' else b.TITLE
            cb.alignment = Alignment(vertical='top', wrap_text=True)
            ws3.row_dimensions[rr].height = max(18, 14 * (len(v) // 60 + 1))

    for sh in (ws, ws2):
        sh.page_setup.orientation = 'landscape'
        sh.sheet_properties.pageSetUpPr.fitToPage = True
        sh.page_setup.fitToWidth = 1
        sh.page_setup.fitToHeight = 0
        sh.print_title_rows = '1:3'

    out = cfg['out']
    wb.save(out)
    n_pic = sum(len(i['photos']) for i in items)
    print('已生成', out)
    print('家具 %d 条，非家具 %d 条，照片 %d 张，体积 %.2f MB'
          % (len(fur), len(non), n_pic, os.path.getsize(out) / 1024 / 1024))


if __name__ == '__main__':
    main()
