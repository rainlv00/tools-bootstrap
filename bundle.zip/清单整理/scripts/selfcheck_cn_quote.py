#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""中文报价模板输出（支路 2c）的交付前自检，27 项。

用法：
    python selfcheck_cn_quote.py --config config.material.json [--file out.xlsx]

期望值全在 config.cn_quote.selfcheck；填 null 表示跳过该项。
有 FAIL 就不交付，把失败项原文贴给用户。
"""
import argparse
import json
import os
import re
import sys
import zipfile

import openpyxl
from openpyxl.utils import column_index_from_string, get_column_letter


def deep_merge(base, over):
    import copy
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


DEFAULTS = {
    'tpl_sheet': '报价清单', 'sheet_name': '报价清单',
    'copy_sheets': [], 'overrides': {},
    'layout': {'header_rows': 9, 'detail_start': 10, 'style_row': 10,
               'footer_start': 16, 'footer_rows': 13, 'last_col': 14},
    'columns': {'seq': 1, 'name': 2, 'pic': 3, 'w': 4, 'd': 5, 'h': 6, 'qty': 7,
                'unit': [8, 9, 10], 'price': [11, 12], 'material': 13, 'remark': 14},
    'wrap_cols': [2],
    'selfcheck': {},
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', required=True)
    ap.add_argument('--file', default=None)
    a = ap.parse_args()
    raw = json.load(open(a.config, encoding='utf8'))
    cq = deep_merge(DEFAULTS, raw.get('cn_quote', {}))
    work = raw['work_dir']
    cq.setdefault('items', os.path.join(work, 'items.json'))
    out = a.file or cq['out']
    ly, cols, sc = cq['layout'], cq['columns'], cq['selfcheck']
    tpl = openpyxl.load_workbook(cq['tpl'])[cq['tpl_sheet']]
    wb = openpyxl.load_workbook(out)
    ws = wb[cq['sheet_name']]
    fur = [i for i in json.load(open(cq['items'], encoding='utf8')) if i['furniture']]
    res = []

    def chk(name, ok, detail=''):
        res.append((ok, name, detail))
        print(('PASS  ' if ok else 'FAIL  ') + name + (('  | ' + str(detail)) if detail else ''))

    def expect(key, actual, label=None):
        v = sc.get(key)
        if v is None:
            chk(label or key, True, '跳过（config 为 null）')
        else:
            chk(label or key, actual == v, '实际 %s 期望 %s' % (actual, v))

    C0 = int(ly['detail_start'])
    F = C0 + len(fur)
    hr = int(ly['header_rows'])
    fr = int(ly['footer_rows'])
    fs = int(ly['footer_start'])
    L = int(ly['last_col'])
    first_footer, last_row = F, F + fr - 1

    # A 结构
    chk('01 工作表齐全', cq['sheet_name'] in wb.sheetnames, str(wb.sheetnames))
    exp_fur = sc.get('expected_furniture')
    chk('02 明细行数与家具条数一致',
        len(fur) > 0 and (exp_fur is None or len(fur) == exp_fur),
        '明细 %d 条 / 源 %d 条' % (F - C0, len(fur)))
    chk('03 序号连续',
        [ws.cell(r, cols['seq']).value for r in range(C0, F)] == list(range(1, len(fur) + 1)))

    # overrides 里的单元格本来就允许与模板不同，比对表头时排除。
    # 用正则自己解析坐标，别依赖 openpyxl 的坐标工具（版本间可能不在顶层导出）。
    ov_cells = set()
    for coord in (cq['overrides'] or {}):
        m = re.match(r'^([A-Z]+)(\d+)$', str(coord).strip().upper())
        if m:
            ov_cells.add((int(m.group(2)), column_index_from_string(m.group(1))))
    hdr_diff = [(r, c) for r in range(1, hr + 1) for c in range(1, L + 1)
                if (r, c) not in ov_cells
                and ws.cell(r, c).value != tpl.cell(r, c).value]
    chk('04 表头 1-%d 行与模板一致（overrides 除外）' % hr, not hdr_diff,
        '差异 %d 处 %s' % (len(hdr_diff), hdr_diff[:3]))
    chk('05 表头第 %d 行 %d 列文字与模板一致' % (hr, L),
        all(ws.cell(hr, c).value == tpl.cell(hr, c).value for c in range(1, L + 1)))

    # B 数据口径
    price_cols = [int(x) for x in cols['price']]
    unit_cols = [int(x) for x in cols['unit']]
    chk('06 价格列全空（价格暂不报）',
        all(ws.cell(r, c).value in (None, '') for r in range(C0, F) for c in price_cols))
    chk('07 单位列全空（源表无单位，不编造）',
        all(ws.cell(r, c).value in (None, '') for r in range(C0, F) for c in unit_cols))
    dim_cols = [int(cols['w']), int(cols['d']), int(cols['h'])]
    bad_dim = [(r, c, ws.cell(r, c).value) for r in range(C0, F) for c in dim_cols
               if ws.cell(r, c).value not in (None, '')
               and not isinstance(ws.cell(r, c).value, int)]
    chk('08 尺寸列为数字或空', not bad_dim, '异常 %d %s' % (len(bad_dim), bad_dim[:3]))
    n_dim = sum(1 for r in range(C0, F) for c in dim_cols
                if isinstance(ws.cell(r, c).value, int))
    expect('expected_dim_numbers', n_dim, '09 尺寸未编造（仅明确三段mm才填）')
    missing = [i['sn'] for i in fur
               if not any(str(i['name']) in str(ws.cell(r, cols['remark']).value or '')
                          for r in range(C0, F))]
    chk('10 逐条源名称可回溯（原名写入备注）', not missing, '缺 %s' % missing[:5])

    # C 图片
    prods = [im for im in ws._images
             if im.anchor._from.row + 1 >= C0 and im.anchor._from.row + 1 < F]
    expect('expected_images', len(ws._images), '11 图片总数（logo + 产品）')
    pic_col0 = int(cols['pic']) - 1
    chk('12 产品图锚点全在图片列',
        all(im.anchor._from.col == pic_col0 for im in prods))
    overflow = []
    for im in prods:
        ext = getattr(im.anchor, 'ext', None)
        if ext is None:
            continue
        rr = im.anchor._from.row + 1
        h_pt = ext.height / 9525.0 * 72 / 96
        row_pt = ws.row_dimensions[rr].height or 14.25
        if h_pt > row_pt + 1:
            overflow.append((rr, round(h_pt, 1), round(row_pt, 1)))
    chk('13 图片未超所在行高（不压行）', not overflow,
        '%d 处 %s' % (len(overflow), overflow[:3]))

    # D 页脚 / 版式
    chk('14 页脚 %d 行文字与模板 %d-%d 一致' % (fr, fs, fs + fr - 1),
        all(ws.cell(first_footer + i, 1).value == tpl.cell(fs + i, 1).value
            for i in range(fr)))
    exp_merge = set(str(m) for m in tpl.merged_cells.ranges if m.min_row <= hr)
    got_merge = set(str(m) for m in ws.merged_cells.ranges if m.min_row <= hr)
    chk('15 表头合并区与模板一致', exp_merge == got_merge,
        '模板 %d 输出 %d' % (len(exp_merge), len(got_merge)))
    foot_merge = [str(m) for m in ws.merged_cells.ranges if m.min_row >= first_footer]
    chk('16 页脚合并区齐全', len(foot_merge) == fr, str(len(foot_merge)))
    pa = str(ws.print_area or '').split('!')[-1].replace('$', '')
    exp_pa = sc.get('print_area') or 'A1:%s%d' % (get_column_letter(L), last_row)
    chk('17 打印区', pa == exp_pa, '%s / 期望 %s' % (pa, exp_pa))
    exp_title = '1:%d' % hr
    got_title = str(ws.print_title_rows or '').replace('$', '')
    chk('18 打印设置（横向/适宽/重复表头）',
        ws.page_setup.orientation == 'landscape'
        and ws.page_setup.fitToWidth == 1 and got_title == exp_title,
        '%s/%s/%s' % (ws.page_setup.orientation, ws.page_setup.fitToWidth, got_title))
    fonts = {}
    for r in range(C0, F):
        for c in range(1, L + 1):
            f = ws.cell(r, c).font
            fonts[(f.name, f.sz)] = fonts.get((f.name, f.sz), 0) + 1
    exp_font = sc.get('font')
    chk('19 明细字体统一', (set(fonts) == {(exp_font[0], float(exp_font[1]))}
                          if exp_font else len(set(fonts)) == 1), str(fonts))

    # E 子表 / 文件
    names = cq['copy_sheets'] or [s for s in wb.sheetnames if s != cq['sheet_name']]
    sn = raw.get('sheet_names', {}).get('non') or next((s for s in names if '非家具' in s), None)
    note_name = (raw.get('sheet_names', {}).get('notes')
                 or next((s for s in names if '说明' in s), None))
    if sn and sn in wb.sheetnames:
        non = wb[sn]
        n_non = sum(1 for r in range(4, non.max_row + 1)
                    if isinstance(non.cell(r, 1).value, int))
        exp_non, exp_total = sc.get('expected_non'), sc.get('expected_total')
        ok20 = ((exp_non is None or n_non == exp_non)
                and (exp_total is None or len(fur) + n_non == exp_total))
        chk('20 条数守恒（家具+非家具=源表）', ok20,
            '家具%d + 非家具%d = %d' % (len(fur), n_non, len(fur) + n_non))
        expect('expected_non_images', len(non._images), '21 非家具子表图片保留')
    else:
        chk('20 条数守恒', True, '跳过（未配置子表）')
        chk('21 非家具子表图片保留', True, '跳过（未配置子表）')
    if note_name and note_name in wb.sheetnames:
        txt = '\n'.join(str(c.value or '') for row in wb[note_name].iter_rows() for c in row)
        req = sc.get('required_notes', [])
        chk('22 说明页关键说明齐全', all(k in txt for k in req),
            '缺 %s' % [k for k in req if k not in txt])
    else:
        chk('22 说明页关键说明齐全', True, '跳过（未配置说明页）')
    z = zipfile.ZipFile(out)
    chk('23 zip 完整性', z.testzip() is None)
    size = os.path.getsize(out) / 1024 / 1024
    max_mb = sc.get('max_size_mb', 25)
    chk('24 体积合理', 0.05 < size < max_mb, '%.2f MB' % size)
    bad_ns = any('ns1:' in z.read(n).decode('utf8', errors='ignore')
                 for n in z.namelist() if n.startswith('xl/worksheets/sheet'))
    chk('25 命名空间未损坏', not bad_ns)

    # F 名称列换行（坑 25）
    wrap_missing = [(r, c) for r in range(C0, F) for c in cq['wrap_cols']
                    if not ws.cell(r, int(c)).alignment.wrap_text]
    chk('26 名称列全部自动换行', not wrap_missing,
        '未换行 %d 处 %s' % (len(wrap_missing), wrap_missing[:3]))
    b_col_w = int(ws.column_dimensions[get_column_letter(int(cols['name']))].width or 8.43)

    def disp_width(s):
        return sum(2 if ord(ch) > 127 else 1 for ch in s)

    b_cut = []
    for r in range(C0, F):
        s = str(ws.cell(r, int(cols['name'])).value or '').replace('\n', ' ')
        lines = max(1, -(-disp_width(s) // b_col_w))
        need = lines * 14.5 + 6
        row_h = ws.row_dimensions[r].height or 14.25
        if need > row_h:
            b_cut.append((r, len(s), lines, round(need, 1), round(row_h, 1)))
    chk('27 名称列折行后行高足够（不裁切/不越界）', not b_cut,
        '%d 处 %s' % (len(b_cut), b_cut[:3]))

    fails = [x for x in res if not x[0]]
    print('\n合计 %d 项，通过 %d，失败 %d'
          % (len(res), len(res) - len(fails), len(fails)))
    for _, n, d in fails:
        print('  x', n, d)
    sys.exit(1 if fails else 0)


if __name__ == '__main__':
    main()
