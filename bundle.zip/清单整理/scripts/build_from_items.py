"""items.json（人工整理的清单）-> parsed.json（build_quote 的输入）。

用于「资料只有图纸/效果图、没有电子清单」的项目：先把清单人工整理成
items.json，再用本脚本转成 build_quote 认的结构，后面走通用出表与自检。

items.json 结构：
{
  "rooms": {
    "STANDARD": [
      {"name": "...", "zh": "...", "w": 1800, "d": 2200, "h": null,
       "qty": 1, "unit": "PCS", "rm": "备注",
       "materials": {"OP1": "浅色材质", "OP2": "深色材质"}}
    ]
  },
  "sections": [
    {"code": "OP1-ST", "room": "STANDARD", "scheme": "OP1",
     "en": "SECTION 1 — ...", "zh": "第 1 部分 — ..."}
  ]
}

- 同一房型可被多个 section 复用（不同 scheme / 不同楼层），材质按 scheme 取。
- materials 只有一项时用该项；也可直接给 "material" 单值。
- 尺寸只填图纸明确标注的，不推算；缺的留 null，备注自动补 size TBC。

用法：
    python build_from_items.py --items _work/items.json --out _work/parsed.json
"""
import argparse
import json
import os
from collections import Counter


def _pick(d, scheme):
    """按方案取字典值；没给 scheme 或该方案缺这项时，取第一个非空值。"""
    if not d:
        return ''
    if scheme and scheme in d:
        return d[scheme]
    for v in d.values():
        if v:
            return v
    return ''


def material_of(src, scheme):
    return _pick(src.get('materials'), scheme) or (src.get('material') or '')


def build(items_path, out_path):
    d = json.load(open(items_path, encoding='utf-8'))
    rooms = d.get('rooms') or {}
    sections = d.get('sections') or []
    if not sections:
        # 没给 sections 时，按房型各成一节
        sections = [dict(code=r, room=r, scheme=None, en=r, zh=r) for r in rooms]

    items, seq = [], 0
    for sec in sections:
        arr = rooms.get(sec['room'])
        if arr is None:
            raise SystemExit('sections 引用了不存在的房型: %s' % sec['room'])
        # room_count：该房型的总房量，条目数量 = 单间件数 x 房量
        rc = sec.get('room_count') or 1
        for i, src in enumerate(arr, 1):
            seq += 1
            dims = [src.get(k) for k in ('w', 'd', 'h')]
            size_mm = ' x '.join(str(x) for x in dims if x) if any(dims) else ''
            # build_quote 的备注列只认 remark_override，不读 remark（技能坑 13）
            rm = (src.get('rm') or '').strip()
            if not any(dims):
                rm = (rm + '; size TBC').strip('; ') if rm else 'size TBC'
            if i == 1 and src.get('pic_note'):
                rm = src['pic_note'] + ('; ' + rm if rm else '')
            rm_zh = (src.get('rm_zh') or '').strip()
            if i == 1 and src.get('pic_note_zh'):
                rm_zh = src['pic_note_zh'] + ('；' + rm_zh if rm_zh else '')
            items.append(dict(
                sn=seq,
                name=src.get('name') or '',
                name_zh=src.get('zh') or '',
                material=material_of(src, sec.get('scheme')),
                material_zh=_pick(src.get('materials_zh'), sec.get('scheme')),
                w=src.get('w'), d=src.get('d'), h=src.get('h'),
                dia=bool(src.get('dia')),
                qty=(src.get('qty') or 0) * rc if src.get('qty') else src.get('qty'),
                unit=src.get('unit') or 'PCS',
                remark=rm,
                remark_override=rm or None,
                remark_zh=(rm_zh or None),
                src=sec['code'],
                row=seq,
                code='', ref='%s-%02d' % (sec['code'], i),
                size=size_mm, size_mm=size_mm,
                size_text=None, size_raw=False,
                img=src.get('img'),
            ))

    os.makedirs(os.path.dirname(os.path.abspath(out_path)) or '.', exist_ok=True)
    json.dump({'items': items, 'general_req': []},
              open(out_path, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

    print('生成 %d 条' % len(items))
    for k, v in Counter(i['src'] for i in items).items():
        print('  %-10s %d 条' % (k, v))
    print('无尺寸 %d | 无材质 %d'
          % (sum(1 for i in items if not any(i[k] for k in ('w', 'd', 'h'))),
             sum(1 for i in items if not i['material'])))
    print('->', out_path)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--items', required=True, help='人工整理的 items.json')
    ap.add_argument('--out', required=True, help='输出 parsed.json')
    a = ap.parse_args()
    build(a.items, a.out)
