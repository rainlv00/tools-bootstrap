#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""交付前自检 25 项

用法：
    python selfcheck.py --file out.xlsx [--expect-items 265] [--sheets 方案 中文版] [--cols 13]
"""
import argparse
import os
import re
import sys
import zipfile

import openpyxl

ALLOW = re.compile(r'\b(Sunbrella|PVC|LED|EPS|CNC|HPL|MDF|ECO|Concertex|Canyon|Mushroom'
                   r'|IF|DT|SP|MT|GL|WD|LP)\b', re.I)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--file', required=True)
    ap.add_argument('--en', default='方案')
    ap.add_argument('--zh', default='中文版')
    ap.add_argument('--cols', type=int, default=13)
    ap.add_argument('--header-end', type=int, default=8)
    ap.add_argument('--content-start', type=int, default=9)
    ap.add_argument('--footer-start', type=int, default=None)
    ap.add_argument('--expect-items', type=int, default=None)
    ap.add_argument('--zh-cols', default='2',
                    help='中文表需要译成中文的列；默认只查品名（材质是面料牌号等技术规格，不译）')
    a = ap.parse_args()

    wb = openpyxl.load_workbook(a.file)
    en, zh = wb[a.en], wb[a.zh]
    C0, H, COLS = a.content_start, a.header_end, a.cols

    # 页脚起点：A 列以数字条款开头的第一行
    F = a.footer_start
    if F is None:
        for r in range(en.max_row, C0, -1):
            v = en.cell(r, 1).value
            if isinstance(v, str) and v.strip()[:2] in ('1.', '2.'):
                F = r
        if F is None:
            F = en.max_row

    res = []

    def chk(name, ok, detail=''):
        res.append((ok, name, detail))
        print(('PASS  ' if ok else 'FAIL  ') + name + (('  | ' + str(detail)) if detail else ''))

    def area(ws):
        v = ws.print_area
        v = v[0] if isinstance(v, list) else v
        return v.split('!')[-1].strip("'\"").replace('$', '')

    # A 结构
    chk('01 两张工作表存在', en and zh, f'{a.en} / {a.zh}')
    chk('02 行数一致', en.max_row == zh.max_row, f'EN={en.max_row} ZH={zh.max_row}')
    chk('03 列数不超限', en.max_column <= COLS and zh.max_column <= COLS,
        f'{en.max_column}/{zh.max_column}')
    chk('04 合并区数量一致', len(en.merged_cells.ranges) == len(zh.merged_cells.ranges),
        f'{len(en.merged_cells.ranges)}/{len(zh.merged_cells.ranges)}')
    chk('05 打印区域一致', area(en) == area(zh), f'{area(en)} / {area(zh)}')

    # B 内容
    def items(ws):
        return [r for r in range(C0, F) if isinstance(ws.cell(r, 1).value, int)]

    n_en, n_zh = len(items(en)), len(items(zh))
    exp = a.expect_items
    chk('06 明细条数', n_en == n_zh and (exp is None or n_en == exp),
        f'EN={n_en} ZH={n_zh}' + (f' 期望={exp}' if exp else ''))

    def secs(ws):
        return sum(1 for r in range(C0, F)
                   if isinstance(ws.cell(r, 1).value, str) and ws.cell(r, 1).value)

    chk('07 区段数一致', secs(en) == secs(zh), f'{secs(en)}/{secs(zh)}')

    bad_num, bad_fmt, empty, txt_n = [], [], 0, []
    for r in items(en):
        vals = [en.cell(r, c).value for c in (4, 5, 6)]
        if all(v in (None, '') for v in vals):
            empty += 1
        for c, v in zip((4, 5, 6), vals):
            if v in (None, ''):
                continue
            if isinstance(v, str):
                # 洁具/五金/固装的 SIZE 是型号或材料规格（LCN 1460T、Thickness 16
                # Length 2400），按原文放规格列，属于正常文本，不算错误；
                # 只拦纯数字文本、TBC/NA 这类占位符。
                t = v.strip()
                if len(t) >= 3 and re.search(r'[A-Za-z]', t) and (
                        re.search(r'\d', t)
                        or re.search(r'tbc|see|refer|detail|drawing|plan', t, re.I)):
                    txt_n.append((r, c, t))
                else:
                    bad_num.append((r, c, v))
            elif not isinstance(v, (int, float)):
                bad_num.append((r, c, v))
            elif en.cell(r, c).number_format not in ('#,##0', '"Ø"#,##0'):
                bad_fmt.append((r, c, en.cell(r, c).number_format))
    chk('08 尺寸列格式', not bad_num,
        f'非数字{len(bad_num)} 规格文本{len(txt_n)} 空尺寸{empty}')
    chk('09 尺寸格式统一', not bad_fmt, f'异常{len(bad_fmt)}')

    # C 字体
    def is_alert(f):
        try:
            return str(f.color.rgb).upper().endswith('FF0000')
        except Exception:
            return False

    def fonts(ws):
        s, b, n, alert = {}, {}, {}, 0
        for r in items(ws):
            for c in range(1, COLS + 1):
                f = ws.cell(r, c).font
                s[f.sz] = s.get(f.sz, 0) + 1
                n[f.name] = n.get(f.name, 0) + 1
                if is_alert(f):
                    alert += 1                 # 红色警示行豁免字重检查
                else:
                    b[bool(f.b)] = b.get(bool(f.b), 0) + 1
        return s, b, n, alert

    for ws, tag in ((en, 'EN'), (zh, 'ZH')):
        s, b, n, alert = fonts(ws)
        chk(f'10{tag} 字号统一', len(s) == 1, str(s))
        chk(f'11{tag} 字重统一', list(b) == [False],
            str(b) + (f' (红字豁免 {alert} 格)' if alert else ''))
        chk(f'12{tag} 字体族统一', len(n) == 1, str(n))

    hb = set()
    for c in range(1, COLS + 1):
        ce = en.cell(H, c)
        if type(ce).__name__ == 'MergedCell':
            continue
        hb.add((bool(ce.font.b), bool(zh.cell(H, c).font.b)))
    chk('13 表头行加粗一致', hb == {(True, True)}, str(hb))

    # D 一致性
    mm = []
    for r in items(en):
        for c in (1, 4, 5, 6, 7, 8, 9, 10):
            if en.cell(r, c).value != zh.cell(r, c).value:
                mm.append((r, c))
    chk('14 两表数值一致', not mm, f'差异{len(mm)} 处 {mm[:3]}')

    zh_cols = [int(x) for x in str(a.zh_cols).split(',') if x.strip()]
    left = []
    for r in items(zh):
        for c in zh_cols:
            v = zh.cell(r, c).value
            if not v:
                continue
            t = re.sub(r'（原文拼写[^）]*）', '', str(v))
            t = ALLOW.sub('', t)
            # 品名必须译成中文；允许夹品牌/系列/型号（<=3 个英文词），
            # 但不允许整句英文。材质列是客户面料牌号等技术规格，不列为翻译项。
            words = re.findall(r'[A-Za-z]{3,}', t)
            if c == 2:
                if not re.search(r'[\u4e00-\u9fa5]', str(v)) or len(words) > 3:
                    left.append((r, c, str(v)[:40]))
            elif words:
                left.append((r, c, str(v)[:40]))
    chk('15 中文表品名已译（英文仅限品牌/型号）', not left,
        f'{len(left)} 处 {[(x[0], x[1]) for x in left[:3]]}')

    ea = sorted((im.anchor._from.row, im.anchor._from.col) for im in en._images)
    za = sorted((im.anchor._from.row, im.anchor._from.col) for im in zh._images)
    chk('16 图片数量一致', len(en._images) == len(zh._images),
        f'{len(en._images)}/{len(zh._images)}')
    def overflow(ws):
        """图片显示高度不得超过所在行高（pt），否则会压到下面几行。"""
        bad = []
        for im in ws._images:
            ext = getattr(im.anchor, 'ext', None)
            if ext is None:
                continue
            r = im.anchor._from.row + 1
            c = im.anchor._from.col + 1
            h_pt = ext.height / 9525.0 * 72 / 96        # px -> pt
            # 图片锚点若在合并区内（如 logo 占 A2:B3），可用高度 = 合并区行高之和
            row_pt = ws.row_dimensions[r].height or 14.25
            for mg in ws.merged_cells.ranges:
                if mg.min_row <= r <= mg.max_row and mg.min_col <= c <= mg.max_col:
                    row_pt = sum((ws.row_dimensions[i].height or 14.25)
                                 for i in range(mg.min_row, mg.max_row + 1))
                    break
            if h_pt > row_pt + 1:
                bad.append((r, round(h_pt, 1), round(row_pt, 1)))
        return bad

    ob, zb = overflow(en), overflow(zh)
    chk('16b 图片未超出所在行高', not ob, f'{len(ob)} 处 例{ob[:3]}')
    chk('16c 中文表图片未超行高', not zb, f'{len(zb)} 处 例{zb[:3]}')

    chk('17 图片锚点一致', ea == za, f'差异{len(set(ea) ^ set(za))}')

    chk('18 页脚留在原位',
        all(isinstance(en.cell(r, 1).value, str) for r in range(F, en.max_row + 1)),
        f'{F}-{en.max_row}')
    chk('19 页脚两表一致',
        all(en.cell(r, 1).value == zh.cell(r, 1).value for r in range(F, en.max_row + 1)))

    # E 文件
    z = zipfile.ZipFile(a.file)
    chk('20 zip 完整性', z.testzip() is None)
    size = os.path.getsize(a.file) / 1024 / 1024
    chk('21 体积合理', 0.05 < size < 25, '%.2f MB' % size)
    bad_ns = False
    for n in z.namelist():
        if n.startswith('xl/worksheets/sheet'):
            if 'ns1:' in z.read(n).decode('utf8'):
                bad_ns = True
    chk('22 命名空间未损坏', not bad_ns)

    fails = [r for r in res if not r[0]]
    print('\n合计 %d 项，通过 %d，失败 %d' % (len(res), len(res) - len(fails), len(fails)))
    for _, n, d in fails:
        print('  ✗', n, d)
    return 1 if fails else 0


if __name__ == '__main__':
    sys.exit(main())
