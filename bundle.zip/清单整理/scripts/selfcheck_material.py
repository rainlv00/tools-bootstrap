#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""拆分表（家具主表 + 非家具子表 + 说明页）交付前自检。

用法：
    python selfcheck_material.py --config config.material.json [--file out.xlsx]

与 selfcheck.py 的区别：selfcheck.py 校验「英文主表 + 中文子表」报价单；
本脚本校验「一条源清单拆成家具/非家具两张表」的结果，核心是条数守恒、
品类不串、图片不压行。
"""
import argparse
import json
import os
import re
import sys
import zipfile

import openpyxl
from openpyxl.utils import column_index_from_string


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', required=True)
    ap.add_argument('--file', default=None)
    a = ap.parse_args()
    cfg = json.load(open(a.config, encoding='utf8'))
    path = a.file or cfg['out']
    sc = cfg.get('selfcheck', {})
    names = cfg['sheet_names']
    photo_col = column_index_from_string(cfg.get('photo', {}).get('col', 'J')) - 1  # 0-based

    wb = openpyxl.load_workbook(path)
    res = []

    def chk(name, ok, detail=''):
        res.append((ok, name, detail))
        print(('PASS  ' if ok else 'FAIL  ') + name + (('  | ' + str(detail)) if detail else ''))

    def body_rows(ws):
        """明细行 = A 列是 int 序号的行（排除分区标题行与合计行）。"""
        return [r for r in range(4, ws.max_row + 1)
                if isinstance(ws.cell(r, 1).value, int)]

    # A 结构
    expected_sheets = [names['furniture'], names['non']]
    if cfg.get('notes'):
        expected_sheets.append(names.get('notes', '说明'))
    chk('01 工作表齐全且顺序正确',
        all(s in wb.sheetnames for s in expected_sheets),
        f"{wb.sheetnames}")

    fur_ws, non_ws = wb[names['furniture']], wb[names['non']]
    fr, nr = body_rows(fur_ws), body_rows(non_ws)

    exp_f = sc.get('expected_furniture')
    exp_n = sc.get('expected_non')
    chk('02 家具条数', exp_f is None or len(fr) == exp_f,
        f'实际={len(fr)} 期望={exp_f}')
    chk('03 非家具条数', exp_n is None or len(nr) == exp_n,
        f'实际={len(nr)} 期望={exp_n}')
    exp_t = sc.get('expected_total')
    chk('04 条数守恒（家具+非家具=源表）',
        exp_t is None or len(fr) + len(nr) == exp_t,
        f'{len(fr)}+{len(nr)}={len(fr) + len(nr)} 源表={exp_t}')

    fseq = [fur_ws.cell(r, 1).value for r in fr]
    nseq = [non_ws.cell(r, 1).value for r in nr]
    chk('05 家具序号连续无重复',
        fseq == list(range(1, len(fr) + 1)), f'{fseq[:5]}...{fseq[-3:]}')
    chk('06 非家具序号连续无重复',
        nseq == list(range(1, len(nr) + 1)), f'{nseq[:5]}...{nseq[-3:]}')

    # B 品类不串
    cls = cfg.get('classify', {})
    kinds = set(str(v) for v in cfg.get('furniture_kinds', {}).values())
    kinds.add(cfg.get('default_furniture_kind', '活动家具'))
    bad_kind = [(r, fur_ws.cell(r, 2).value) for r in fr
                if str(fur_ws.cell(r, 2).value) not in kinds]
    chk('07 家具分类值域合法', not bad_kind, f'异常{len(bad_kind)} {bad_kind[:3]}')

    sub_order = cfg.get('sub_order') or (
        [s[0] for s in cls.get('non_furniture_subs', [])]
        + [cls.get('other_vendor_label', '其他（家具厂供货但非家具）'),
           cls.get('other_unknown_label', '其他（未归类）')])
    bad_sub = [(r, non_ws.cell(r, 2).value) for r in nr
               if str(non_ws.cell(r, 2).value) not in sub_order]
    chk('08 非家具分组值域合法', not bad_sub, f'异常{len(bad_sub)} {bad_sub[:3]}')

    non_words = [k for _, keys in cls.get('non_furniture_subs', []) for k in keys]
    furn_words = cls.get('furniture_keys', [])
    excl = cls.get('keyword_exclusions', {})

    # 自检必须复用与解析脚本完全相同的分类优先级，否则会造出假 FAIL：
    # 「电视柜」含「电视」但属家具；有备注说明的混合/改判条目是有意为之。
    def hit(n, k):
        return k in n and not any(x in n for x in excl.get(k, []))

    def noted(ws, r):
        return bool(str(ws.cell(r, 9).value or '').strip())

    def furn_hit(ws, r):
        n = str(ws.cell(r, 3).value or '')
        return any(hit(n, k) for k in furn_words)

    leak_f = [(r, fur_ws.cell(r, 3).value) for r in fr
              if any(hit(str(fur_ws.cell(r, 3).value or ''), k) for k in non_words)
              and not furn_hit(fur_ws, r) and not noted(fur_ws, r)]
    chk('09 家具表无非家具关键词残留', not leak_f,
        f'{len(leak_f)} 处 {[x[1] for x in leak_f[:2]]}')
    leak_n = [(r, non_ws.cell(r, 3).value) for r in nr
              if any(hit(str(non_ws.cell(r, 3).value or ''), k) for k in furn_words)
              and not noted(non_ws, r)]
    chk('10 非家具表无家具关键词误入', not leak_n,
        f'{len(leak_n)} 处 {[x[1] for x in leak_n[:2]]}')

    # 源表可能有空名称行，只要备注写清推定依据就允许
    empty_kw = sc.get('empty_name_note_keywords', ['推定', '名称为空', '待确认'])
    empty_names = []
    for ws, rows, tag in ((fur_ws, fr, '家具'), (non_ws, nr, '非家具')):
        for r in rows:
            if not str(ws.cell(r, 3).value or '').strip():
                rem = str(ws.cell(r, 9).value or '')
                if not any(k in rem for k in empty_kw):
                    empty_names.append((tag, r, rem[:30]))
    chk('11 空名称行均注明推定依据', not empty_names,
        f'{len(empty_names)} 处 {empty_names[:2]}')

    # C 字体
    def is_alert(f):
        try:
            return str(f.color.rgb).upper().endswith('FF0000')
        except Exception:
            return False

    def font_stat(ws, rows):
        sz, fam, bold = {}, {}, {}
        for r in rows:
            for c in range(1, len(cfg['output_columns']) + 1):
                f = ws.cell(r, c).font
                sz[f.sz] = sz.get(f.sz, 0) + 1
                fam[f.name] = fam.get(f.name, 0) + 1
                if not is_alert(f):
                    bold[bool(f.b)] = bold.get(bool(f.b), 0) + 1
        return sz, fam, bold

    for ws, rows, tag in ((fur_ws, fr, '家具'), (non_ws, nr, '非家具')):
        sz, fam, bold = font_stat(ws, rows)
        exp_size = float(cfg.get('fonts', {}).get('size', 9))
        chk(f'12{tag} 明细字号统一', set(sz) == {exp_size}, str(sz))
        chk(f'13{tag} 字体族统一', len(fam) == 1, str(fam))
        chk(f'14{tag} 明细字重统一（红字豁免）', list(bold) == [False], str(bold))

    hdr = [bool(fur_ws.cell(3, c).font.b) for c in range(1, len(cfg['output_columns']) + 1)]
    chk('15 表头行全部加粗', all(hdr), f'{sum(hdr)}/{len(hdr)}')

    def qty_ok(v):
        if v in (None, ''):
            return True
        if isinstance(v, (int, float)):
            return True
        # 源表数量列常是纯数字字符串，或带单位/括注（如「40㎡（不包含损耗）」、
        # 甚至多行面积说明「墙面2.16㎡\n地面6㎡…」），一律原样搬运。
        # 数字开头、或含面积/长度单位即合法；真正要拦的是 '-' / 'TBC' / '待定' 这类脏值。
        s = str(v).strip()
        units = sc.get('qty_text_units', ['㎡', 'm²', '平方米', '平米', '延米', '毫米', 'mm'])
        return bool(re.match(r'^\d', s)) or any(u in s for u in units)

    bad_qty = [(r, ws.cell(r, 6).value) for ws, rows in ((fur_ws, fr), (non_ws, nr))
               for r in rows if not qty_ok(ws.cell(r, 6).value)]
    chk('16 数量列为数字/数字串或空', not bad_qty, f'脏值{len(bad_qty)} {bad_qty[:3]}')

    # D 图片
    exp_img = sc.get('expected_images')
    n_img = len(fur_ws._images) + len(non_ws._images)
    chk('17 图片总数', exp_img is None or n_img == exp_img,
        f'实际={n_img} 期望={exp_img}')

    all_imgs = fur_ws._images + non_ws._images
    wrong_col = [(im.anchor._from.row + 1, im.anchor._from.col + 1)
                 for im in all_imgs if im.anchor._from.col != photo_col]
    chk('18 图片锚点全在照片列', not wrong_col,
        f'{len(wrong_col)} 处 {wrong_col[:3]}')

    overflow = []
    for ws, ims in ((fur_ws, fur_ws._images), (non_ws, non_ws._images)):
        for im in ims:
            ext = getattr(im.anchor, 'ext', None)
            if ext is None:
                continue
            r = im.anchor._from.row + 1
            c = im.anchor._from.col + 1
            h_pt = ext.height / 9525.0 * 72 / 96
            row_pt = ws.row_dimensions[r].height or 14.25
            for mg in ws.merged_cells.ranges:
                if mg.min_row <= r <= mg.max_row and mg.min_col <= c <= mg.max_col:
                    row_pt = sum((ws.row_dimensions[i].height or 14.25)
                                 for i in range(mg.min_row, mg.max_row + 1))
                    break
            if h_pt > row_pt + 1:
                overflow.append((r, round(h_pt, 1), round(row_pt, 1)))
    chk('19 图片未超出所在行高（不压行）', not overflow,
        f'{len(overflow)} 处 例{overflow[:3]}')

    # E 说明页 / 打印 / 文件
    if cfg.get('notes'):
        note_ws = wb[names.get('notes', '说明')]
        txt = '\n'.join(str(c.value or '') for row in note_ws.iter_rows() for c in row)
        miss = [k for k in sc.get('required_notes', []) if k not in txt]
        chk('20 说明页关键说明齐全', not miss, f'缺{miss}')

    for ws, tag in ((fur_ws, '家具'), (non_ws, '非家具')):
        # openpyxl 会把 1:3 规范化成 $1:$3，比较前去掉 $
        ptr = str(ws.print_title_rows or '').replace('$', '')
        ok = (ws.page_setup.orientation == 'landscape'
              and ws.page_setup.fitToWidth == 1
              and ptr == '1:3')
        chk(f'21{tag} 打印设置（横向/适宽/重复表头）', ok,
            f'{ws.page_setup.orientation}/{ws.page_setup.fitToWidth}/{ptr}')

    z = zipfile.ZipFile(path)
    chk('22 zip 完整性', z.testzip() is None)
    size = os.path.getsize(path) / 1024 / 1024
    chk('23 体积合理', 0.05 < size < float(sc.get('max_size_mb', 25)), '%.2f MB' % size)
    bad_ns = any('ns1:' in z.read(n).decode('utf8', errors='ignore')
                 for n in z.namelist() if n.startswith('xl/worksheets/sheet'))
    chk('24 命名空间未损坏', not bad_ns)

    fails = [x for x in res if not x[0]]
    print('\n合计 %d 项，通过 %d，失败 %d' % (len(res), len(res) - len(fails), len(fails)))
    for _, n, d in fails:
        print('  ✗', n, d)
    return 1 if fails else 0


if __name__ == '__main__':
    sys.exit(main())
