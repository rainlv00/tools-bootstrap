#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""通用材料报验 / 混合清单解析：拆出「家具」与「非家具」，并归位内嵌照片。

用法：
    python parse_material_list.py --config config.material.json

输入：客户的一张混合材料表（家具 + 五金 / 洁具 / 灯具 / 电器 / 布草 / 餐具 …）
输出：<work_dir>/items.json 与 <work_dir>/img/<src_row>_<i>.jpg

设计要点（都是从实际项目里踩出来的）：
- 列位、分区行、分类词表、人工改判全部由 config 驱动，不硬编码行号/品名。
- 照片按 drawing xml 的 twoCellAnchor 锚点行归属，不按 media 顺序猜图。
- drawing 的 Target 可能是相对路径（../drawings/drawing1.xml）或绝对路径，
  统一用 posixpath.normpath 归一，且兼容带/不带 xdr: 前缀的标签。
- 分类优先级：布草排除 > 人工 override > 家具白名单 > 非家具子类 > 家具厂供货但非家具 > 未归类。
  这套顺序防止「名称里带 LED 灯带的床头软包」被误判成灯具。
"""
import argparse
import io
import json
import os
import posixpath
import re
import zipfile

import openpyxl
from PIL import Image


def cell(ws, r, i):
    v = ws.cell(r, i).value
    return '' if v is None else str(v).strip()


def build_classifier(cfg):
    """返回 classify(sn, name, brand) -> (is_furniture, sub, note)。"""
    c = cfg['classify']
    furn_keys = c.get('furniture_keys', [])
    bedding = c.get('bedding_keys', [])          # 名称里有床字但其实是布草
    vendor = c.get('furniture_vendor_keys', [])  # 家具供应商，但品类可能不是家具
    subs = c.get('non_furniture_subs', [])       # [[子类, [关键词...]], ...]
    override = {int(k): v for k, v in c.get('override', {}).items()}
    # 短关键词会误伤复合家具名：「电视」命中「电视柜」、「灯」命中「床头柜」。
    # keyword_exclusions = {"电视": ["电视柜"], ...}，命中排除词时该关键词不生效。
    excl = c.get('keyword_exclusions', {})
    other_vendor = c.get('other_vendor_label', '其他（家具厂供货但非家具）')
    other_unknown = c.get('other_unknown_label', '其他（未归类）')

    def hit(n, k):
        return k in n and not any(x in n for x in excl.get(k, []))

    def classify(sn, name, brand):
        n, b = str(name or ''), str(brand or '')
        try:
            sni = int(sn)
        except (TypeError, ValueError):
            sni = -1
        # 1. 人工改判最高优先：必须放在所有自动规则之前，否则写了不生效。
        #    （踩过：布草规则排在前面，S/N「装饰抱枕」被「枕」吃掉，override 形同虚设）
        if sni in override:
            sub, note = override[sni]
            return (sub == ''), sub, note
        # 2. 布草/床品排除：名称含「被芯/床单/枕」等，即使同时含「床」也不算家具
        if any(hit(n, k) for k in bedding):
            sub = c.get('bedding_sub', '客房布草及运营用品')
            return False, sub, ''
        # 3. 家具白名单先于非家具子类：防止「床头软包（含LED灯带）」被灯具词吃掉
        if any(k in n for k in furn_keys):
            return True, '', ''
        # 4. 非家具子类（短词按 keyword_exclusions 排除复合家具名）
        for sub, keys in subs:
            if any(hit(n, k) for k in keys):
                return False, sub, ''
        # 5. 家具厂供货但品类不是家具 → 单列待确认，不静默丢弃
        if any(k in b for k in vendor):
            return False, other_vendor, '由家具供应商供货，但品类不是家具，待确认'
        # 6. 未命中
        return False, other_unknown, '未命中任何规则，待人工确认'

    return classify


def drawing_media_map(z, sheet_xml='xl/worksheets/sheet1.xml'):
    """返回 {锚点起始行(1-based): [media_path, ...]}。

    兼容：Target 相对/绝对、drawingN.xml 前缀 xdr: 可有可无。
    """
    rels_path = posixpath.join(posixpath.dirname(sheet_xml), '_rels',
                               posixpath.basename(sheet_xml) + '.rels')
    try:
        sheet_rels = z.read(rels_path).decode('utf8', errors='ignore')
    except KeyError:
        return {}
    m = re.search(r'Target="([^"]*drawing\d+\.xml)"', sheet_rels)
    if not m:
        return {}
    tgt = m.group(1)
    draw_path = (tgt.lstrip('/') if tgt.startswith('/')
                 else posixpath.normpath(posixpath.join(posixpath.dirname(sheet_xml), tgt)))
    try:
        draw = z.read(draw_path).decode('utf8', errors='ignore')
    except KeyError:
        return {}
    drels_path = posixpath.join(posixpath.dirname(draw_path), '_rels',
                                posixpath.basename(draw_path) + '.rels')
    try:
        drels = z.read(drels_path).decode('utf8', errors='ignore')
    except KeyError:
        return {}
    rid2media = dict(re.findall(r'Id="(rId\d+)"[^>]*Target="([^"]+)"', drels))

    imgs = {}
    tag = r'(?:xdr:)?'
    for blk in re.findall(r'<%stwoCellAnchor.*?</%stwoCellAnchor>' % (tag, tag), draw, re.S):
        r0 = re.search(r'<%sfrom>\s*<%scol>(\d+)</%scol>.*?<%srow>(\d+)</%srow>'
                       % (tag, tag, tag, tag, tag), blk, re.S)
        rid = re.search(r'r:embed="(rId\d+)"', blk)
        if not (r0 and rid):
            continue
        row = int(r0.group(2)) + 1
        media_tgt = rid2media.get(rid.group(1))
        if not media_tgt:
            continue
        # rels 的 Target 相对 drawings/ 目录，可能是 ../media/image1.png
        media = posixpath.normpath(posixpath.join(posixpath.dirname(draw_path), media_tgt))
        imgs.setdefault(row, []).append(media)
    return imgs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', required=True)
    a = ap.parse_args()
    cfg = json.load(open(a.config, encoding='utf8'))

    src = cfg['src']
    work = cfg['work_dir']
    img_dir = os.path.join(work, 'img')
    os.makedirs(img_dir, exist_ok=True)
    cols = cfg['columns']
    photo_cfg = cfg.get('photo', {})
    max_photos = int(photo_cfg.get('max_photos', 2))
    max_px = int(photo_cfg.get('max_px', 480))
    do_photos = photo_cfg.get('enabled', True)

    wb = openpyxl.load_workbook(src, data_only=True)
    ws = wb[cfg['sheet']]
    classify = build_classifier(cfg)

    items, section = [], ''
    for r in range(int(cfg.get('content_start', 4)), ws.max_row + 1):
        sn, name = cell(ws, r, cols['sn']), cell(ws, r, cols['name'])
        if not sn and not name:
            continue
        if not sn:                                   # 无序号 = 分区标题行
            section = name
            continue
        it = {'src_row': r, 'sn': sn, 'section': section}
        for key, ci in cols.items():
            if key not in ('sn', 'name'):
                it[key] = cell(ws, r, ci)
        it['name'] = name
        items.append(it)

    z = zipfile.ZipFile(src)
    imgs = drawing_media_map(z) if do_photos else {}
    for it in items:
        paths = []
        for i, media in enumerate(imgs.get(it['src_row'], [])[:max_photos]):
            try:
                im = Image.open(io.BytesIO(z.read(media))).convert('RGB')
            except Exception:
                continue
            if max(im.size) > max_px:
                k = max_px / max(im.size)
                im = im.resize((int(im.width * k), int(im.height * k)), Image.LANCZOS)
            p = os.path.join(img_dir, '%d_%d.jpg' % (it['src_row'], i))
            im.save(p, 'JPEG', quality=80, optimize=True)
            paths.append(p)
        it['photos'] = paths
        ok, sub, note = classify(it['sn'], it['name'], it.get('brand', ''))
        it.update(furniture=ok, sub=sub, note=note)

    out = os.path.join(work, 'items.json')
    json.dump(items, open(out, 'w', encoding='utf8'), ensure_ascii=False, indent=1)

    fur = [i for i in items if i['furniture']]
    non = [i for i in items if not i['furniture']]
    print('条目 %d | 家具 %d | 非家具 %d | 有照片 %d'
          % (len(items), len(fur), len(non), sum(1 for i in items if i['photos'])))
    from collections import Counter
    print('\n非家具分类:')
    for k, v in Counter(i['sub'] for i in non).most_common():
        print('  %-24s %d' % (k, v))
    print('\n需人工确认:')
    for i in items:
        if i['note']:
            print('  SN%-4s %-30s %s' % (i['sn'], i['name'].replace('\n', '/')[:30], i['note']))
    print('\n已写出', out)


if __name__ == '__main__':
    main()
