#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""parsed.json + 英文模板 -> 报价单（英文主表 + 中文子表）

用法：
    python build_quote.py --config _work/config.json
"""
import argparse
import bisect
import io
import json
import os
import re
import shutil
import zipfile
import xml.etree.ElementTree as ET
from copy import copy

import openpyxl
from openpyxl.drawing.image import Image
from openpyxl.drawing.spreadsheet_drawing import OneCellAnchor, AnchorMarker
from openpyxl.drawing.xdr import XDRPositiveSize2D
from openpyxl.utils.units import pixels_to_EMU
from openpyxl.utils import column_index_from_string
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import range_boundaries
from PIL import Image as PImage

from glossary import translate_material, translate_name

SEC_FILL = PatternFill('solid', fgColor='FFE8E4D9')
THIN = Side(style='thin', color='FF9E9E9E')
SEC_BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
REMARK_ZH = {'unit TBC': '单位待定', 'size TBC': '规格待定',
             'material TBC': '材质待定', 'no IF ref': '无型号编号'}


# ---------------- 尺寸 ----------------
def tpl_path(p):
    """模板路径不存在时，回退到本技能自带的 assets/templates/ 同名文件。"""
    if not p:
        return p
    if os.path.exists(p):
        return p
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    cand = os.path.join(here, 'assets', 'templates',
                        os.path.basename(str(p).replace('\\', '/')))
    if os.path.exists(cand):
        print('模板路径不存在，改用技能自带模板：%s' % cand)
        return cand
    return p


def size_cells(text):
    t = str(text or '').strip()
    if not t:
        return [('', False)] * 3
    out = [('', False)] * 3
    slot = 0
    for p in [x.strip() for x in re.split(r'\s*[xX×]\s*', t) if x.strip()]:
        m = re.search(r'(\d+(?:\.\d+)?)', p)
        if not m:
            continue
        num = float(m.group(1))
        num = int(num) if num == int(num) else num
        low = p.lower()
        if 'dia' in low or 'Ø' in p:
            out[1] = (num, True)
            continue
        if re.search(r'\bH\b', p):
            out[2] = (num, False)
            continue
        if re.search(r'\bL\b', p):
            out[0] = (num, False)
            continue
        while slot < 3 and out[slot][0] != '':
            slot += 1
        if slot < 3:
            out[slot] = (num, False)
            slot += 1
    return out



def place_pic(ws, row, path, box_w, box_h, col='C'):
    """贴图，并按图片实际显示尺寸决定行高。

    两个坑：
    1. 行高原先只按文字长度算，图纸比行高大，锚点在图左上角，溢出部分压到
       下面几行（实测 4 行图叠成一团）。这里改为「行高 = max(文字需要, 图片高+留白)」。
    2. `ws.add_image(pic, 'C12')` 传字符串时 openpyxl 保存阶段才生成 anchor，
       此时改 `pic.anchor._from.rowOff` 无效（anchor 还是 str）。要垂直居中必须
       自己构造 OneCellAnchor。
    """
    pic = Image(path)
    ratio = min(box_w / pic.width, box_h / pic.height, 1)
    w, h = pic.width * ratio, pic.height * ratio

    need = h * 72 / 96 + 6                       # px -> pt，另加 6pt 上下留白
    cur = ws.row_dimensions[row].height or 14.25
    row_h = max(cur, need)
    ws.row_dimensions[row].height = row_h

    off_px = max(int((row_h - need) / 2 * 96 / 72), 0)   # 行比图高时垂直居中
    marker = AnchorMarker(col=column_index_from_string(col) - 1,
                          colOff=pixels_to_EMU(6),
                          row=row - 1,
                          rowOff=pixels_to_EMU(off_px))
    pic.anchor = OneCellAnchor(_from=marker,
                               ext=XDRPositiveSize2D(pixels_to_EMU(w), pixels_to_EMU(h)))
    ws.add_image(pic)
    return w, h

def unit_norm(u):
    u = str(u or '').strip().lower()
    return {'pcs': 'PCS', 'pc': 'PCS', 'set': 'SET', 'sets': 'SET',
            'lot': 'LOT', 'm': 'M', 'sqm': 'SQM', '': ''}.get(u, u.upper())


def remark_of(it):
    bits = []
    if not it['unit']:
        bits.append('unit TBC')
    if not (it.get('size_mm') or it.get('size_text') or it['size']):
        bits.append('size TBC')
    if not it['material']:
        bits.append('material TBC')
    if not it['code'] and not it.get('ref') and not str(it['src']).startswith('BUILT'):
        bits.append('no IF ref')
    return '; '.join(bits)


# ---------------- 图片 ----------------
def collect_images(cfg, items):
    """按 (src, row) 归属；锚点行常比条目首行早 1 行，用 bisect(row+1)。"""
    img_dir = cfg['images_dir']
    os.makedirs(img_dir, exist_ok=True)
    out = {}
    for src in cfg['sources']:
        wb = openpyxl.load_workbook(src['file'])
        for sh in src['sheets']:
            label = sh['label']
            rows = sorted(i['row'] for i in items if i['src'] == label)
            if not rows:
                continue
            pool = {}
            for im in wb[sh['name']]._images:
                try:
                    ar = im.anchor._from.row + 1
                except Exception:
                    continue
                pool.setdefault(ar, im._data())
            for ar, data in pool.items():
                k = bisect.bisect_right(rows, ar + 1) - 1
                if k < 0:
                    continue
                key = (label, rows[k])
                if key in out:
                    continue
                p = os.path.join(img_dir, f'{label}_{rows[k]}.jpg')
                try:
                    pic = PImage.open(io.BytesIO(data)).convert('RGB')
                    if max(pic.size) > 520:
                        sc = 520 / max(pic.size)
                        pic = pic.resize((int(pic.width * sc), int(pic.height * sc)), PImage.LANCZOS)
                    pic.save(p, 'JPEG', quality=82, optimize=True)
                    out[key] = p
                except Exception as e:            # noqa: BLE001
                    print('  图片转换失败', label, rows[k], e)
        wb.close()
    print('图片归属 %d 张' % len(out))
    return out


# ---------------- 主体 ----------------
def build(cfg):
    H_END = cfg.get('header_end', 8)
    C_START = cfg.get('content_start', 9)
    F_START = cfg.get('footer_start', 45)
    F_END = cfg.get('footer_end', 51)
    COLS = cfg.get('cols', 13)
    F_EN = cfg.get('fonts', {}).get('en', 'Arial')
    F_ZH = cfg.get('fonts', {}).get('zh', '宋体')
    FS = cfg.get('fonts', {}).get('size', 9)
    ROW_H = cfg.get('row_height', 80)
    AUTO_H = cfg.get('auto_height', 0)
    PIC_W = cfg.get('pic_w', 96)
    PIC_H = cfg.get('pic_h', 62)
    DWG = {str(k).strip(): v for k, v in (cfg.get('drawing_map') or {}).items()}
    DWG_MODE = cfg.get('drawing_mode', 'all')
    dwg_used = set()

    data = json.load(open(cfg['parsed'], encoding='utf8'))
    items = data['items']
    by_src = {}
    for i in items:
        by_src.setdefault(i['src'], []).append(i)

    imgs = collect_images(cfg, items)

    wb = openpyxl.load_workbook(tpl_path(cfg['template']), data_only=False)
    ws = wb[cfg.get('sheet_name', '方案')]

    # 保留表头图片
    ws._images = [im for im in ws._images if im.anchor._from.row < H_END]
    for im in ws._images:
        im.ref = io.BytesIO(im._data())

    for col, w in (cfg.get('col_widths') or {}).items():
        ws.column_dimensions[col].width = w

    content_style = [copy(ws.cell(C_START, c)._style) for c in range(1, COLS + 1)]

    # 存表尾
    f_cells, f_heights, f_merges = {}, {}, []
    for r in range(F_START, F_END + 1):
        for c in range(1, COLS + 1):
            cell = ws.cell(r, c)
            f_cells[(r, c)] = {'v': cell.value, 's': copy(cell._style),
                               'fmt': cell.number_format}
        f_heights[r] = ws.row_dimensions[r].height
    for m in list(ws.merged_cells.ranges):
        mn_c, mn_r, mx_c, mx_r = range_boundaries(str(m))
        if mn_r >= F_START:                       # 只收表尾的合并
            f_merges.append((mn_c, mn_r, mx_c, mx_r))
            ws.unmerge_cells(str(m))
        elif mn_r >= C_START:                     # 明细区合并只拆不存
            ws.unmerge_cells(str(m))

    # 组装行
    plan = []
    for sec in cfg['sections']:
        plan.append(('sec', sec))
        for it in by_src.get(sec['src'], []):
            plan.append(('item', it))
    add = cfg.get('addendum')
    if add and add.get('items'):
        plan.append(('sec', {'en': add['en_title'], 'zh': add['zh_title']}))
        for a in add['items']:
            plan.append(('add', a))

    extra = len(plan) - (F_START - C_START)
    if extra > 0:
        ws.insert_rows(F_START, extra)
    footer_start = F_START + extra
    last_row = footer_start + (F_END - F_START)

    for (r, c), d in f_cells.items():
        t = ws.cell(r + extra, c)
        t.value, t.number_format = d['v'], d['fmt']
        t._style = copy(d['s'])
    for mn_c, mn_r, mx_c, mx_r in f_merges:
        ws.merge_cells(start_row=mn_r + extra, start_column=mn_c,
                       end_row=mx_r + extra, end_column=mx_c)
    for r, h in f_heights.items():
        if h:
            ws.row_dimensions[r + extra].height = h

    BODY = Font(name=F_EN, size=FS)
    BOLD = Font(name=F_EN, size=FS, bold=True)
    ALERT = Font(name=F_EN, size=FS, bold=True, color='FFFF0000')

    for c in range(1, COLS + 1):
        cell = ws.cell(H_END, c)
        cell.font = BOLD
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)

    seq = 0
    meta = []
    for off, (kind, payload) in enumerate(plan):
        r = C_START + off
        ws.row_dimensions[r].height = 26 if kind == 'sec' else ROW_H
        for c in range(1, COLS + 1):
            cell = ws.cell(r, c)
            if type(cell).__name__ == 'MergedCell':
                continue
            cell.value = None
            cell._style = copy(content_style[c - 1])
            cell.font = BODY

        if kind == 'sec':
            ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=COLS)
            cell = ws.cell(r, 1, payload['en'])
            cell.font = BOLD
            cell.alignment = Alignment(horizontal='left', vertical='center', indent=1)
            for c in range(1, COLS + 1):
                ws.cell(r, c).fill = SEC_FILL
                ws.cell(r, c).border = SEC_BORDER
            meta.append((r, 'sec', payload))
            continue

        seq += 1
        if kind == 'add':
            w, d, h = 3 * [('', False)]
            vals = [seq, payload['name'], None, payload.get('w'), payload.get('d'),
                    payload.get('h'), None, payload.get('unit', 'SET'), None, None,
                    payload.get('material_en', 'Refer to addendum drawings'),
                    payload.get('remark_en', ''), payload.get('ref_en', '')]
            meta.append((r, 'add', payload))
        else:
            it = payload
            if it.get('size_raw'):
                # 洁具/五金/固装：SIZE 是型号或材料规格，原文直出；没有短规格就留空，
                # 绝不回退去拆原文（否则 LCN 1460T 又变成 1460×864）
                w, d, h = it.get('size_text') or '', '', ''
                wd = dd = hd = False
            elif any(it.get(k) is not None for k in ('w', 'd', 'h')):
                w, d, h = it.get('w') or '', it.get('d') or '', it.get('h') or ''
                wd = dd = hd = False
                if it.get('dia'):                 # 圆件：直径通常落在 D 列，显示 Ø
                    if d != '':
                        dd = True
                    elif w != '':
                        wd = True
            else:
                (w, wd), (d, dd), (h, hd) = size_cells(it.get('size_mm') or it['size'])
            rem_en = it.get('remark_override') or remark_of(it)
            vals = [seq, it['name'], None, w, d, h, it.get('qty'), unit_norm(it['unit']), None, None,
                    it['material'], rem_en,
                    ('Ref: %s' % (it.get('ref') or it['code']).replace(' ', '')) if (it.get('ref') or it['code']) else '']
            meta.append((r, 'item', it))

        for c, v in enumerate(vals, 1):
            cell = ws.cell(r, c)
            cell.value = v
            cell.font = BODY
            cell.alignment = Alignment(
                vertical='center', wrap_text=c in (2, 11, 12),
                horizontal='center' if c in (1, 4, 5, 6, 7, 8, 9, 10, 13) else 'left')
        if kind == 'item' and it.get('flag'):
            ws.cell(r, 12).font = ALERT
        if kind == 'add' and payload.get('flag'):
            ws.cell(r, 12).font = ALERT

        if AUTO_H:
            txt_len = [len(str(vals[10] or '')) / 30, len(str(vals[11] or '')) / 48,
                       len(str(vals[1] or '')) / 17, len(str(vals[6] or '')) / 26]
            lines = max(max(txt_len), 1)
            ws.row_dimensions[r].height = min(max(30, 10 + lines * 11.5), AUTO_H)

        dias = {4: wd, 5: dd, 6: hd}
        for c in (4, 5, 6):
            cell = ws.cell(r, c)
            v = cell.value
            if isinstance(v, (int, float)):
                cell.number_format = '"Ø"#,##0' if dias.get(c) else '#,##0'
            else:
                cell.number_format = 'General'

        if kind == 'item':
            p = it.get('img') or imgs.get((it['src'], it['row']))
            src_key = str(it['src']).strip()
            if not p and src_key in DWG:
                if DWG_MODE == 'all' or src_key not in dwg_used:
                    p = DWG[src_key]
                    dwg_used.add(src_key)
            if p:
                place_pic(ws, r, p, PIC_W, PIC_H)

    for addr, v in cfg.get('header', {}).items():
        if not addr.startswith('zh_'):
            ws[addr] = v

    ws.print_area = f'A1:M{last_row}'
    ws.print_title_rows = f'1:{H_END}'
    ws.page_setup.orientation = 'landscape'
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0

    # ---------- 中文子表 ----------
    ws_zh = wb.copy_worksheet(ws)
    ws_zh.title = cfg.get('zh_sheet_name', '中文版')
    ws_zh._images = []

    ZF = Font(name=F_ZH, size=FS)
    ZB = Font(name=F_ZH, size=FS, bold=True)

    for addr, v in cfg.get('header', {}).items():
        if addr.startswith('zh_'):
            ws_zh[addr[3:]] = v
    for c, t in cfg.get('header_zh', {}).items():
        ws_zh.cell(H_END, int(c)).value = t
        ws_zh.cell(H_END, int(c)).font = ZB

    for r, kind, payload in meta:
        if kind == 'sec':
            cell = ws_zh.cell(r, 1)
            cell.value = payload['zh']
            cell.font = ZB
        elif kind == 'add':
            ws_zh.cell(r, 2).value = payload.get('zh_name', payload['name'])
            ws_zh.cell(r, 11).value = payload.get('material_zh', '详见增补图纸')
            ws_zh.cell(r, 12).value = payload.get('remark_zh', '')
            ws_zh.cell(r, 13).value = payload.get('ref_zh', '')
        else:
            it = payload
            nm = it.get('name_zh') or translate_name(it['name'])[0]
            mt = it.get('material_zh') or (
                it['material'] if cfg.get('zh_keep_material')
                else translate_material(it['material'])[0])
            if it.get('remark_zh'):
                rm = it['remark_zh']
            elif cfg.get('zh_keep_remark'):
                rm = ws_zh.cell(r, 12).value          # 保留英文备注（材料/供应商等无翻译价值）
            else:
                rm = '；'.join(REMARK_ZH.get(x.strip(), x.strip())
                              for x in remark_of(it).split(';') if x.strip())
            ws_zh.cell(r, 2).value = nm
            ws_zh.cell(r, 11).value = mt
            ws_zh.cell(r, 12).value = rm
            ws_zh.cell(r, 13).value = ('参照：%s' % (it.get('ref') or it['code']).replace(' ', '')
                                       if (it.get('ref') or it['code']) else '')

    for r in range(H_END, last_row + 1):
        for c in range(1, COLS + 1):
            cell = ws_zh.cell(r, c)
            if type(cell).__name__ == 'MergedCell':
                continue
            cell.font = ZF
            if r >= C_START:
                cell.alignment = Alignment(
                    vertical='center', wrap_text=c in (2, 11, 12),
                    horizontal='center' if c in (1, 4, 5, 6, 7, 8, 9, 10, 13) else 'left')
    ZALERT = Font(name=F_ZH, size=FS, bold=True, color='FFFF0000')
    for r, kind, payload in meta:
        if kind in ('item', 'add') and payload.get('flag'):
            ws_zh.cell(r, 2).font = Font(name=F_ZH, size=FS, bold=True, color='FFFF0000')
            ws_zh.cell(r, 12).font = ZALERT
            ws_zh.cell(r, 12).value = payload.get('remark_zh') or ws_zh.cell(r, 12).value
    for c in range(1, COLS + 1):
        ws_zh.cell(H_END, c).font = ZB
    for r, kind, _ in meta:
        if kind == 'sec':
            ws_zh.cell(r, 1).font = ZB

    logo = cfg.get('logo')
    if logo and os.path.exists(logo):
        lg = Image(logo)
        lg.width = cfg.get('logo_w', 150)
        lg.height = cfg.get('logo_h', 89)
        ws_zh.add_image(lg, cfg.get('logo_anchor', 'A2'))

    dwg_used2 = set()
    for r, kind, payload in meta:
        if kind != 'item':
            continue
        p = payload.get('img') or imgs.get((payload['src'], payload['row']))
        src_key2 = str(payload['src']).strip()
        if not p and src_key2 in DWG:
            if DWG_MODE == 'all' or src_key2 not in dwg_used2:
                p = DWG[src_key2]
                dwg_used2.add(src_key2)
        if p:
            place_pic(ws_zh, r, p, PIC_W, PIC_H)

    ws_zh.print_area = f'A1:M{last_row}'
    ws_zh.print_title_rows = f'1:{H_END}'
    ws_zh.page_setup.orientation = 'landscape'
    ws_zh.sheet_properties.pageSetUpPr.fitToPage = True
    ws_zh.page_setup.fitToWidth = 1
    ws_zh.page_setup.fitToHeight = 0

    if DWG and cfg.get('drawings_sheet', True):
        wsd = wb.create_sheet('DRAWINGS')
        wsd.column_dimensions['A'].width = 34
        wsd.column_dimensions['B'].width = 14
        wsd.column_dimensions['C'].width = 96
        wsd['A1'] = 'AREA LAYOUT DRAWINGS (no product photo available in client BOQ)'
        wsd['A1'].font = Font(name=F_EN, size=12, bold=True)
        wsd['A2'] = 'Each image is the furniture layout plan of that area - for location reference only.'
        wsd['A2'].font = Font(name=F_EN, size=9, color='FF808080')
        rr = 4
        for sec in cfg['sections']:
            area = str(sec['src']).strip()
            if area not in DWG:
                continue
            big = DWG[area].replace('_thumb.jpg', '.jpg')
            src_img = big if os.path.exists(big) else DWG[area]
            if not os.path.exists(src_img):
                continue
            wsd.cell(rr, 1, sec['zh']).font = Font(name=F_ZH, size=9)
            wsd.cell(rr, 2, area.split('_')[0]).font = Font(name=F_EN, size=9, bold=True)
            pic = Image(src_img)
            k = min(660 / pic.width, 340 / pic.height, 1)
            pic.width, pic.height = int(pic.width * k), int(pic.height * k)
            wsd.add_image(pic, f'C{rr}')
            wsd.row_dimensions[rr].height = pic.height * 72 / 96 + 12
            rr += 1
        wsd.print_area = f'A1:C{rr - 1}'
        wsd.page_setup.orientation = 'landscape'
        wsd.sheet_properties.pageSetUpPr.fitToPage = True
        wsd.page_setup.fitToWidth = 1
        wsd.page_setup.fitToHeight = 0

    out = cfg['out']
    wb.save(out)

    # 裁掉 M 列之外的空壳
    NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
    REL = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
    ET.register_namespace('', NS)
    ET.register_namespace('r', REL)
    tmp = out + '.tmp'
    removed = 0
    with zipfile.ZipFile(out) as zin:
        targets = [n for n in zin.namelist()
                   if re.match(r'xl/worksheets/sheet\d+\.xml$', n)]
        blob = {}
        for t in targets:
            root = ET.fromstring(zin.read(t))
            max_row = 0
            for row in root.iter(f'{{{NS}}}row'):
                max_row = max(max_row, int(row.get('r')))
                for cell in list(row.findall(f'{{{NS}}}c')):
                    letters = re.match(r'[A-Z]+', cell.get('r')).group(0)
                    idx = 0
                    for ch in letters:
                        idx = idx * 26 + ord(ch) - 64
                    if idx > COLS:
                        row.remove(cell)
                        removed += 1
            dim = root.find(f'{{{NS}}}dimension')
            if dim is not None:
                dim.set('ref', f'A1:M{max_row}')
            blob[t] = ET.tostring(root, encoding='UTF-8', xml_declaration=True)
        with zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED) as zout:
            for item in zin.infolist():
                zout.writestr(item, blob.get(item.filename, zin.read(item.filename)))
    shutil.move(tmp, out)

    n_pic = sum(1 for i in items if i.get('img')) or len(imgs)
    print('已生成 %s' % out)
    print('明细 %d 条 / %d 行 | 表尾 %d-%d | 新增行 %d | 图片 %d | 清理空壳 %d'
          % (seq, len(plan), footer_start, last_row, extra, n_pic, removed))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', required=True)
    a = ap.parse_args()
    build(json.load(open(a.config, encoding='utf8')))


if __name__ == '__main__':
    main()
