# -*- coding: utf-8 -*-
"""某项目 清单中英术语表 + 翻译（词边界匹配，短语优先）"""
import re

NAMES = {
 'Access Chair': '无障碍座椅', 'Armchair': '扶手椅',
 'BACK COUNTER': '后场工作台', 'BACK COUNTER & CABINET': '后场工作台及柜体',
 'BANQUET': '长条卡座', 'BANQUETTE SEATING 1': '卡座 1', 'BANQUETTE SEATING 2': '卡座 2',
 'BAR COUNTER': '吧台', 'BED BASE - DOUBLE BED SIZE': '床架（双人床）',
 'BED BASE - KING SIZE BED': '床架（大床）', 'BEDROOM VANITY COUNTER': '卧室梳妆台',
 'BOOK SHELF': '书架', 'BUFFER COUNTER A': '自助餐台 A', 'BUFFET COUNTER B': '自助餐台 B',
 'BUFFET COUNTER C': '自助餐台 C', 'Bar Stool': '吧椅', 'Bean Chair': '豆袋椅',
 'Bed Bench': '床尾凳', 'Bedside Table': '床头柜', 'Bench': '长凳',
 'Bench @ Gym': '长凳（健身房）', 'Bench @ Living': '长凳（客厅）',
 'Bench @ T&B': '长凳（客房卫浴）', 'C - Table': 'C 型边几', 'COUNTER': '柜台',
 'Chaise Lounge': '贵妃椅', 'Coffee Table': '茶几', 'Coffee Table  B': '茶几 B',
 'Coffee Table A': '茶几 A', 'Coffeee Table': '茶几（原文拼写 Coffeee）',
 'Console Table': '条案', 'Console Table @ Master': '条案（主卧）',
 'Console Table A': '条案 A', 'Console Table B': '条案 B',
 'Console Table at Living': '条案（客厅）', 'Curved Sofa': '弧形沙发',
 'DESSERT STATION': '甜点台', 'DRESSER': '梳妆台', 'Desk Chair': '书桌椅',
 'Desk Chair @ Master': '书桌椅（主卧）', 'Desk Chair @ Study': '书桌椅（书房）',
 'Dinign Chair': '餐椅（原文拼写 Dinign）', 'Dining Chair': '餐椅',
 'Dining Chair A': '餐椅 A', 'Dining Chair B': '餐椅 B', 'Dining Chair C': '餐椅 C',
 'Dining Chair D': '餐椅 D', 'Dining Chair E': '餐椅 E', 'Dining Table': '餐桌',
 'Dining Table  A': '餐桌 A', 'Dining Table A': '餐桌 A', 'Dining Table B': '餐桌 B',
 'Dining Table C': '餐桌 C', 'Dining Table D': '餐桌 D', 'Dresser Chair': '梳妆椅',
 'FEMALE VANITY COUNTER': '女卫梳妆台', 'Focal Table': '中心装饰桌',
 'GROUP CHECK-IN COUNTER': '团队入住柜台', 'Guest Chair': '客椅',
 'HEADBOARD': '床头板', "HEADROOM @  MASTER'S BEDROM": '床头板（主卧）',
 'IF -': '（原文无名称）', 'Kiddie Table': '儿童桌',
 'Kidnew Pillow': '腰枕（原文拼写 Kidnew）', 'Kidney Pillow': '腰枕',
 'LOOSE COUNTER': '活动柜台', 'Louge Chair': '休闲椅（原文拼写 Louge）',
 'Lounge Chair': '休闲椅', 'Lounge Chair @ Living': '休闲椅（客厅）',
 'Lounge Chair @ Master': '休闲椅（主卧）', 'Lounge Chair A': '休闲椅 A',
 'Lounge Chair B': '休闲椅 B', "MAITRE ' D": '迎宾台', 'MALE VANITY COUNTER': '男卫梳妆台',
 'MINIBAR': '迷你吧', 'MIRROR (FOR STUDY DESK)': '镜（书桌用）',
 'MRX - 101': 'MRX-101', 'MRX - 102': 'MRX-102', 'MRX - 121': 'MRX-121', 'MRX - 122': 'MRX-122',
 'Meeting Table': '会议桌', 'Nesting Coffee Table': '套几',
 'Occassional Chair A': '休闲椅 A（原文拼写 Occassional）',
 'Occassional Chair B': '休闲椅 B（原文拼写 Occassional）',
 'Occassional Table': '边几', 'Occassional Table A': '边几 A', 'Occassional Table B': '边几 B',
 'Office Chair A': '办公椅 A', 'Office Chair B': '办公椅 B', 'Office Chair C': '办公椅 C',
 'Ottoman': '脚踏', 'Ottoman B': '脚踏 B', 'Outdoor Communal Table': '户外长桌',
 'Outdoor Continental Table': '户外休闲桌', 'Outdoor Dining Chair': '户外餐椅',
 'Outdoor Dining Table A': '户外餐桌 A', 'Outdoor Dining Table B': '户外餐桌 B',
 'Outdoor Lounge Chair': '户外休闲椅', 'Outdoor Sofa A': '户外沙发 A',
 'PASTISSERIE': '甜点吧台', 'POWDER ROOM VANITY COUNTER': '公卫梳妆台',
 'POWDER ROOM VANITY COUNTER WITH VANITY MIRROR': '公卫梳妆台（含梳妆镜）',
 'PWD TOILET MIRROR WITH CABINET': '无障碍卫生间镜柜', 'RECEPTION COUNTER': '接待台',
 'RECEPTION COUNTER AND BACK SCREEN': '接待台及背屏', 'Reception Chair': '接待椅',
 'Reception Table': '接待桌', 'Receptionist Chair': '接待员椅', 'SCREEN WALL': '屏风墙',
 'SERVICE COUNTER': '服务台', 'SHELVES A': '搁架 A', 'SHELVES B': '搁架 B',
 'SHELVES C': '搁架 C', 'SHELVES D': '搁架 D', 'STUDY DESK': '书桌',
 'Sculptural Seating': '艺术造型座椅', 'Sculptural Seating A': '艺术造型座椅 A',
 'Sculptural Seating B (Right and Left)': '艺术造型座椅 B（左右向）',
 'Sculptural Sofa': '艺术造型沙发', 'Service Station A': '服务台 A',
 'Service Station B': '服务台 B', 'Side Tabke A': '边几 A（原文拼写 Tabke）',
 'Side Table': '边几', 'Side Table @ Living': '边几（客厅）',
 'Side Table @ Master': '边几（主卧）', 'Side Table A': '边几 A', 'Side Table B': '边几 B',
 'Sofa': '沙发', 'Sofa A': '沙发 A', 'Sofa B': '沙发 B', 'Study Table': '书桌',
 'TV CONSOLE': '电视柜', 'TV WALL @ BOARDROOM': '电视墙（会议室）', 'Table C': '桌 C',
 'Throw Pillow': '抱枕', 'Throw Pillow "A\' @ Sofa': '抱枕 A（沙发配）',
 'Throw Pillow "B\' @ Sofa': '抱枕 B（沙发配）', 'Throw Pillow "C" @ Sofa': '抱枕 C（沙发配）',
 'Throw Pillow A': '抱枕 A', 'Throw Pillow B': '抱枕 B', 'Throw Pillow C': '抱枕 C',
 'VANITY COUNTER': '梳妆台', 'VANITY COUNTER A': '梳妆台 A', 'VANITY COUNTER B': '梳妆台 B',
 'VANITY COUNTER C': '梳妆台 C', 'VANITY COUNTER D': '梳妆台 D',
 'VANITY COUNTER AND DEMYSTIFYING MIRROR': '梳妆台及镜面',
 'VANITY COUNTER, WITH VANITY MIRROR': '梳妆台（含梳妆镜）', 'Vanity Chair': '梳妆椅',
 'WARDROBE': '衣柜', 'WARDROBE & LUGGAGE RACK': '衣柜及行李架', 'WARDROBE 1': '衣柜 1',
 'WARDROBE 2': '衣柜 2', 'WARDROBE 3': '衣柜 3',
 'specification not available': '（客户未提供规格）',
 'specification  not available': '（客户未提供规格）',
 'Conference Chair': '会议椅', 'Conference Table - 16 seater': '会议桌（16 人位）',
 'Communal Table': '公用长桌', 'Cocktail Table': '鸡尾酒桌',
}

_D = [
 (r'Fire Rating\s*:?\s*Min\.?\s*of\s*60\s*Minutes', '防火等级：不低于 60 分钟'),
 (r'Wood Treatment\s*:\s*Vermin Free', '木材处理：防虫处理'),
 (r'Metal Finish\s*:\s*Stainless Steel', '金属饰面：不锈钢'),
 (r'Power data\s*&\s*Tel\.?\s*Point at', '电源及电话点位设于'),
 (r'\*?\s*Confirm\s*on-?site\s*Dimension\w*', '现场尺寸需确认'),
 (r'verify\s*on\s*site', '现场核实'),
 (r'with\s+Heavy\s*Duty\s+Teflon\s+[Gg]lides', '配重型铁氟龙脚垫'),
 (r'Heavy\s*Duty\s+Teflon\s+[Gg]lides', '重型铁氟龙脚垫'),
 (r'Teflon\s+[Gg]lides', '铁氟龙脚垫'),
 (r'Knife\s*Edge', '刀边工艺'),
 (r'Self[\s-]*Stitch\w*', '单缝线'),
 (r'Single\s*Stitch\w*', '单缝线'),
 (r'Pop-?up\s+Table', '升降桌'),
 (r'Laminated\s+Plywood\s+Slats', '多层夹板条'),
 (r'Laminated\s+Plywood', '多层夹板'),
 (r'Sintered\s+Stone', '岩板'),
 (r'Solid\s+Surface', '人造石'),
 (r'Quartz\s+Stone', '石英石'),
 (r'Marble\s+Stone|Mable\s+Stone', '大理石'),
 (r'Tinted\s+Tempered\s+Glass', '着色钢化玻璃'),
 (r'Tempered\s+Glass', '钢化玻璃'),
 (r'Laminated\s+Glass', '夹胶玻璃'),
 (r'Textured\s+Resin\s+Glass', '纹理树脂玻璃'),
 (r'Textured\s+Glass', '纹理玻璃'),
 (r'Bamboo\s+Charcoal', '竹炭'),
 (r'Paint\s*F[in]{1,3}sh', '涂料饰面'),
 (r'Powder\s*[Cc]oat\w*', '粉末喷涂'),
 (r'Powdercoat', '粉末喷涂'),
 (r'Metal\s+counter\s*top', '金属台面'),
 (r'Stone\s+top', '石台面'),
 (r'General\s+Metal\s+Finish', '通用金属饰面'),
 (r'Wood\s+Veneer', '木饰面'),
 (r'Solid\s+Wood', '实木'),
 (r'Fabric\s*(?:&|and)\s*Upholstery', '布艺软包'),
 (r'[Oo]utdoor', '户外'),
 (r'[Cc]once?aled\s+[Ll]ight', '隐藏灯带'),
 (r'[Cc]once?aled', '隐藏式'),
 (r'[Ee]lectroplat\w*', '电镀'),
 (r'Stainless\s+Steel', '不锈钢'),
 (r'[Hh]airline', '发丝纹'),
 (r'[Bb]rushed', '拉丝'),
 (r'[Pp]olished', '抛光'),
 (r'[Mm]atte?\b', '哑光'),
 (r'[Gg]lossy', '亮光'),
 (r'[Ss]atin\b', '缎面'),
 (r'[Aa]ntique', '仿古'),
 (r'[Pp]atina', '做旧'),
 (r'[Ss]tain\w*', '染色'),
 (r'[Tt]extured\b', '纹理'),
 (r'[Mm]atch', '匹配'),
 (r'[Ee]nsure\s+stability', '确保稳固'),
 (r'[Hh]eavily\s+weight\w*', '加重'),
 (r'[Ll]edge', '台沿'),
 (r'[Cc]ounter', '台面'),
 (r'[Dd]imension\w*', '尺寸'),
 (r'[Qq]uartz', '石英石'), (r'[Mm]arble|[Mm]able', '大理石'),
 (r'[Gg]ranite', '花岗岩'), (r'[Tt]errazzo', '水磨石'),
 (r'[Ss]tone', '石材'), (r'[Rr]esin', '树脂'), (r'[Aa]crylic', '亚克力'),
 (r'[Ll]aminate\w*', '层压板'), (r'[Vv]eneer', '木饰面'),
 (r'[Pp]lywood', '夹板'), (r'MDF', '中纤板'), (r'HPL', '防火板'),
 (r'[Gg]lass', '玻璃'), (r'[Mm]irror', '镜面'),
 (r'[Ll]eather', '皮革'), (r'[Ff]abric', '布艺'), (r'[Uu]pholster\w*', '软包'),
 (r'[Ff]oam', '海绵'), (r'[Ff]elt', '毛毡'), (r'[Nn]ylon', '尼龙'),
 (r'[Rr]attan', '藤'), (r'[Cc]ane\b', '藤编'), (r'[Rr]ope', '绳编'),
 (r'[Cc]eramic', '陶瓷'), (r'[Pp]orcelain', '瓷质'), (r'[Tt]ile', '瓷砖'),
 (r'[Cc]oncrete', '清水混凝土'), (r'[Pp]laster', '石膏'), (r'[Bb]rick', '砖'),
 (r'[Pp]aint', '涂料'), (r'[Ll]acquer', '烤漆'),
 (r'[Bb]rass', '黄铜'), (r'[Cc]opper', '紫铜'), (r'[Bb]ronzato|[Bb]ronze', '古铜色'),
 (r'[Nn]ickel', '镍'), (r'[Cc]hrome', '镀铬'), (r'[Ss]teel', '钢'),
 (r'[Ii]ron', '铁'), (r'[Aa]luminium|[Aa]luminum', '铝'),
 (r'[Pp]erforated', '穿孔'), (r'[Ff]olded', '折板'),
 (r'[Ss]lats', '条板'), (r'[Pp]anel', '饰面板'), (r'[Bb]oard', '板'),
 (r'[Rr]ubber', '橡胶'), (r'[Ss]ilicone', '硅胶'), (r'[Vv]inyl', '塑胶'),
 (r'[Ww]oven\s*PVC', '编织 PVC'), (r'PVC', 'PVC'),
 (r'[Mm]esh', '网'),
 (r'[Ww]hite', '白色'), (r'[Bb]lack', '黑色'), (r'[Gg]r[ae]y', '灰色'),
 (r'[Ll]ight', '浅色'), (r'[Dd]ark', '深色'), (r'[Mm]edium', '中色'),
 (r'[Bb]eige', '米色'), (r'[Gg]reen', '绿色'), (r'[Bb]lue', '蓝色'),
 (r'[Rr]ed', '红色'), (r'[Bb]rown', '棕色'), (r'[Nn]atural', '本色'),
 (r'[Tt]erracotta', '赤陶色'), (r'[Tt]aupe', '灰褐'), (r'[Cc]ream', '米白'),
 (r'[Cc]harcoal', '碳灰'), (r'[Ii]vory', '象牙白'),
 (r'[Tt]eak', '柚木'), (r'[Ww]alnut', '胡桃木'), (r'[Oo]ak', '橡木'),
 (r'[Aa]sh\b', '白蜡木'), (r'[Bb]irch', '桦木'), (r'[Jj]atoba', '贾托巴木'),
 (r'[Ss]tainless', '不锈钢'), (r'[Mm]etal', '金属'),
 (r'[Hh]ardware', '五金件'), (r'[Aa]ccessor\w*', '配件'),
 (r'[Cc]abinet', '柜体'), (r'[Ww]ardrobe', '衣柜'),
 (r'[Tt]able\s*[Tt]op|Tabletop', '台面'), (r'[Cc]ountertop', '台面'),
 (r'[Ff]rame', '框架'), (r'[Bb]ase', '底座'), (r'[Ll]egs?\b', '脚'),
 (r'[Gg]lides?', '脚垫'), (r'[Cc]aster', '脚轮'), (r'[Ww]heels?', '脚轮'),
 (r'[Ss]helf|Shelves', '层板'), (r'[Dd]rawer', '抽屉'), (r'[Dd]oor', '门'),
 (r'[Hh]andle', '拉手'), (r'[Hh]inge', '合页'),
 (r'[Ss]witch', '开关'), (r'[Ss]ocket', '插座'), (r'[Oo]utlet', '插座'),
 (r'[Pp]ort', '端口'), (r'[Pp]ower', '电源'), (r'[Dd]ata', '数据'),
 (r'[Ll]ighting', '照明'), (r'[Ll]ight\b', '灯'),
 (r'[Tt]op\b', '台面'), (r'[Ff]inish(?:es|ed)?', '饰面'),
 (r'[Ss]urface', '表面'), (r'[Ss]olid', '实木'),
 (r'[Ff]illing', '填充'), (r'[Tt]eflon', '铁氟龙'),
 (r'[Hh]eavy\s*Duty', '重型'), (r'[Gg]eneral', '通用'),
 (r'[Ss]tandard', '标准'), (r'[Cc]ustom', '定制'),
 (r'[Ii]ncluding|include[sd]?', '含'),
 (r'[Ww]ith\b', '配'), (r'\band\b', '及'), (r'\bor\b', '或'),
 (r'\bto\b', '至'), (r'\bfor\b', '用于'), (r'\bin\b', ''),
]

_NAME_RE = [(re.compile(r'(?<![A-Za-z])' + re.escape(k) + r'(?![A-Za-z])', re.I), v)
            for k, v in sorted(NAMES.items(), key=lambda x: -len(x[0])) if k.strip()]

def _apply(s):
    out = s
    for rx, zh in _NAME_RE:
        out = rx.sub(zh, out)
    for pat, zh in _D:
        out = re.sub(pat, zh, out, flags=re.I)
    out = re.sub(r'(?<=[\u4e00-\u9fa5])\s+(?=[\u4e00-\u9fa5])', '', out)
    out = re.sub(r'\s*,\s*', '，', out)
    out = re.sub(r'\s*;\s*', '；', out)
    out = re.sub(r'\s*\.\s*', '；', out)
    out = re.sub(r'[，；]{2,}', '；', out)
    out = re.sub(r'\s{2,}', ' ', out)
    return out.strip(' ，；')

# （旧的 translate_material 已被文末的完整版本取代，此处删除避免误改）

def translate_name(n):
    if n in NAMES:
        return NAMES[n], []
    out, left = translate_name_composed(n)
    return out, left

# ---------- 补充：原文拼写错误 + 长描述短语（第二轮） ----------
_EXTRA = [
 (r'[Pp]ow[ae]d?er\s*[Cc]oat\w*', '粉末喷涂'),
 (r'[Pp]ow[ae]d?er', '粉末'),
 (r'[Cc]onc[el]{1,2}a{1,2}led', '隐藏式'),
 (r'[Hh][ea]{2}d?[cd]?y\s*[Dd]uty', '重型'),
 (r'[Hh][ea]{2}d?y', '重型'),
 (r'[Hh]eacy', '重型'),
 (r'[Ff]ab[ir]{1,2}c\w*', '布艺'),
 (r'[Ii]ncldg|[Ii]ncl\.', '含'),
 (r'[Pp]rov[is]{1,2}on', '配置'),
 (r'[Tt]empe\w*', '钢化'),
 (r'[Aa]slo', '亦'),
 (r'[Mm]eral', '金属'),
 (r'[Ww]ooven', '编织'),
 (r'[Ww]heen', '轮'),
 (r'[Ss]abbot', '脚套'),
 (r'[Dd]emystifying', '除雾'),
 (r'[Ss]elf[\s-]*[Cc]losing', '自闭'),
 (r'[Hh]anger\s*[Rr]od', '挂衣杆'),
 (r'[Ww]all\s*[Mm]ounted', '壁挂式'),
 (r'[Tt]ouch\s*[Cc]ontrol', '触控'),
 (r'[Ff]og\s*[Ff]ree', '防雾'),
 (r'[Mm]arine\s*[Gg]rade', '船用级'),
 (r'[Uu]ltra\s*[Cc]lear', '超白'),
 (r'[Cc]lear\b', '透明'),
 (r'[Mm]attress', '床垫'),
 (r'[Pp]added', '加垫'),
 (r'[Ss]mooth', '光滑'),
 (r'[Ss]pecial', '特殊'),
 (r'[Gg]rade', '级'),
 (r'[Ss]ilver', '银色'),
 (r'[Bb]anquette', '卡座'),
 (r'\bette\b', ''),
 (r'[Nn]ight\s*[Ss]tand', '床头柜'),
 (r'[Ss]ide\s*[Ss]tand', '边架'),
 (r'[Ss]tand\b', '架'),
 (r'[Ss]mokey', '烟熏'),
 (r'[Oo]cean', '海洋'),
 (r'[Pp]alissandron', '帕利桑德'),
 (r'[Mm]obile', '移动式'),
 (r'[Tt]ransom', '亮窗'),
 (r'[Cc]omplete', '完整'),
 (r'[Cc]onsider', '需考虑'),
 (r'[Pp]lacement', '定位'),
 (r'[Oo]rientation', '朝向'),
 (r'[Ll]ocking\s*[Mm]echanism', '锁定装置'),
 (r'[Mm]echanism', '装置'),
 (r'\bmust\b', '须'),
 (r'\bhave\b', '带'),
 (r'\bconfirm\b', '确认'),
 (r'\bverify\b', '核实'),
 (r'\bthe\b', ''),
 (r'\bWood\b', '木'),
 (r'\bDuty\b', '级'),
 (r'\bCut\b', '切割'),
 (r'\bPoint\b', '点位'),
 (r'\bBar\b', '杆'),
 (r'\bLounge\b', '休闲'),
 (r'S/S', '不锈钢'),
]
_D.extend(_EXTRA)

# ---------- 第三轮：残余专有词与工艺短语 ----------
_D.extend([
 (r'concel+a?ed|conc[ae]lae?d', '隐藏式'),
 (r'self\s*concealed', '自带隐藏'),
 (r'\bself\b', '自带'),
 (r'\bsoad\b', '皂液器'),
 (r'\btissue\b', '纸巾'),
 (r'pull[\s-]*out', '抽出式'),
 (r'soft[\s-]*closing', '阻尼回弹'),
 (r'\bguides?\b', '导轨'),
 (r'\bmist\b', '雾面'),
 (r'\bunder\b', '下部'),
 (r'\binner\b', '内侧'),
 (r'sunbrella|sumbrella', 'Sunbrella 面料'),
 (r'refer to bid plans?/?specs? for details', '详见招标图纸及技术规格'),
 (r'\bdarj\b', '深色'),
 (r'gliddes|glifes|\bglides?\b', '脚垫'),
 (r'harline', '发丝纹'),
 (r'\bwoof\b', '木'),
 (r'\bfiish\b', '饰面'),
 (r'\btexxtu\w*', '纹理'),
 (r'\bmust\b', '须'),
 (r'\bwith\b', '配'),
 (r'\band\b', '及'),
 (r'\bor\b', '或'),
 (r'\bin\b', ''),
])

# ---------- 第四轮 ----------
_D.extend([
 (r'leathe?r?ette', '人造革'),
 (r'LED\s+Light', 'LED 灯'),
 (r'refer\s+to\s+bid\s+plans?\s*/?\s*specs?\s*for\s+details', '详见招标图纸及技术规格'),
 (r'non[\s-]*woven', '无纺'),
 (r'polyester', '聚酯'),
 (r'polystyrene', '聚苯乙烯'),
 (r'expanded', '发泡'),
 (r'lightweight', '轻质'),
 (r'beads', '颗粒'),
 (r'infill', '填充'),
 (r'inner\s*liner', '内衬'),
 (r'liner', '内衬'),
 (r'color', '颜色'),
 (r'back\s+of', '背面'),
 (r'\bback\b', '背面'),
 (r'fabriic', '布艺'),
 (r'soild', '实木'),
 (r'tinted', '着色'),
 (r'telphone', '电话'),
 (r'aslo|\balso\b', '亦'),
 (r'fitout|fit[\s-]*out', '装修'),
 (r'\bmust\s+be\b', '须为'),
 (r'\bbe\b', '为'),
 (r'\bby\b', '由'),
 (r'contractors?', '承包商'),
 (r'\bfabric\b', '布艺'),
])
_CLEAN2 = [
 (r'\s+([:：])', r'\1'),
 (r'([：:])\s*', r'\1'),
 (r'\s+/\s*', ' / '),
 (r'\(\s+', '（'), (r'\s+\)', '）'),
]
def _tidy(s):
    for pat, rep in _CLEAN2:
        s = re.sub(pat, rep, s)
    s = re.sub(r'\s{2,}', ' ', s)
    return s.strip(' ，；')
_ORIG_APPLY = _apply
def _apply(s):
    return _tidy(_ORIG_APPLY(s))

# ---------- 预处理：先替换会被通用规则拆坏的专有短语 ----------
_PRE = [
 (r'\(?\s*refer\s+to\s+bid\s+plans?\s*/?\s*specs?\s+for\s+details\s*\)?', '（详见招标图纸及技术规格）'),
 (r'[Ll]eathe?r?ette', '人造革'),
 (r'[Tt]ouch[\s-]*[Cc]ontrol(?:led)?', '触控'),
 (r'[Tt]owel\s*(?:[Bb]ar|杆)', '毛巾杆'),
 (r'[Pp]ull[\s-]*[Oo]ut\s+[Tt]ray', '抽出式托盘'),
 (r'[Mm]arquetry', '拼花'),
 (r'[Ee]mbossed\s+[Tt]exture', '压纹饰面'),
 (r'[Ss]ubstrate', '基材'),
 (r'its\s+own', '自带'),
 (r'\bThk\.?\b', '厚'),
 (r'\bw/', '配'),
 (r'\s*&\s*', '及'),
 (r'\bLeft\b|\bRight\b', '左右'),
 (r'mini\s+bulk\s+head\s+above', '上方小批量吊顶'),
]
def _pre(s):
    for pat, rep in _PRE:
        s = re.sub(pat, rep, s)
    return s
_APPLY3 = _apply
def _apply(s):
    return _APPLY3(_pre(s))

def translate_material(text):
    s = str(text or '')
    if not s:
        return '', []
    out = _apply(s)
    left = re.findall(r'[A-Za-z]{3,}', out)
    keep = {'sunbrella','pvc','led','eps','cnc','hpl','mdf','eco','concertex',
            'canyon','mushroom'}
    left = [w for w in left if w.lower() not in keep]
    return out, left

_PRE.extend([
 (r'[Ll]ightweight', '轻质'),
 (r'[Ff]og[\s-]*[Ff]ree', '防雾'),
 (r'[Ss]trap', '拉带'),
 (r'\bmini\b', '小'),
 (r'\bbulk\b', '批量'),
 (r'\bhead\b', '吊顶'),
 (r'\babove\b', '上方'),
])

_PRE.extend([
 (r'undercounter', '台下式'),
 (r'[Dd]ecorative', '装饰'),
 (r'\bunder\b', '下部'),
 (r'\bTower\b', '毛巾'),
 (r'[Pp]rinted\s*[Ww]allcover\w*', '印花墙纸'),
 (r'[Ss]pe?a?c?id?a?l', '特殊'),
])

# ---------- 组合式品名：词根 + 长短语优先 ----------
NAME_PHRASES = [
 ('modular system sofa', '模块化组合沙发'), ('modular sofa', '模块沙发'),
 ('center banquet seat', '中心卡座'), ('column banquet seat', '柱边卡座'),
 ('banquet seat', '卡座'), ('pdr banquet seat', '公卫卡座'),
 ('guest seating', '客用座椅'), ('pouf guest seating', '客用坐墩'),
 ('service station', '服务台'), ('coffee table lounge', '休闲茶几'),
 ('coffee table', '茶几'), ('dining table', '餐桌'), ('side table', '边几'),
 ('lounge chair', '休闲椅'), ('lounge sofa', '休闲沙发'), ('accent lounge chair', '单人休闲椅'),
 ('foot spa lounge chair', '足浴休闲椅'), ('foot spa foot stool', '足浴脚踏'),
 ('foot spa', '足浴'), ('platform stage', '舞台'),
 ('curved joinery cushion', '弧形木作坐垫'), ('joinery cushion', '木作坐垫'),
 ('billiard ball bean bag', '台球豆袋'), ('billiard table', '台球桌'),
 ('football table', '桌上足球台'), ('pingpong table', '乒乓球台'),
 ('shuffleboard table', '沙狐球台'), ('activity table', '活动桌'),
 ('refreshment table', '茶歇桌'), ('console cabinet', '条案柜'),
 ('round pedestal', '圆底座'), ('table desk', '桌台'), ('l-shape desk', 'L 形办公桌'),
 ('half-pill dining table', '半圆餐桌'), ('half-pill', '半圆'),
 ('oval console table', '椭圆条案'), ('oval coffee table', '椭圆茶几'),
 ('rectangular dining table', '长方餐桌'), ('rectangular side table', '长方边几'),
 ('rectangular sofa', '长方沙发'), ('rectangular table', '长方桌'),
 ('round dining table', '圆餐桌'), ('round coffee table', '圆茶几'),
 ('round lounge sofa', '圆休闲沙发'), ('round lounge table', '圆休闲桌'),
 ('round sofa', '圆沙发'), ('round tablelounge', '圆桌（酒廊）'),
 ('square dining table', '方餐桌'), ('square side table', '方边几'),
 ('square table lounge', '方桌（酒廊）'), ('square table', '方桌'),
 ('discussion chair', '会议椅'), ('reception guest chair', '接待客椅'),
 ('security chair', '安防椅'), ('swivel chair', '转椅'), ('desk chair', '书桌椅'),
 ('office chair', '办公椅'), ('vanity stool', '梳妆凳'), ('shower stool', '淋浴凳'),
 ('elephant stool', '象凳'), ('pouf world map', '世界地图坐墩'),
 ("kid's armchair", '儿童扶手椅'), ("kid's sofa", '儿童沙发'),
 ("teen's sofa", '青少年沙发'), ('bench guest seating', '客用长凳'),
 ('elipse table', '椭圆桌'), ('oval table', '椭圆桌'), ('center table', '中心桌'),
 ('c table', 'C 型边几'), ('armoire', '衣橱'), ('wardrobe', '衣柜'), ('console', '条案'), ('sidetable', '边几'),
]
NAME_WORDS = [
 ('armchair', '扶手椅'), ('chair', '椅'), ('sofa', '沙发'), ('stool', '凳'),
 ('table', '桌'), ('desk', '办公桌'), ('pouf', '坐墩'), ('bench', '长凳'),
 ('banquet', '卡座'), ('column', '柱边'), ('center', '中心'), ('centre', '中心'),
 ('security', '安防'), ('reception', '接待'), ('guest', '客用'), ('lobby', '大堂'),
 ('lounge', '休闲'), ('dining', '餐'), ('coffee', '茶几'), ('side', '边'),
 ('round', '圆'), ('square', '方'), ('rectangular', '长方'), ('oval', '椭圆'),
 ('modular', '模块化'), ('swivel', '转'), ('activity', '活动'), ('platform', '平台'),
 ('stage', '舞台'), ('refreshment', '茶歇'), ('service', '服务'), ('station', '台'),
 ("kid's", '儿童'), ("teen's", '青少年'), ('kid', '儿童'), ('teen', '青少年'),
 ('seating', '座椅'), ('conference', '会议'), ('upholstered', '软包'),
 ('occasional', '边'), ('chai', '椅'), ('meeting', '会议'),
 ('specification', ''), ('not', ''), ('available', ''),
]

def _norm(s):
    return str(s or '').replace('’', "'").replace('–', '-').strip()

def translate_name_composed(n):
    """组合式品名：长短语优先，逐词替换，保留尾部编号字母。"""
    src = _norm(n)
    if not src:
        return '', []
    src = re.sub(r'([a-z])([A-Z])$', r'\1 \2', src)   # TableA -> Table A
    suffix = ''
    m = re.search(r'\s+([A-Z]\.?\d?|A\d?|B\d?)$', src)
    if m and len(m.group(1)) <= 3:
        suffix = ' ' + m.group(1)
        src = src[:m.start()]
    txt = src.lower()
    for en, zh in sorted(NAME_PHRASES, key=lambda x: -len(x[0])):
        txt = re.sub(r'(?<![a-z])' + re.escape(en) + r'(?![a-z])', zh, txt)
    for en, zh in NAME_WORDS:
        txt = re.sub(r'(?<![a-z])' + re.escape(en) + r'(?![a-z])', zh, txt)
    txt = re.sub(r'\bfor\s+(\d+)', r'\1 人', txt)
    txt = re.sub(r'\s{2,}', ' ', txt).strip(' -')
    txt = re.sub(r'(?<=[\u4e00-\u9fa5])\s+(?=[\u4e00-\u9fa5])', '', txt)
    left = re.findall(r'[A-Za-z]{2,}', txt)
    return txt + suffix, left

# ---------- FFE / 图纸支路高频短语（v1.9 整理）：长短语优先，插在 _PRE 最前面 ----------
# 这些短语若走通用词表会被拆坏：hinged→合页d、panelling→饰面板ling、cut-pile→切割-pile
_PRE[:0] = [
 (r'[Hh]inged\s+[Dd]oors?\b', '平开门'),
 (r'[Ss]liding\s+[Dd]oors?\b', '推拉门'),
 (r'[Gg]lass\s+[Dd]oors?\b', '玻璃门'),
 (r'[Ww]all\s+[Pp]anell?ing\b', '墙面饰板'),
 (r'[Ff]luted\b', '格栅'),
 (r'[Bb]ed\s+[Bb]ase\b', '床架'),
 (r'[Bb]ed\s+[Hh]eadboard\b', '床头板'),
 (r'[Ll]inen\s+[Ww]eave\b', '亚麻织物'),
 (r'[Hh]anging\s+[Rr]ail\b', '挂衣杆'),
 (r'[Cc]ut[\s-]*pile\b', '割绒'),
 (r'[Ff]reestanding\b', '独立式'),
 (r'[Aa]crylic\b', '亚克力'),
 (r'[Ww]all[\s-]*faced\s+[Pp]an\b', '壁挂式座便器'),
 (r'[Ss]oft[\s-]*close\s+[Ss]eat\b', '缓降盖板'),
 (r'[Ss]olid\s+[Tt]imber\s+[Ff]rame\b', '实木框架'),
 (r'[Tt]imber\b', '实木'),
 (r'[Ff]abric\s+[Uu]pholstery\b', '布艺软包'),
 (r'[Uu]pholstered\b', '软包'),
 (r'[Ss]tone\s+[Tt]op\b', '石材台面'),
 (r'[Ss]tone\s+[Cc]ounter\b', '石材台面'),
 (r'[Mm]etal\s+[Bb]ase\b', '金属底座'),
 (r'[Cc]ustom\s+[Ss]ize\b', '定制尺寸'),
 (r'[Cc]oncealed\b', '暗藏'),
 (r'[Ff]loating\s+TV\s+[Cc]onsole\b', '悬浮电视柜'),
 (r'[Ii]ntegrated\b', '一体式'),
 (r'[Ff]ull[\s-]*height\s+[Mm]irror\b', '通高穿衣镜'),
 (r'[Bb]rushed\s+[Bb]rass\s+[Tt]rim\b', '拉丝黄铜收边'),
 (r'[Mm]oisture[\s-]*resistant\s+[Bb]oard\b', '防潮板'),
 (r'[Tt]empered\s+[Gg]lass\b', '钢化玻璃'),
 (r'[Ll]eather\s+[Ss]trap\b', '皮质拉手'),
 (r'[Ss]wivel\s+[Bb]ase\b', '旋转底座'),
 (r'[Oo]ak\s+[Vv]eneer\b', '橡木饰面'),
 (r'[Ww]alnut\s+[Vv]eneer\b', '胡桃木饰面'),
 (r'[Vv]eneer\b', '饰面'),
 (r'[Cc]arpet\b', '地毯'),
 (r'[Pp]anell?ing\b', '饰板'),
 (r'[Bb]athtub\b|\b[Bb]ath\b', '浴缸'),
]
_PRE[:0] = [
 (r'LED\s+[Ss]trip\b', 'LED 灯带'),
 (r'\b[Dd]etail\b', '细节'),
 (r'\b[Ss]trips?\b', '条'),
]

# ---------- FFE / 图纸支路高频品名（v1.9 整理）：长短语优先 ----------
NAME_PHRASES[:0] = [
 ('luggage rack with mirror', '行李架（含穿衣镜）'), ('luggage rack', '行李架'),
 ('tv cabinet with wall panelling', '电视柜及墙面饰板'), ('tv cabinet', '电视柜'),
 ('bar counter with bar chair', '吧台及吧椅'), ('bar counter', '吧台'),
 ('bar chair', '吧椅'), ('bar stool', '吧凳'),
 ('bathroom vanity cabinet', '浴室柜'), ('vanity cabinet', '浴室柜'),
 ('wall panelling', '墙面饰板'), ('wall paneling', '墙面饰板'),
 ('shower screen', '淋浴隔断'), ('display cabinet', '展示柜'),
 ('window seating', '窗台座'), ('ironing board', '熨衣板'),
 ('bed headboard', '床头板'), ('mini bar', '迷你吧柜'), ('minibar', '迷你吧柜'),
 ('area rug', '地毯'), ('rug', '地毯'),
 ('study desk', '书桌'), ('sofa chair', '单人沙发椅'),
 ('bedside table', '床头柜'),
 ('wardrobe (3-door)', '衣柜（三门）'), ('wardrobe', '衣柜'),
 ('bed (super king)', '超大床'), ('bed (king)', '大床'),
 ('super king bed', '超大床'), ('king bed', '大床'), ('bed', '床'),
 ('bathtub', '浴缸'), ('toilet', '坐便器'), ('basin', '面盆'),
 ('shower', '淋浴'), ('mirror', '镜'),
]
_PRE[:0] = [
 (r'\b[Ss]heets?\b', '板材'),
 (r'\b[Mm]att\b|\b[Mm]atte\b', '哑光'),
]
# seat 必须排在 'soft-close seat' 之后，否则会把专有短语拆掉
_PRE.append((r'\b[Ss]eats?\b', '座面'))
