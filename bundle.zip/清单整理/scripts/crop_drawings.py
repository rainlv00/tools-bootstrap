#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""从图纸 PDF 裁区域平面图，用作无产品图时的 PIC 替代

用法：
    python crop_drawings.py --map map.json --out img_dir [--dpi 200] [--width 1400]

map.json: {"AREA_KEY": "path/to/drawing.pdf", ...}
输出: img_dir/<AREA_KEY>.jpg
"""
import argparse, json, os, re
import numpy as np
import pymupdf
from PIL import Image


def crop_plan(page, dpi=200, title_block_ratio=0.82):
    """渲染后裁掉图框与标题栏，并按白色边距收紧。"""
    pm = page.get_pixmap(dpi=dpi)
    im = Image.frombytes('RGB', (pm.width, pm.height), pm.samples)
    w, h = im.size
    im = im.crop((int(w * 0.005), int(h * 0.02), int(w * title_block_ratio), int(h * 0.97)))
    arr = np.array(im)
    mask = arr.min(axis=2) < 245
    rows, cols = mask.any(axis=1), mask.any(axis=0)
    if rows.any() and cols.any():
        y0 = max(int(rows.argmax()) - 8, 0)
        y1 = min(len(rows) - 1 - int(rows[::-1].argmax()) + 8, im.height)
        x0 = max(int(cols.argmax()) - 8, 0)
        x1 = min(len(cols) - 1 - int(cols[::-1].argmax()) + 8, im.width)
        im = im.crop((x0, y0, x1, y1))
    return im


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--map', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--dpi', type=int, default=200)
    ap.add_argument('--width', type=int, default=1400)
    a = ap.parse_args()

    mapping = json.load(open(a.map, encoding='utf8'))
    os.makedirs(a.out, exist_ok=True)
    for area, pdf in mapping.items():
        if not os.path.exists(pdf):
            print('  缺文件', area, pdf)
            continue
        doc = pymupdf.open(pdf)
        im = crop_plan(doc[0], a.dpi)
        doc.close()
        if im.width > a.width:
            k = a.width / im.width
            im = im.resize((int(im.width * k), int(im.height * k)), Image.LANCZOS)
        safe = re.sub(r'[^\w\u4e00-\u9fa5]+', '_', area)
        p = os.path.join(a.out, safe + '.jpg')
        im.save(p, 'JPEG', quality=82, optimize=True)
        print('  %-34s %4dx%-4d -> %s' % (area, im.width, im.height, os.path.basename(p)))


if __name__ == '__main__':
    main()
