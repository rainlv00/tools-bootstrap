#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""设计公司 FFE Schedule（xlsx / PDF）-> parsed.json + 产品图

用法：
    python parse_ffe_schedule.py --config config.ffe.json

适用：按 TAG 编制的 FURNITURE SCHEDULE，表头形如
    TAG | LOCATION | AREA | IMAGE | PRODUCT CODE DESCRIPTION | COLOR FINISH |
    UNIT SIZE | ACCESSORIES | QTY | SUPPLIER/ MANUFACTURER / LINK | REMARKS
并按 FURNITURE / EQUIPMENT / WHITE GOODS / FIXTURES / DOOR HARDWARE 分段。

为什么不直接用 parse_boq.py：区块式 BOQ 靠「字母编号 / IF 型号」识别条目，
FFE Schedule 靠「TAG + 全大写分组行」，且品名列位置各表不一致（有的品名在
AREA 列、材质在 DESCRIPTION 列），必须由 config 指明 name_from。

设计要点：
- 分组白名单 groups：同一 sheet 里只取 FURNITURE 段，EQUIPMENT/WHITE GOODS/
  FIXTURES/DOOR HARDWARE 一律跳过（只做家具）。
- 续行（TAG 为空的补充行，如面料、床箱）并入上一条的 material，不单独计数。
- 图片按 drawing 锚点行归属，不按 media 顺序猜图；兼容 oneCellAnchor 与
  twoCellAnchor、带/不带 xdr: 前缀、相对/绝对 Target。
- PDF 源：按列 x 分桶取字段，再用「最近的 TAG」把文本行归到条目（PDF 里
  TAG 垂直居中，y 与内容行不一致，按 y 聚类会错位）。
- 数量可由另一份「核算图纸量」表按 TAG 回灌（qty_source），不覆盖已有值。
"""
import argparse
import bisect
import io
import json
import os
import posixpath
import re
import zipfile

import openpyxl
import pymupdf
from PIL import Image

TAGPAT = re.compile(r'^[A-Z]{1,4}-?[A-Z]{0,4}\d{1,3}$')


# ---------------------------------------------------------------- xlsx 基础
def clean(v):
    return '' if v is None else str(v).strip()


def is_group(a):
    """全大写、无数字、长度 >= 3 的行 = 分段标题（FURNITURE / WHITE GOODS …）。"""
    return bool(a) and bool(re.fullmatch(r'[A-Z][A-Z0-9 &/\.\-]{2,}', a)) and not re.search(r'\d', a)


def sheet_xml_path(z, sheet_name):
    wb = z.read('xl/workbook.xml').decode('utf8', errors='ignore')
    m = re.search(r'<sheet[^>]*name="%s"[^>]*r:id="([^"]+)"' % re.escape(sheet_name), wb)
    if not m:
        return None
    rid = m.group(1)
    rels = z.read('xl/_rels/workbook.xml.rels').decode('utf8', errors='ignore')
    t = dict(re.findall(r'Id="([^"]+)"[^>]*Target="([^"]+)"', rels)).get(rid)
    if not t:
        return None
    if t.startswith('/'):
        return t.lstrip('/')
    return posixpath.normpath(posixpath.join('xl', t))


def drawing_media_map(z, sheet_xml):
    """{锚点起始行(1-based): [media_path, ...]} —— 兼容 one/twoCellAnchor。"""
    rels_path = posixpath.join(posixpath.dirname(sheet_xml), '_rels',
                               posixpath.basename(sheet_xml) + '.rels')
    try:
        sheet_rels = z.read(rels_path).decode('utf8', errors='ignore')
    except KeyError:
        return {}
    m = re.search(r'Target="([^"]*drawing\d+\.xml)"', sheet_rels)
    if not m:
        return {}
    tgt = m.group(1)
    draw_path = (tgt.lstrip('/') if tgt.startswith('/')
                 else posixpath.normpath(posixpath.join(posixpath.dirname(sheet_xml), tgt)))
    try:
        draw = z.read(draw_path).decode('utf8', errors='ignore')
    except KeyError:
        return {}
    drels_path = posixpath.join(posixpath.dirname(draw_path), '_rels',
                                posixpath.basename(draw_path) + '.rels')
    try:
        drels = z.read(drels_path).decode('utf8', errors='ignore')
    except KeyError:
        return {}
    rid2media = dict(re.findall(r'Id="(rId\d+)"[^>]*Target="([^"]+)"', drels))

    imgs = {}
    g = r'(?:xdr:)?'
    pat = r'<%s(?:twoCellAnchor|oneCellAnchor).*?</%s(?:twoCellAnchor|oneCellAnchor)>' % (g, g)
    for blk in re.findall(pat, draw, re.S):
        r0 = re.search(r'<%sfrom>\s*<%scol>(\d+)</%scol>.*?<%srow>(\d+)</%srow>'
                       % (g, g, g, g, g), blk, re.S)
        rid = re.search(r'r:embed="(rId\d+)"', blk)
        if not (r0 and rid):
            continue
        media_tgt = rid2media.get(rid.group(1))
        if not media_tgt:
            continue
        media = posixpath.normpath(posixpath.join(posixpath.dirname(draw_path), media_tgt))
        imgs.setdefault(int(r0.group(2)) + 1, []).append(media)
    return imgs


UNITF = [('inch', 25.4), ('mm', 1.0), ('cm', 10.0)]
LB_W = re.compile(r'width|length|\bw\b|\bl\b', re.I)
LB_D = re.compile(r'depth|dia(?:meter)?|Ø|\bd\b|base plate dia', re.I)
LB_H = re.compile(r'height|\bh\b|\bht\b', re.I)


def _nearest_label(txt):
    """段内「最近的」标签，避免 `Length 780 Depth 920` 里 780 被判成 Depth。"""
    best, pos = None, -1
    for name, rx in (('w', LB_W), ('d', LB_D), ('h', LB_H)):
        for m in rx.finditer(txt):
            if m.start() > pos:
                pos, best = m.start(), name
    return best


def norm_size(text):
    """尺寸串 -> (w, d, h, dia, flags)。单位统一 mm，槽位占用后不覆盖。

    flags 里 `~` 开头 = 软提示（源文本本来就没给尺寸 / 写着 refer to detail），
    只记 size_note、不标红；不带 `~` 的才是硬错误（cm/mm 误写等），标红留痕。

    源表尺寸写法极不统一（`W 62 x D 64 x H 127 cm`、`Length 780 Depth 920
    Height 1000`、`Height:680mm / Top Dia: 500mm`、`400cm diameter x 630 cm ht`），
    所以：先按分隔符切成段，段内逐个数取「最近的」前后标签，标签不会跨字段。
    槽位顺序 W/D/H；L（长度）先占 W，W 已占则退 D（床 `W1840 L2020`）。
    """
    raw = str(text or '').strip()
    if not raw:
        return (None, None, None, False, ['~尺寸待定'])
    s = raw.replace('×', ' x ').replace('*', ' x ')
    s = re.sub(r'(?<=\d)\s*["”]\s*', ' inch ', s)
    s = re.sub(r'[\n\r\t]+', ' / ', s)          # 换行先转成分隔符，否则被后面 split 的 \s* 吞掉
    s = re.sub(r'([A-Za-z\)])\s*[:=]?\s*(\d)', r'\1 \2', s)
    g = re.search(r'\b(inch|mm|cm)\b', s, re.I)
    default_u = g.group(1).lower() if g else 'mm'
    flags, vals, dia = [], [None, None, None], False
    segs = [x for x in re.split(r'\s*(?:x|X|×|/|,|;|\n|\|)\s*', s) if x.strip()]
    for seg in segs:
        for m in re.finditer(r'(\d+(?:\.\d+)?)\s*(inch|mm|cm|in\b|")?', seg, re.I):
            num = float(m.group(1))
            uu = (m.group(2) or '').lower()
            if uu in ('in', '"'):                    # 注意 'inch'.replace('in','inch') 会变 'inchch'
                uu = 'inch'
            if not uu:
                uu = default_u
            if uu == 'cm' and num > 300:               # 把 mm 误写成 cm
                uu = 'mm'
                flags.append('源标注 %s 疑为 mm' % seg.strip()[:40])
            mm = int(round(num * dict(UNITF).get(uu, 1.0)))     # 家具尺寸统一整数 mm
            before, after = seg[:m.start()], seg[m.end():]
            lab = _nearest_label(before) or _nearest_label(after)
            if lab == 'h':
                slot = 2
            elif lab == 'd':
                slot = 1
                if re.search(r'dia|Ø', before + after, re.I):
                    dia = True
            elif lab == 'w':
                slot = 0
            else:
                slot = next((i for i in range(3) if vals[i] is None), None)
            if slot is None:
                continue
            if vals[slot] is None:
                vals[slot] = mm
            elif slot == 0:                            # L 与 W 抢位：L 退到 D
                nxt = 1 if vals[1] is None else (2 if vals[2] is None else None)
                if nxt is not None:
                    vals[nxt] = mm
    if all(v is None for v in vals):
        return (None, None, None, False, ['~尺寸未给出'])
    if re.search(r'refer|check\s*plan|as per|drawing|detail|tbc|confirm', raw, re.I) \
            and sum(v is not None for v in vals) < 2:
        return (None, None, None, dia, ['~尺寸见图纸'])
    return (vals[0], vals[1], vals[2], dia, flags)


def save_img(data, path, max_px):
    pic = Image.open(io.BytesIO(data))
    if pic.mode in ('RGBA', 'LA', 'P'):
        bg = Image.new('RGB', pic.size, (255, 255, 255))
        pic = pic.convert('RGBA')
        bg.paste(pic, mask=pic.split()[-1])
        pic = bg
    else:
        pic = pic.convert('RGB')
    if max_px and max(pic.size) > max_px:
        sc = max_px / max(pic.size)
        pic = pic.resize((max(1, int(pic.width * sc)), max(1, int(pic.height * sc))), Image.LANCZOS)
    pic.save(path, 'JPEG', quality=84, optimize=True)
    return pic.size


# ---------------------------------------------------------------- xlsx 解析
def parse_xlsx(src, cfg):
    """返回 items；图片已落盘并在 item['img'] 记绝对路径。"""
    lay, cols = src, src['cols']
    path, sheet = src['file'], src['sheet']
    keep = set(src.get('groups') or [])
    skip_tags = {str(x).strip().upper() for x in (src.get('skip_tags') or [])}
    skip_re = [re.compile(x, re.I) for x in (src.get('skip_name_re') or [])]
    name_from = src.get('name_from', 'desc')
    imgs_keep = src.get('img_col', cols.get('image'))

    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    ws = wb[sheet]
    items, group, take = [], '', True
    for r, row in enumerate(ws.iter_rows(min_row=1, max_col=max(cols.values()), values_only=True), 1):
        if r < src.get('start_row', 11):
            continue
        get = lambda k: clean(row[cols[k] - 1]) if k in cols else ''  # noqa: E731
        a = get('tag')
        if is_group(a):
            group = a
            take = (not keep) or any(k in a for k in keep)
            continue
        if TAGPAT.match(a):
            if not take:
                continue
            if a.upper() in skip_tags:
                continue
            if skip_re and any(r.search(get('desc')) for r in skip_re):
                continue
            items.append(dict(
                sn=a, group=group,
                loc=get('location'), area=get('area'),
                desc=get('desc'), color=get('color'), size=get('size'),
                access=get('access'), remark=get('remark'), supplier=get('supplier'),
                qty=get('qty'), row=r, cont=[], src=src['label']))
            continue
        if not a and items and take:
            rest = [get(k) for k in ('desc', 'color', 'size', 'access', 'remark', 'supplier')]
            if any(rest):
                items[-1]['cont'].append([x for x in rest if x][0])
    wb.close()

    # 品名/材质口径
    ROOMW = re.compile(r'^(rooms?|bathroom|kitchen|hallway|lift lobby|main room|'
                       r'general areas?|hallways?/ ?rooms?|rooms?\s*)$', re.I)
    for it in items:
        if name_from == 'area':
            it['name'], it['material_parts'] = it['area'], [it['desc'], it['color']]
        else:
            # 少数表把品名写在 AREA 列、DESCRIPTION 留空（EQ11 Hand Wash Sink 等）
            nm = it['desc']
            if not nm and it['area'] and not ROOMW.match(it['area'].strip()):
                nm = it['area']
            it['name'], it['material_parts'] = nm, [it['color']]
        it['material_parts'] += [it['access']] if it['access'] else []
        it['material_parts'] += it['cont']
        it['material_parts'] = [x for x in it['material_parts'] if x]

    # 图片：按锚点行归属，只取图片列起始的图，每行优先最大的一张
    tag_rows = sorted(i['row'] for i in items)
    try:
        z = zipfile.ZipFile(path)
        sx = sheet_xml_path(z, sheet)
        amap = drawing_media_map(z, sx) if sx else {}
    except Exception as e:                                     # noqa: BLE001
        print('  [warn] %s drawing 解析失败: %s' % (sheet, e))
        z, amap = None, {}
    import bisect
    for ar, medias in amap.items():
        k = bisect.bisect_right(tag_rows, ar + 1) - 1
        if k < 0:
            continue
        it = [i for i in items if i['row'] == tag_rows[k]][0]
        if it.get('img'):
            continue
        for media in medias:
            try:
                data = z.read(media)
            except KeyError:
                continue
            p = os.path.join(cfg['img_dir'], '%s_%s.jpg' % (src['slug'], it['sn']))
            try:
                save_img(data, p, cfg.get('max_px', 520))
                it['img'] = p
                break
            except Exception:                                  # noqa: BLE001
                continue
    if z:
        z.close()
    return items


# ---------------------------------------------------------------- PDF 解析
PDF_COLS = [('tag', 0, 50), ('loc', 50, 91), ('area', 91, 198), ('desc', 198, 256),
            ('color', 256, 311), ('size', 311, 361), ('access', 361, 455),
            ('qty', 455, 460), ('supplier', 460, 520), ('remark', 520, 9999)]


def _bucket(x):
    for k, lo, hi in PDF_COLS:
        if lo <= x < hi:
            return k
    return 'remark'


def parse_pdf(src, cfg):
    doc = pymupdf.open(src['file'])
    items = []
    for pno in src['pages']:
        pg = doc[pno - 1]
        spans = []
        for blk in pg.get_text('dict')['blocks']:
            for ln in blk.get('lines', []):
                for sp in ln['spans']:
                    t = sp['text'].strip()
                    if t:
                        spans.append((sp['bbox'][0], sp['bbox'][1], sp['bbox'][3], t))
        tags = [(y0, t) for x0, y0, y1, t in spans if x0 < 50 and re.fullmatch(r'FU\d{1,3}', t)]
        if not tags:
            continue
        # 划界用的「全部条目 TAG」：本页所有 FU/WG/FT/EQ/FX/DH/FN 标签。
        # 只用 FU 划界会把下一段（WHITE GOODS 等）的文字块算进上一条 FU 的材质列。
        cuts = sorted((y0, t) for x0, y0, y1, t in spans
                      if x0 < 50 and re.fullmatch(r'(?:FU|FX|FT|WG|EQ|DH|FN)\d{1,3}', t))
        body = [(x0, y0, t) for x0, y0, y1, t in spans
                if not (x0 < 50 and re.fullmatch(r'(?:FU|FX|FT|WG|EQ|DH|FN)\d{1,3}', t))]
        # 页头/表头：只丢表格表头行以上（含）的内容。
        # 不能写死 y>200 —— 续页没有页头，TAG 直接在页面顶部（吧台区域 p7 的 FU5 在 y=108），
        # 写死阈值会把续页第一条整行吃掉，表现为「产品少了几条」。
        hdr_kw = re.compile(
            r'^(E-mail|FURNITURE (SCHEDULE|AND FIXTURE)|'
            r'PROJECT:|DATE:|TO:|ADDRESS:|TAG|LOCATION|AREA|IMAGE|PRODUCT CODE|'
            r'COLOR FINISH|UNIT SIZE|ACCESSORIES|QTY|SUPPLIER|REMARKS|Reference)')
        hdr = [y1 for x0, y0, y1, t in spans if t and hdr_kw.match(t) and y1 < 260]
        hdr_bot = (max(hdr) + 2) if hdr else 0
        body = [b for b in body if b[1] > hdr_bot]
        tags.sort()
        buckets = {t: {} for _, t in tags}
        cty = [c[0] for c in cuts]

        def owner(y0):
            """按相邻条目 TAG 的中点划界，而不是"最近 FU + 距离阈值"。

            上一行（如 FU5）与下一段（如 WHITE GOODS 的 WG1）间距小时，
            WG1 的文字块会落在距 FU5 的 95pt 窗口内被吃进 FU5 的材质列。
            """
            i = bisect.bisect_left(cty, y0)
            if i == 0:
                return cuts[0]
            if i >= len(cty):
                return cuts[-1]
            lo, hi = cuts[i - 1], cuts[i]
            return lo if (y0 - lo[0]) <= (hi[0] - y0) else hi

        for x0, y0, t in body:
            # 最近的 TAG（TAG 在行内垂直居中，y 与内容行不一致）
            best = owner(y0)
            if not best[1].startswith('FU'):
                continue                      # 属于白电/洁具/门五金等其它段落，丢掉
            if abs(best[0] - y0) > 95:
                continue
            k = _bucket(x0)
            buckets[best[1]].setdefault(k, []).append((y0, x0, t))

        # 图片按 bbox 归行
        pinfo = pg.get_image_info(xrefs=True)
        for _, tag in tags:
            d = {k: ' '.join(x[2] for x in sorted(v)) for k, v in buckets[tag].items()}
            ty = [y for y, t in tags if t == tag][0]
            cand = []
            for pi in pinfo:
                bx0, by0, bx1, by1 = pi['bbox']
                if 85 <= bx0 <= 210 and abs((by0 + by1) / 2 - ty) < 95:
                    cand.append((pi['xref'], (bx1 - bx0) * (by1 - by0)))
            img = None
            if cand:
                cand.sort(key=lambda x: -x[1])
                try:
                    pix = pymupdf.Pixmap(doc, cand[0][0])
                    if pix.n > 4:
                        pix = pymupdf.Pixmap(pymupdf.csRGB, pix)
                    p = os.path.join(cfg['img_dir'], '%s_%s.jpg' % (src['slug'], tag))
                    pix.save(p)
                    save_img(open(p, 'rb').read(), p, cfg.get('max_px', 520))
                    img = p
                except Exception:                              # noqa: BLE001
                    img = None
            items.append(dict(
                sn=tag, group=src.get('group', 'FURNITURE'),
                loc=d.get('loc', ''), area=d.get('area', ''),
                desc=d.get('desc', ''), color=d.get('color', ''), size=d.get('size', ''),
                access=d.get('access', ''), remark=d.get('remark', ''),
                supplier=d.get('supplier', ''), qty=d.get('qty', ''),
                row=pno * 1000 + ord(tag[-1]), cont=[],
                src=src['label'], img=img))
    doc.close()
    for it in items:
        it['name'] = src.get('name_from') == 'area' and it['area'] or it['desc']
        it['material_parts'] = [x for x in (it['color'], it['access']) if x]
    return items


# ---------------------------------------------------------------- 同节 TAG 撞号
def fix_dup_sn(items):
    """同一节里 TAG 撞号（两张表都编 FN13）时，后者加字母后缀，避免参考号重复。

    整行完全重复（同 TAG、同描述、同部位）的源表重复录入直接丢弃。
    不改源 TAG 含义，只在成品的 ref 上区分；overrides 用加后缀后的键。
    """
    seen, cnt, drop = {}, {}, []
    for it in items:
        k = (it['src'], it['sn'])
        if k in seen:
            if seen[k].get('desc') == it.get('desc') and seen[k].get('area') == it.get('area'):
                drop.append(it)
                continue
            cnt[k] = cnt.get(k, 1) + 1
            it['sn'] = '%s%s' % (it['sn'], chr(64 + cnt[k]))
        else:
            seen[k] = it
    for it in drop:
        items.remove(it)
    if drop or any(v > 1 for v in cnt.values()):
        print('同节 TAG 撞号：丢弃重复行 %d 条 / 改名 %d 条'
              % (len(drop), sum(v - 1 for v in cnt.values())))
    return len(drop)


# ---------------------------------------------------------------- 跨表去重
def dedupe(items, cfg):
    """同一前缀 + 同一品名、但来自不同工作表 → 合并（保留首次出现）。

    只在跨表时合并：同一张表里 FU1/FU14 都叫 Dining Table 是不同房型的两张桌子，
    合并会吃掉 SKU。合并后把来源 TAG 记进 dup_tags，可追溯。
    """
    if not cfg.get('dedupe', True):
        return 0
    keep, seen, n = [], {}, 0
    for it in items:
        m = re.match(r'[A-Z]+', str(it['sn']))
        if not m:
            keep.append(it)
            continue
        key = (m.group(0), re.sub(r'[^a-z0-9]+', '', str(it.get('name') or '').lower()))
        if key in seen:
            prev = seen[key]
            if prev['src'] != it['src']:
                prev.setdefault('dup_tags', []).append('%s-%s' % (it['src'], it['sn']))
                n += 1
                continue
        else:
            seen[key] = it
        keep.append(it)
    items[:] = keep
    print('跨表去重 %d 条' % n)
    return n


def apply_qty(items, cfg):
    src = cfg.get('qty_source')
    if not src:
        return 0
    wb = openpyxl.load_workbook(src['file'], read_only=True, data_only=True)
    ws = wb[src['sheet']]
    want = {i['sn']: i for i in items if i['src'] in (src.get('labels') or [i['src']])}
    n = 0
    for row in ws.iter_rows(min_row=src.get('start_row', 11), max_col=11, values_only=True):
        tag = clean(row[src.get('tag_col', 1) - 1])
        q = row[src.get('qty_col', 9) - 1]
        if tag in want and q not in (None, '', '-'):
            it = want[tag]
            if not it.get('qty'):
                it['qty'] = q
                n += 1
    wb.close()
    print('数量回灌 %d 条' % n)
    return n


def apply_overrides(items, cfg):
    """按「区域|TAG」人工改判：品名、补材质、备注、数量、红字。"""
    ov = cfg.get('overrides') or {}
    n = 0
    for it in items:
        o = ov.get('%s|%s' % (it['src'], it['sn']))
        if not o:
            continue
        n += 1
        if o.get('name'):
            it['name'] = o['name']
        if o.get('name_zh'):
            it['name_zh'] = o['name_zh']
        if o.get('material_add'):
            it['material_parts'].append(o['material_add'])
        if o.get('remark_add'):
            it['remark'] = ' / '.join([x for x in (it.get('remark'), o['remark_add']) if x])
        if o.get('remark_zh'):
            it['remark_zh'] = o['remark_zh']
        if o.get('qty') is not None:
            it['qty'] = o['qty']
        if o.get('flag'):
            it['flag'] = True
    print('人工改判 %d 条' % n)
    return n


# ---------------------------------------------------------------- 主流程
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', required=True)
    a = ap.parse_args()
    cfg = json.load(open(a.config, encoding='utf8'))['ffe']
    os.makedirs(cfg['img_dir'], exist_ok=True)

    all_items = []
    for src in cfg['sources']:
        if src['type'] == 'xlsx':
            its = parse_xlsx(src, cfg)
        else:
            its = parse_pdf(src, cfg)
        with_img = sum(1 for i in its if i.get('img'))
        print('%-22s %-28s %3d 条 | 有图 %3d' % (src['label'], src.get('sheet') or 'PDF p%s' % src.get('pages'), len(its), with_img))
        all_items += its

    fix_dup_sn(all_items)
    dedupe(all_items, cfg)
    apply_qty(all_items, cfg)
    apply_overrides(all_items, cfg)

    for it in all_items:
        it.setdefault('unit', cfg.get('default_unit') or '')
        it['name'] = re.sub(r'\s+', ' ', str(it.get('name') or '')).strip()
        it['material'] = ' / '.join(re.sub(r'\s+', ' ', x).strip()
                                    for x in it['material_parts'] if x)
        # 洁具/五金/固装的「SIZE」是型号规格或材料规格（LCN 1460T、32 Gallon、
        # Thickness 16 Length 2400），拆成 W/D/H 会变成 1460×864×965 这种假尺寸，
        # 所以这几类原文直出，不拆三维。
        raw_prefix = tuple(cfg.get('size_raw_prefix') or ('FN', 'FT', 'DH', 'FX'))
        # 项目常给 TAG 加前缀（PT-DH1、某项目-FU3），取末尾那段字母才是类别码
        _pm = re.search(r'([A-Z]+)\d+[A-Z]*$', str(it['sn']))
        _pref = _pm.group(1) if _pm else str(it['sn'])[:2]
        if _pref in raw_prefix:
            raw_sz = re.sub(r'\s+', ' ', str(it.get('size') or '')).strip()
            w = dd = hh = None
            dia, szflag = False, []
            it['size_raw'] = True        # 告诉 build_quote 别回退去拆原文
            if re.search(r'refer|see|check|as per', raw_sz, re.I) and \
                    re.search(r'detail|drawing|plan|measure', raw_sz, re.I):
                # 「尺寸见图纸」是源表的正常写法，统一成报价口径，不塞长句进规格列
                it['size_text'] = 'TBC (see drawings)'
            elif re.fullmatch(r'yes|no|n/?a|-+|tbc', raw_sz, re.I):
                # 尺寸列填了 Yes / TBC 这类非尺寸值，属源表填错，留痕待确认
                it['size_text'] = None
                it['flag'] = True
                it['size_note'] = '尺寸列源填「%s」，非尺寸值' % raw_sz
                it['remark'] = ' / '.join([x for x in (
                    it.get('remark'), '[source size field reads: %s]' % raw_sz) if x])
            else:
                # 规格列只放短规格；整段产品参数（水压范围、流量、包装尺寸）
                # 塞进规格列会撑爆行高，移到备注，规格列留空
                if raw_sz and (len(raw_sz) > 40 or not re.search(r'\d', raw_sz)):
                    it['size_text'] = None
                    it['remark'] = ' / '.join([x for x in (
                        it.get('remark'), '[size: %s]' % raw_sz[:140]) if x])
                else:
                    it['size_text'] = raw_sz or None
        else:
            w, dd, hh, dia, szflag = norm_size(it.get('size'))
            it['size_text'] = None
        it['w'], it['d'], it['h'], it['dia'] = w, dd, hh, dia
        it['size_mm'] = ' x '.join(str(x) for x in (w, dd, hh) if x is not None)
        rem = [x for x in (it.get('remark'), it.get('supplier')) if x]
        it['remark'] = ' / '.join(re.sub(r'\s+', ' ', x).strip() for x in rem)
        if szflag:
            hard = [x for x in szflag if not x.startswith('~')]
            soft = [x[1:] for x in szflag if x.startswith('~')]
            it['size_note'] = '; '.join(hard + soft)
            if hard:
                it['flag'] = True
                src_sz = re.sub(r'\s+', ' ', str(it.get('size') or '')).strip()
                it['remark'] = ' / '.join([x for x in (
                    it['remark'], '[%s%s]' % ('; '.join(hard),
                                              ('; source size: ' + src_sz) if src_sz else '')) if x])
        it['code'] = ''
        it['ref'] = '%s-%s' % (cfg.get('ref_prefix', ''), it['sn']) if cfg.get('ref_prefix') else it['sn']

    os.makedirs(os.path.dirname(os.path.abspath(cfg['parsed'])) or '.', exist_ok=True)
    json.dump({'items': all_items, 'general_req': []},
              open(cfg['parsed'], 'w', encoding='utf8'), ensure_ascii=False, indent=1)

    empty = lambda k: sum(1 for i in all_items if not str(i.get(k) or '').strip())  # noqa: E731
    qty_n = sum(1 for i in all_items if i.get('qty'))
    print('\n合计 %d 条 | 无名称 %d | 无尺寸 %d | 无材质 %d | 无图 %d | 有数量 %d | 红字待确认 %d'
          % (len(all_items), empty('name'), empty('size_mm'), empty('material'),
             sum(1 for i in all_items if not i.get('img')), qty_n,
             sum(1 for i in all_items if i.get('flag'))))
    print('→', cfg['parsed'])


if __name__ == '__main__':
    main()
