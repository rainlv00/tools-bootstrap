---
name: 清单整理
description: 把客户给的清单资料整理成可直接填价的报价单。触发：清单整理、清单资料整理、整理清单、整理报价单、按模板出报价、BOQ 转报价、家具清单报价、中英文报价单、FF&E quotation、材料报验表、报验清单、只整理家具、清单拆分、中文报价模板、中文模版、套中文模板、FFE 清单、FFE Schedule、设计方清单、软装清单、只有图纸、从图纸整理、按平面图出清单、房型家具清单、效果图整理。输入可为：客户 BOQ/Excel 清单、设计方 FFE Schedule（xlsx 或 PDF）、材料报验表/混合物料清单、或只有平面图+效果图的图纸集。产出：英文模板主表 + 中文子表、中英文分列的家具/非家具拆分表、或客户中文报价模板，含产品图提取、尺寸规范化与交付前 27/28 项自检。
agent_created: true
---

# 酒店家具报价单（客户 BOQ → 我方报价模板）

把客户的 BOQ / 工程量清单 / 设计公司软装清单，整理成可以直接填价、可以直接发客户的报价单。

上游是 `hotel-furniture-bom`（杂乱资料 → 标准清单）；本技能处理**清单已存在、要套我方报价模板**这一段。

## 一句话怎么用

说一句 **「清单整理」+ 资料路径 + 要什么**，就能跑。典型说法：

| 你说 | 我做什么 |
|---|---|
| 清单整理 `D:/xxx/项目`，英文模板 | 勘察目录 → 判支路 → 出英文主表 + 中文子表 |
| 整理这个清单，按客户中文模板出 | 拆家具/非家具 → 套中文模板 |
| 按平面图出房型家具清单 | 图纸项目支路（步骤 2e） |
| 把设计方 FFE Schedule 转成报价单 | FFE 支路（步骤 2d） |

**说「按默认」就不用逐项确认**，默认口径见步骤 1 的表。只给目录、什么都不说也照样开工，缺的按默认走，事后在交付说明里点出来。

## 何时使用

- 客户给了 BOQ 表（Excel），要求"按你们的模板报价"
- 设计公司给的是方案 PDF，需要拆成逐条报价行
- 需要中英双语（外资业主 / 外方顾问，但内部要中文核对）
- 需要把散装家具（loose furniture）和固装家具（built-in）分开报价
- 客户给的是**材料报验表 / 混合物料清单**，家具、五金、洁具、灯具、电器、布草、餐具混在一张表里，而本单位只做家具
- 国内项目要按**客户提供的中文报价模板**出正式报价清单（拆完家具后套模板版式，价格列暂留空）
- 设计方给的是 **FFE Schedule**（按 FURNITURE / JOINERIES / FIXTURES / WHITE GOODS / EQUIPMENT 分段的表格，xlsx 或 PDF）；默认取「除电器全收」，客户只要活动家具时才只取 `FURNITURE` 段
- 资料**只有平面图和效果图、没有任何电子清单**，需要从图纸整理出房型家具清单（走步骤 2e）

## 铁律

1. **模板结构必须 XML 级确认，不能只信一次 openpyxl 打印。**
   用 `xl/worksheets/sheet1.xml` 的 `r=` 属性 + `sharedStrings` 复核表头行、明细起止行、页脚起止行。行号错一行，整张表报废。

2. **产品图只能取内嵌原图，禁止截页面。**
   `doc.extract_image(xref)` 取图，配 smask 合成白底，numpy 按 <247 阈值去白边。截页面必然带引线标注和箭头。

2b. **没有产品图时，切图纸顶上，不许留空。**
   - 图面有可检索的家具编号（矢量文字层）→ 按条目编号 `page.search_for(code)` 定位，裁该编号周边一窗，一物一图。
   - 图面是栅格 / 无文字层 → 退化为**区域级**：裁该区域的家具平面图（去图框与标题栏），插入该区域每条明细的 PIC；同时在 `DRAWINGS` 页放可读大图（≥600px），因为 150px 缩略图只能表明"属于哪张图"，看不出家具。
   - **禁止按 media 顺序猜图**：数量对不上就是没有可靠映射，宁可退到区域级。
   - **行高必须由图片反推，不能只按文字算**。行高(pt) ≥ 图片显示高度 × 72/96 + 6。
     只按文字算行高、图片锚在格子左上角，图片会溢出压到下面几行（实测 4 行图纸叠成一团）。
     行比图高时（长规格撑高行），图片要垂直居中，否则大片空白。
   - 交付说明必须写清"图为区域平面布置图，非单件产品图"。

3. **源文字原样搬运，主表不翻译、不改写、不润色。**
   客户写 `Concelaed`、`Tabke`、`Dinign` 就保留错拼；只在中文子表里按正确含义翻译，并在译名后标「（原文拼写 XXX）」。

4. **数量和单价缺失就留空，绝不编造。**
   Pre-Bid BOQ 常常整列没有 quantity。留空 + REMARKS 标 `unit TBC` / `size TBC`，并在交付说明里点出来。

5. **型号去重按「分区 + 编码」双键。**
   同一编码在不同分区指不同产品是常态（实例：FU110 同时是三种尺寸的置物架、梳妆台、马扎）。只按编码合全会吃掉 4 个 SKU。

6. **交付前必跑自检，把原始输出贴给用户。**
   报价模板跑 `scripts/selfcheck.py`（27 项），清单拆分跑 `scripts/selfcheck_material.py`（28 项），中文模板输出跑 `scripts/selfcheck_cn_quote.py`（27 项）。
   任一 FAIL 必须报告失败项，不能只说"已完成"。**自检脚本自己报错时先分清是数据问题还是断言过严**，假 FAIL 要当场修脚本，不能拿它当结论，也不能为了过审改动源数据。

7. **混合清单只做家具，非家具必须单列子表，不许静默丢弃。**
   用户 2026-11-20 明确："我们只做家具，以后遇到这种情况也要注意。"
   - 家具＝可移动家具（床、柜、桌、椅、凳、沙发、行李架、婴儿床）＋ 固装木作（衣柜组合柜、浴室柜、小厨房橱柜、墙面饰板）＋ 固装软包（床头板）。
   - 门及门窗五金、灯具电气、洁具五金、瓷砖石材、涂料基材、电器、布草、餐具厨具、装饰软装（地毯/抱枕/挂画/镜子）全部**不计入家具**，单列「非家具」子表按品类分组，并加一页「说明」写清判定口径与待确认项。
   - **「由家具厂供货」不等于「是家具」**：吊灯、地毯、装饰镜常由家具供应商供货，但品类不是家具，归非家具并标待确认。
   - 条数必须守恒：家具条数 + 非家具条数 = 源表条目数，自检第 04 项会卡。
   - 拿不准的（混合条目、空名称、承包界面不清）不要替客户拍板：归到一边 + 备注写明推定依据 + 说明页列「待确认」。

## 流程

### 步骤 0 — 勘察资料

1. 列目录，看文件类型和体积。
2. 每个 PDF：`pymupdf` 打印页数 + 首页文字，判断是**规格书**、**提案册**还是**纯图**。
3. 每个 xlsx：打印 sheet 名 + 行数 + 列数。
4. 找硬指标：**有没有数量、有没有单价、有没有型号**。

### 步骤 1 — 确认口径（必须问，别猜）

一次性问清四件事（用 AskUserQuestion）。**用户说「按默认」或没提，就用下表默认值，别追问**：

| 问题 | 默认 | 其他选项 |
|---|---|---|
| 输出模板 | 我方英文模板（`方案` EN + `中文版` ZH 双表） | 客户 BOQ 原表填价 / 客户中文模板 / 只出结构化清单 |
| 数量 | 有则填、无则空；能从图纸数出房量就 × 房量 | 只报单价 / 用户稍后提供 / 按图纸估（不推荐） |
| 币种 | 人民币 RMB，不折美元 | USD / 当地币 |
| 范围 | 除电器全收（活动家具 + 固装 + 洁具 + 五金） | 只做活动家具 |
| 额外增补 | 单列一节并注明来源 | 并入主表 |

**只有两种情形必须问**：① 资料里没有任何可判范围的线索；② 房量/数量存在会让总价差一个数量级的歧义。其余一律按默认先做，做完在交付说明里列「我按什么口径做的」。

### 步骤 2 — 解析 BOQ

```bash
python scripts/parse_boq.py --loose LOOSE.xlsx --builtins BUILT-INS.xlsx --out _work/parsed.json
```

产出 `parsed.json`，每条含：分区、区域、Ref、型号、名称、尺寸串、材质、备注、单位、源行号。

**区块式 BOQ 有四种条目起始写法，只认字母编号会漏掉约 1/4 条目。** 规则见 `references/boq-parsing.md`。

### 步骤 2b — 混合清单分支：拆家具 / 非家具

资料是材料报验表、物料总表这类「一张表什么都有」时，走这条支路，不再套报价模板：

```bash
python scripts/parse_material_list.py --config _work/config.material.json
# 人工复核 items.json 的分类与「需人工确认」清单，必要时只改 config 的 override
python scripts/build_material_list.py --config _work/config.material.json
python scripts/selfcheck_material.py --config _work/config.material.json
```

三个脚本共用**同一个 config**：源文件路径、列位映射、分类词表、人工改判、分组顺序、表头文字、说明页文案、自检期望值全在里面。
`assets/config.material.sample.json` 是可直接照抄的样例。判定口径与坑位见 `references/material-split.md`。

### 步骤 2c — 中文报价模板输出（可选支路，v1.5 起）

拆完家具、又需要按**客户提供的中文报价模板**出正式报价清单时，接着跑。**同一份 config**，新增 `cn_quote` 节即可，不填就跳过这条支路：

```bash
python scripts/build_cn_quote.py      --config _work/config.material.json
python scripts/selfcheck_cn_quote.py  --config _work/config.material.json
python scripts/preview_cn_quote.py    --config _work/config.material.json   # 无 Excel 时目视核对版式
```

- 与步骤 2b 的三个脚本共用同一个 config：`cn_quote` 节放模板路径、行号/列位、列宽、字段口径、换行列、图片参数、抬头覆盖、自检期望值。
- `base` 默认接 `build_material_list.py` 的产物，自动把「非家具」子表和「说明」页一起带过去，产物仍是三张表；显式设 `null` 则只出报价清单单表。
- 逐格复刻模板（表头块 → 明细块 → 页脚块），**不插行删行**；价格/单位列留空、尺寸只认明确三段 mm、名称列强制自动换行（坑 25）。
- 配置键、字段映射、自检 27 项见 `references/cn-quote.md`；样例见 `assets/config.material.sample.json` 的 `cn_quote` 节。

### 步骤 2d — 设计方 FFE Schedule 分支（v1.6 起）

资料是设计方给的 **FFE Schedule**（`TAG | LOCATION | AREA | IMAGE | DESCRIPTION | COLOR | SIZE | ACCESSORIES | QTY | SUPPLIER | REMARKS`，按 `FURNITURE / EQUIPMENT / WHITE GOODS / FIXTURES / DOOR HARDWARE` 大写分段）时走这条：

```bash
python scripts/parse_ffe_schedule.py --config _work/config.ffe.json   # 抽条目/抽图/尺寸规范化
# 复核 parsed.json 的 无名称 / 无尺寸 / 无图 / 红字 四类，需要改的写进 ffe.overrides
python scripts/build_quote.py        --config _work/config.ffe.json   # 复用报价模板，不另写一套
python scripts/selfcheck.py          --file out.xlsx --expect-items N
```

- **交付范围按客户能力定，默认「除电器全收」**（2026-11-20 用户明确）：活动家具（`FURNITURE`）+ 固装家具（`JOINERIES`：衣柜、吧台、橱柜、电视墙、床头板、石材/人造石台面、玻璃、墙纸、黄铜嵌条）+ 洁具（`FIXTURES`）+ 门五金（`HARDWARE` / `DOORS HARDWARE`）+ 厨房不锈钢台架（`EQUIPMENT` 里的水槽/操作台/置物架）。**只排除通电设备**：冰箱、电视、烤箱、灶台、洗碗机、油烟机、微波炉、咖啡机、洗烘机、干手器（等于“吹风机”那类）。灯具（`LIGHTING`）不在家具范围，单独说明即可。
  - 判断标准是**通不通电**，不是段名。`WHITE GOODS` 段里同时有马桶（做）和冰箱（不做），必须按条目逐条判，用 `skip_tags` 精确排除。
  - 客户只要活动家具时才整段排除；不确定就问，别替客户缩范围。
- **先比对 TAG 集合再动手**：同项目常是「xlsx 主体 + PDF 补充页」，PDF 独有条目要单列一节。
- **交付范围要写进报告**：哪几类纳入、哪几类排除、为什么，客户核对源表时才对得上。
- 数量有值就填、没有留空；只在附属「核算图纸量」表里的用 `qty_source` 回灌。
- 中文表品名**逐条手写 `name_zh`**，材质/单位/页脚保留原文；术语表机械替换必然出垃圾（坑 28）。
- 配置键、尺寸规范化规则、源数据缺陷处理见 `references/ffe-schedule.md`；样例见 `assets/config.ffe.sample.json`。

### 步骤 2e — 图纸项目分支（无电子清单，v1.8 起）

资料只有**平面图 + 效果图**、没有任何 Excel/规格书清单时走这条。清单由人工整理，脚本只负责转格式和出表。

```bash
# 1. 勘察图纸：平面图有家具名称标注和尺寸的才是有效数据源，效果图只能识别品类与材质
# 2. 人工整理 _work/items.json（房型 → 条目；尺寸只抄图面标注，缺的写 null）
python scripts/build_from_items.py --items _work/items.json --out _work/parsed.json
python scripts/crop_from_pdf.py    --job _work/crop_job.json   # 产品图：裁单件并挂回 parsed.json
python scripts/build_quote.py      --config _work/config.json
python scripts/selfcheck.py        --file out.xlsx --expect-items N
```

- `items.json` 结构见 `assets/items.sample.json`：`rooms`（房型 → 条目，含 `materials` 按方案分材质）+ `sections`（节 → 引用哪个房型、哪个方案）。
- 同一房型可被多个节复用（两套设计方案 / 多个楼层），改 `sections` 即可，不改条目。
- **尺寸只抄图面明确标注的**，缺的写 `null`，脚本自动在备注补 `size TBC`。不要按「同类产品常见尺寸」填。
- **效果图不能当产品图**：只在每节首条挂一张房型效果图作锚点，并在该条备注写 `PIC shows room rendering, not single-product photo`。
- 一页平面图上标注了家具名、但**尺寸数字不在文字层**（CAD 导出打散成线条）时，只能放大人工读图；别指望 OCR 或文字提取。
- 交付说明必须写清：数据来自哪几张图、哪些尺寸是图上标的、哪些留空、哪些品类按口径排除。
- **高度（H）平面图通常不标**：只标宽×深。按家具常规高度补（桌 750、床头柜 550、床架 450、床头板 1100、衣柜/墙板按吊顶降 400、马桶 750、浴缸 550、淋浴隔断 2000），并用吊顶高度表交叉校验；交付说明写明「高度为常规值，非图纸标注」。
- **数量 = 单间件数 × 房量**：房量从建筑总平面图的客房层逐间数（图上标 `8TH-16TH FLOOR - HOTEL ROOMS` 这类标题，典型层 × 层数），`sections[].room_count` 给总数，脚本自动乘。数完必须在说明里写清「依据典型层计数，待甲方确认」。
- **产品图用 `crop_from_pdf.py` 裁**：job 文件里一条一个 `{pdf, page, section, name, box}`，`page` **从 1 开始**，`box` 是相对整页的 `[x0,y0,x1,y1]`（0~1）。脚本裁完自动按 `(section, name)` 写回 `parsed.json` 的 `img`，没给的条目留空。
  **不同方案的 PDF 页序不同，坐标不能直接套用**（OP1 的 p1 是衣柜、OP2 的 p1 可能是走廊），先渲染全部页面拼缩略图逐页确认，再定位坐标。
- 中文表要**中文材质和中文备注**：`items.json` 里给 `materials_zh`（按方案）和 `rm_zh`，脚本写进 `parsed.json` 的 `material_zh` / `remark_zh`；只靠 `zh_keep_material` 会让中文表整列英文。

### 步骤 3 — 抽产品图

图片是浮动图，锚点行常比条目首行**早 1 行**，且不同 sheet 行号重叠 —— 映射键必须用 `(sheet, row)`。做法见 `references/boq-parsing.md`「图片归属」。

### 步骤 4 — 套模板生成

```bash
python scripts/build_quote.py --config _work/config.json
```

一次生成两个 sheet：

- `方案`（英文，主表，所有数据的唯一来源）
- `中文版`（`copy_worksheet` 复制版式后逐格替换文案；图片要重新挂）

行号、列位、页脚位移规则见 `references/template-map.md`。

### 步骤 5 — 自检

```bash
python scripts/selfcheck.py --file out.xlsx                              # 报价模板：27 项
python scripts/selfcheck_material.py --config _work/config.material.json   # 清单拆分：28 项
python scripts/selfcheck_cn_quote.py --config _work/config.material.json   # 中文模板：27 项
```

报价模板 27 项见 `references/checklist.md`；清单拆分 28 项见 `references/material-split.md`；中文模板 27 项见 `references/cn-quote.md`。

### 步骤 6 — 交付

用 `present_files` 给文件，正文写清：条数、分节结构、留空了哪些列、源数据有哪些缺陷。

### 步骤 7 — 收尾：更新本技能（强制，不做等于这轮没做完）

**每一轮清单/报价整理结束后，自动回头更新这个技能，不等用户开口。**

四件事，按顺序做：

1. **记新坑**：这轮遇到的、技能里没有的问题，追加到 **`references/pitfalls.md`** 末尾（不是 SKILL.md），编号往下排。写清 `现象 → 根因 → 修法`，有代码就给代码；新增条数变了要同步 SKILL.md「常见坑」里那句「目前 N 条」。
2. **补术语**：新出现的产品名/材质词补进 `scripts/glossary.py`（品名进 `NAMES` 或 `NAME_PHRASES`/`NAME_WORDS`），然后跑覆盖率确认只剩品牌与料号。
3. **改脚本**：这轮为了过审临时打的补丁，合并进 `scripts/`；凡是下一个项目还会用到的，就做成配置开关而不是硬编码。
4. **写版本记录**：在 `references/changelog.md` 顶部加一条（日期 / 项目 / 新增 / 修复 / 影响），并把 `SKILL.md` 里「自检项数、脚本清单、配置开关」三处同步到最新。

判定标准：**下一个项目只改 `config.json` 就能跑通，不需要再改脚本。** 做不到就说明这轮该固化的东西没固化。

维护细则与 changelog 格式见 `references/maintenance.md`。

## 输出约定（默认，用户 2026-11-20 明确）

1. **永远同时输出英文主表 + 中文子表**，两个 sheet：`方案`（EN）+ `中文版`（ZH）。除非用户当次明确说"只要英文"。
2. **中文子表不是重排版**，是 `copy_worksheet` 复制版式后逐格换文案：列宽、行高、合并、图片锚点与主表完全一致，序号/尺寸/数量/金额必须逐格相同。
3. **重要存疑写进 REMARKS 列并标红加粗**（`Font(color='FFFF0000', bold=True)`），中英两表都要红。典型场景：客户标注的尺寸自相矛盾、与图纸不符、明显笔误。只在 REMARKS 里写，不要改 D/E/F 的原始数值。
4. 存疑项要在交付说明里逐条列出，不能只标在表里。
5. **三条支路别串台**：外资业主的 FF&E quotation 走 EN 主表 + ZH 子表；国内材料报验表走「家具清单 + 非家具子表 + 说明页」；要在拆分清单基础上出正式中文报价单，再接步骤 2c 套中文模板（产物仍是三张表）。不要为了凑格式硬翻成英文，也不要把中文模板的版式套到英文 BOQ 上。

## 排版规范（客户已认可的版本）

| 项 | 规则 |
|---|---|
| 明细字号 | 统一 9pt；英文 Arial / 中文宋体 |
| 字重 | 明细全部常规；只有表头行、分区行加粗 |
| 尺寸 | D/E/F 写**数字**；圆形件用 `"Ø"#,##0`（值是数字，显示带 Ø） |
| 行高 | 取 `max(文字需要的高度, 图片显示高度 × 72/96 + 6pt)`；散装明细不低于 80pt，分区行 26pt。**图片永远不压行** |
| 打印 | 横向、fitToWidth=1、表头行 1:8 重复 |
| 分区行 | 合并 A:M，浅米底 `FFE8E4D9`，左对齐缩进 |

## 常见坑

完整列表见 **`references/pitfalls.md`**（目前 48 条，编号 1–48，按轮次递增）。

高频前三条，贴在这里备查：

1. **模板行号偏一行** → 表头清空 + 页脚错位。必须用 XML 的 `r=` 复核，不能只信 openpyxl 打印。
2. **备注列写 `remark` 无效** → 只认 `remark_override`（坑 13、45）。
3. **中文表材质整列英文** → 要给 `material_zh`，`zh_keep_material` 只是兜底（坑 46）。

## 参考

- `references/boq-parsing.md` — 四种条目起始、分区识别、图片归属、尺寸解析
- `references/template-map.md` — 中英文模板行号/列位/页脚位移/打印设置
- `references/translation.md` — 术语表用法、翻译迭代法、客户原始错拼清单
- `references/checklist.md` — 报价模板自检 27 项逐条说明
- `references/material-split.md` — **混合清单拆分**：判定口径、分类优先级、图片归位、拆分表自检 28 项
- `references/cn-quote.md` — **中文报价模板输出**：配置键、字段映射、版式复刻、自检 27 项
- `references/ffe-schedule.md` — **设计方 FFE Schedule 支路**：源文件类型、列位映射、尺寸规范化、源数据缺陷处理
- `assets/items.sample.json` — **图纸项目**（步骤 2e）的 items.json 结构样例
- `references/pitfalls.md` — **常见坑完整列表**（1–48 条），SKILL.md 只保留高频三条
- `references/maintenance.md` — **每轮收尾怎么更新本技能**（四件事 + 验收标准）
- `references/changelog.md` — 版本记录，最新在最上面

## 脚本

| 文件 | 用途 |
|---|---|
| `scripts/parse_boq.py` | 客户 BOQ → parsed.json |
| `scripts/parse_ffe_schedule.py` | 设计方 FFE Schedule（xlsx/PDF）→ parsed.json + 抽图 + 尺寸规范化 |
| `scripts/build_from_items.py` | **图纸项目**：人工整理的 items.json → parsed.json |
| `scripts/crop_from_pdf.py` | **图纸项目**：从效果图裁单件产品图，按 (节,品名) 挂回 parsed.json |
| `scripts/build_quote.py` | 套模板生成英文主表 + 中文子表（含图片） |
| `scripts/glossary.py` | 产品名 + 材质术语表，**持续追加** |
| `scripts/selfcheck.py` | 27 项交付前自检 |
| `scripts/strict2t.py` | Strict OOXML → Transitional（openpyxl 能读） |
| `scripts/crop_drawings.py` | 图纸 PDF → 去图框裁切，生成区域平面图（含缩略图） |
| `scripts/parse_material_list.py` | 混合清单 → items.json（拆家具/非家具 + 照片按锚点归位） |
| `scripts/build_material_list.py` | items.json → 家具主表 + 非家具子表 + 说明页 |
| `scripts/selfcheck_material.py` | 拆分表 28 项交付前自检 |
| `scripts/build_cn_quote.py` | 中文报价模板输出（逐格复刻模板 + 名称列换行 + 带非家具/说明页） |
| `scripts/selfcheck_cn_quote.py` | 中文模板输出 27 项交付前自检 |
| `scripts/preview_cn_quote.py` | 中文模板版式预览（PIL 按像素宽度折行，本机无 Excel 时用） |

报价模板的配置里控制输出的几个开关：

| 配置键 | 作用 |
|---|---|
| `auto_height` | 备注/材质越长行越高（给上限，如 300），长规格不被截断 |
| `header.L8` | 备注列表头（模板默认为空） |
| `logo` / `logo_anchor` / `logo_w` / `logo_h` | 中文表补 logo，尺寸按模板锚点的实际显示尺寸给 |
| `drawing_map` | `{区域: 图纸jpg}`，产品图缺失时回填 |
| `drawing_mode` | `all` 每条都填 / `first` 每区只填首条（默认 all） |
| `drawings_sheet` | 是否额外生成 `DRAWINGS` 大图页（默认 true） |
| `pic_w` / `pic_h` / `col_widths` | PIC 列图片框尺寸与列宽，图纸类缩略图建议 150×100、C 列 21。**行高会按图片自动撑开** |

混合清单（步骤 2b）三个脚本共用另一份 config，键位见 `assets/config.material.sample.json`：
| 配置键 | 作用 |
|---|---|
| `columns` | 源表字段名 → 列号映射（换客户表只改这里） |
| `classify.furniture_keys` / `non_furniture_subs` | 家具白名单 / 非家具品类词表及分组顺序 |
| `classify.override` | 人工改判 `{S/N: [子类, 理由]}`，子类为 `""` 表示改判为家具，**优先级最高** |
| `classify.keyword_exclusions` | 短词误伤复合家具名时的排除词，如 `{"电视": ["电视柜"]}` |
| `classify.bedding_keys` | 名称带「床」但其实是布草的排除词 |
| `photo.max_photos` / `max_px` / `col` / `box_w` / `box_h` | 每行最多几张、缩图上限、照片列、图片框尺寸 |
| `sheet_names` / `output_columns` / `notes` | 表名、列头与列宽、说明页文案（支持 `{fur}`/`{non}`/`{total}`/`{with_photo}` 占位符） |
| `selfcheck.expected_furniture` / `expected_non` / `expected_total` / `expected_images` | 自检期望值，条数守恒靠它卡 |

中文模板输出（步骤 2c）挂在**同一份 config** 的 `cn_quote` 节，与上面两条支路共用文件：

| 配置键 | 作用 |
|---|---|
| `cn_quote.tpl` / `out` / `base` / `items` | 中文模板、输出、上游拆分清单（默认取顶层 `out`）、items.json（默认 `<work_dir>/items.json`） |
| `cn_quote.layout` | 表头行数 / 明细起始行 / 样式行 / 页脚起止 / 末列 / 合并区 / 重复表头，**行号一律以 XML 为准** |
| `cn_quote.columns` / `col_widths` / `wrap_cols` | 列位映射、列宽覆盖、需自动换行的列（默认名称列） |
| `cn_quote.text` | 材质词、备注字段顺序、品名裁剪正则、尺寸正则、各类文案前缀 |
| `cn_quote.photo` | 每行最多图片数、行高上下限、文字行高系数、图片间距、logo 尺寸 |
| `cn_quote.overrides` | 抬头 / 项目名 / 时间等按项目覆盖的单元格，表头自检会自动排除 |
| `cn_quote.selfcheck` | 27 项自检的期望值（家具/非家具/图片/尺寸数字/字体/打印区/说明页关键词），`null` 跳过 |

`assets/config.sample.json` 是英文报价支路的样例；`assets/config.material.sample.json` 同时覆盖清单拆分与中文模板输出两条支路；`assets/config.ffe.sample.json` 是设计方 FFE Schedule 支路 —— 新项目照抄改路径即可。

FFE Schedule 支路（步骤 2d）挂在**同一份 config** 的 `ffe` 节：

| 配置键 | 作用 |
|---|---|
| `ffe.sources[].type` / `file` / `sheet` / `pages` | 数据源：`xlsx`（给 sheet）或 `pdf`（给页码数组） |
| `ffe.sources[].label` / `slug` | 内部区域名（对应顶层 `sections[].src`）/ 图片文件名前缀 |
| `ffe.sources[].cols` | 字段名 → 列号映射，**每份源文件单独给**，别复用 |
| `ffe.sources[].name_from` | 品名取哪列：`desc` / `area` / `code` |
| `ffe.sources[].groups` | 分段白名单，子串匹配（`"FURNITURE"` 也能命中 `FURNITURE/ FITTINGS`）；`[]` = 整表都收 |
| `ffe.sources[].skip_tags` | 按 TAG 精确排除，**排除电器只能这么排**（`WHITE GOODS` 段里马桶要做、冰箱不做） |
| `ffe.sources[].skip_name_re` | 按品名正则排除，TAG 编号不稳时用 |
| `ffe.dedupe` | 跨工作表按「前缀 + 品名」合并同一产品（同表内不合并，避免吃掉不同房型的同款家具） |
| `ffe.size_raw_prefix` | 这几类前缀的 SIZE 是型号/材料规格，原文直出规格列、不拆三维（默认 `["FN","FT","DH","FX"]`） |
| `ffe.qty_source` | 附属「核算图纸量」表按 TAG 回灌数量，`overwrite: false` 不覆盖已有值 |
| `ffe.overrides` | 人工改判，键 `区域|TAG`，可给 `name` / `name_zh` / `material_add` / `remark_add` / `qty` / `flag` |
| `ffe.max_px` / `default_unit` | 抽图缩略上限 / 默认单位（`PCS`） |
| `zh_keep_material` / `zh_keep_remark` | 中文表材质、备注保留原文（FFE 支路建议都开） |

**验收标准：下一个项目只改 `config.json` 就能跑通，不需要再改脚本。**
